﻿using CAImportWorkflow.Data;
using CAImportWorkflow.Models;
using ClosedXML.Excel;
using DocumentFormat.OpenXml.Spreadsheet;
using DocumentFormat.OpenXml.Wordprocessing;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Syncfusion.Linq;
using System.Data;
using System.DirectoryServices;
using System.Globalization;
using System.Linq.Dynamic.Core;
using System.Reflection;
using System.Security.Claims;
using System.Threading;
using IHostingEnvironment = Microsoft.AspNetCore.Hosting.IHostingEnvironment;

namespace CAImportWorkflow.Controllers
{

    public class AdminController : Controller
    {
        public ApplicationDbContext _ctx;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly IHostingEnvironment hostingEnvironment;
        public AdminController(ApplicationDbContext ctx, IHttpContextAccessor httpContextAccessor, IHostingEnvironment _hostingEnvironment)
        {
            hostingEnvironment = _hostingEnvironment;
            _httpContextAccessor = httpContextAccessor;
            _ctx = ctx;
        }
        public IActionResult Index()
        {
            return View();
        }

        [Authorize(Roles = "Admin,Supervisor,Manager")]
        public IActionResult AdminDashboard()
        {
            ViewData["UserName"] = _ctx.User.Where(x => x.IsActive == true && x.IsDelete == false).OrderBy(x => x.CitrixId).ToList();
            ViewData["ThreadName"] = _ctx.ThreadMaster.OrderBy(x => x.Sequence).ThenBy(x => x.Name).ToList();
            return View();
        }

     

        ///Add Location
        ///
        [Authorize(Roles = "Admin,Supervisor,Manager")]
        [HttpGet]
        public IActionResult InsertLocation()
        {
            List<LocationMaster> locationMaster = _ctx.LocationMaster.OrderBy(x => x.Name).ToList();
            return View(locationMaster);
        }

        /// <summary>
        /// Create New Location
        /// </summary>
        /// <returns></returns>
        [Authorize(Roles = "Admin,Supervisor,Manager")]
        [HttpGet]
        public IActionResult CreateLocation()
        {
            ViewData["LocationId"] = Guid.NewGuid().ToString();
            return PartialView();
        }


        /// <summary>
        /// Edit Location
        /// </summary>
        /// <param name="locationId"></param>
        /// <returns></returns>
        [Authorize(Roles = "Admin,Supervisor,Manager")]
        [HttpGet]
        public IActionResult EditLocation(string locationId)
        {
            ViewData["LocationName"] = _ctx.LocationMaster.Where(x => x.Id == locationId).FirstOrDefault();

            return PartialView();
        }


        [HttpPost]
        public JsonResult CreateLocation(LocationMaster model)
        {
            if (ModelState.IsValid)
            {
                LocationMaster locationMaster = _ctx.LocationMaster.Where(x => x.Id == model.Id.Trim()).FirstOrDefault();

                if (locationMaster == null)
                {
                    LocationMaster locationName = _ctx.LocationMaster.Where(x => x.Name == model.Name.Trim()).FirstOrDefault();
                    if (locationName == null)
                    {
                        _ctx.LocationMaster.Add(
                            new LocationMaster
                            {
                                Id = model.Id,
                                Name = model.Name,
                                IsActive = true
                            });
                    }
                    else
                    {
                        return Json("Duplicate");
                    }
                }
                else
                {
                    LocationMaster locationName = _ctx.LocationMaster.Where(x => x.Name == model.Name.Trim()).FirstOrDefault();
                    if (locationName == null)
                    {
                        locationMaster.Name = model.Name;
                        _ctx.LocationMaster.Update(locationMaster);
                    }
                    else
                    {
                        return Json("Duplicate");
                    }
                }

                _ctx.SaveChanges();
                return Json(ModelState);
            }
            else
            {
                return Json("Something went wrong");
            }
        }

        /// <summary>
        /// Activate Location        /// 
        /// </summary>
        /// <param name="Id"></param>
        /// <returns></returns>
        public JsonResult ActivateLocation(string Id)
        {
            string message = "";
            if (Id != null)
            {
                LocationMaster master = _ctx.LocationMaster.Where(x => x.Id == Id).FirstOrDefault();
                if (master != null)
                {
                    master.IsActive = master.IsActive != null ? !master.IsActive : true;
                    _ctx.LocationMaster.Update(master);
                    _ctx.SaveChanges();
                    message = master.IsActive == true ? master.Name + " Location Activated!" : master.Name + " Location Deactivated!";

                }
                else
                {
                    message = "Error in Activation.!";
                }
            }
            return Json(message);
        }

        //public JsonResult ActivateUser(string Id)
        //{
        //    string message = "";
        //    if (Id != null)
        //    {
        //        User master = _ctx.User.Where(x => x.Id == Id).FirstOrDefault();
        //        if (master != null)
        //        {
        //            master.IsActive = master.IsActive != null ? !master.IsActive : true;
        //            _ctx.User.Update(master);
        //            _ctx.SaveChanges();
        //            message = master.IsActive == true ? master.UserName + "Activated!" : master.UserName + "Deactivated!";

        //        }
        //        else
        //        {
        //            message = "Error in Activation.!";
        //        }
        //    }
        //    return Json(message);
        //}
        //public JsonResult DeleteUser(string Id)
        //{
        //    string message = "";
        //    if (Id != null)
        //    {
        //        User master = _ctx.User.Where(x => x.Id == Id).FirstOrDefault();
        //        if (master != null)
        //        {
        //            master.IsDelete = master.IsDelete != null ? !master.IsDelete : true;
        //            _ctx.User.Update(master);
        //            _ctx.SaveChanges();
        //            message = master.IsDelete == true ? master.UserName + "Deleted!" : master.UserName + "Restore!";

        //        }
        //        else
        //        {
        //            message = "Error in Activation.!";
        //        }
        //    }
        //    return Json(message);
        //}
        //public JsonResult ActivateActivity(string Id)
        //{
        //    string message = "";
        //    if (Id != null)
        //    {
        //        ActivityMaster master = _ctx.ActivityMaster.Where(x => x.Id == Id).FirstOrDefault();
        //        if (master != null)
        //        {
        //            master.IsActive = master.IsActive != null ? !master.IsActive : true;
        //            _ctx.ActivityMaster.Update(master);
        //            _ctx.SaveChanges();
        //            message = master.IsActive == true ? master.Name + " Activity Activated!" : master.Name + " Activity Deactivated!";

        //        }
        //        else
        //        {
        //            message = "Error in Activation.!";
        //        }
        //    }
        //    return Json(message);
        //}
        public JsonResult DeleteActivity(string Id)
        {
            string message = "";
            if (Id != null)
            {
                ActivityMaster master = _ctx.ActivityMaster.Where(x => x.Id == Id).FirstOrDefault();
                if (master != null)
                {
                    master.IsDelete = master.IsDelete != null ? !master.IsDelete : true;
                    _ctx.ActivityMaster.Update(master);
                    _ctx.SaveChanges();
                    message = master.IsDelete == true ? master.Name + " Activity Deleted!" : master.Name + " Activity Restore!";

                }
                else
                {
                    message = "Error in Activation.!";
                }
            }
            return Json(message);
        }

        ///Create Activity
        ///
        [Authorize(Roles = "Admin,Supervisor,Manager")]
        [HttpGet]
        public IActionResult InsertActivity()
        {
            ViewData["ActivityId"] = Guid.NewGuid().ToString();
            ViewData["ThreadList"] = _ctx.ThreadMaster.Where(x => x.IsActive == true).OrderBy(x => x.Sequence).ThenBy(x => x.Name).ToList();
            ViewData["ActivityList"] = _ctx.ActivityMaster.Select(x => new ActivityMasterModel
            {
                Id = x.Id,
                Name = x.Name,
                BasedOn = x.BasedOn,
                IsActive = x.IsActive,
                ThreadId = x.ThreadId,
                ThreadName = x.ThreadMaster.Name,
                Sequence = x.Sequence
            }).OrderBy(x => x.Sequence).ThenBy(x => x.Name).ToList();
            return PartialView();
        }


        [HttpPost]
        public JsonResult InsertActivity(ActivityMasterModel model)
        {
            if (ModelState.IsValid)
            {
                ActivityMaster activityMaster = _ctx.ActivityMaster.Include(x => x.ThreadMaster).Where(x => x.Id == model.Id.Trim() && x.ThreadMaster.IsActive == true).FirstOrDefault();

                if (activityMaster == null)
                {
                    ActivityMaster activityName = _ctx.ActivityMaster.Include(x => x.ThreadMaster).Where(x => x.Name == model.Name.Trim() && x.ThreadMaster.IsActive == true).FirstOrDefault();
                    if (activityName == null)
                    {
                        _ctx.ActivityMaster.Add(
                            new ActivityMaster
                            {
                                Id = model.Id,
                                Name = model.Name,
                                BasedOn = model.BasedOn,
                                Sequence = model.Sequence,
                                ThreadId = model.ThreadId,
                                IsActive = true
                            });
                    }
                    else
                    {
                        return Json("Duplicate");
                    }
                }
                else
                {
                    activityMaster.Name = model.Name;
                    activityMaster.BasedOn = model.BasedOn;
                    activityMaster.ThreadId = model.ThreadId;
                    activityMaster.Sequence = model.Sequence;
                    _ctx.ActivityMaster.Update(activityMaster);

                }

                _ctx.SaveChanges();
                return Json(ModelState);
            }
            else
            {
                return Json("Something went wrong");
            }
        }

        ///Create Activity
        ///
        [Authorize(Roles = "Admin,Supervisor,Manager")]
        [HttpGet]
        public IActionResult InsertThread()
        {
            ViewData["ThreadId"] = Guid.NewGuid().ToString();
            ViewData["ThreadList"] = _ctx.ThreadMaster.OrderBy(x => x.Sequence).ThenBy(x => x.Name).ToList();
            return PartialView();
        }

        [HttpPost]
        public JsonResult InsertThread(ThreadMaster model)
        {
            if (ModelState.IsValid)
            {
                ThreadMaster threadMaster = _ctx.ThreadMaster.Where(x => x.Id == model.Id.Trim()).FirstOrDefault();

                if (threadMaster == null)
                {
                    ThreadMaster threadName = _ctx.ThreadMaster.Where(x => x.Name == model.Name.Trim()).FirstOrDefault();
                    if (threadName == null)
                    {
                        _ctx.ThreadMaster.Add(
                            new ThreadMaster
                            {
                                Id = model.Id,
                                Name = model.Name,
                                Sequence = model.Sequence,
                                IsActive = true
                            });
                    }
                    else
                    {
                        return Json("Duplicate");
                    }
                }
                else
                {
                    ThreadMaster threadName = _ctx.ThreadMaster.Where(x => x.Name == model.Name.Trim()).FirstOrDefault();
                    threadMaster.Name = model.Name;
                    threadMaster.Sequence = model.Sequence;
                    _ctx.ThreadMaster.Update(threadMaster);

                }

                _ctx.SaveChanges();
                return Json(ModelState);
            }
            else
            {
                return Json("Something went wrong");
            }
        }


        ///Add File
        ///
        [Authorize(Roles = "Admin,Supervisor,Manager")]
        [HttpGet]
        public IActionResult InsertFile()
        {
            ViewData["LocationList"] = _ctx.LocationMaster.OrderBy(x => x.Name).ToList();
            return View();
        }

        [HttpPost]
        public IActionResult InsertFile(FileEntryViewModel model)
        {
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            var act = _ctx.ActivityMaster.Where(x => x.BasedOn == "File" && x.ThreadMaster.Name == "HBL User" && x.IsActive == true && x.IsDelete == false).OrderBy(x => x.Sequence).ThenBy(x => x.Name).ToList();
            _ctx.Database.SetCommandTimeout(300);
            var present = _ctx.FileEntry.Where(x => x.ContainerNo == model.ContainerNo).FirstOrDefault();
            if (present == null)
            {
                FileEntry file = new FileEntry
                {
                    FileNo = model.FileNo,
                    ContainerNo = model.ContainerNo,
                    IsEdi = (model.IsEdi.ToUpper() == "TRUE" || model.IsEdi.ToUpper() == "YES" ? true : false),
                    Pol = model.Pol,
                    Pod = model.Pod,
                    FinalDestination = model.FinalDestination,
                    FileType = model.FileType,
                    Hblcount = model.Hblcount,
                    ActualHblcount = model.ActualHblcount,
                    Cbm = model.Cbm,
                    CoLoader = model.CoLoader,
                    SailingDate = model.SailingDate,
                    EtaAtPod = model.EtaAtPod,
                    EtaAtFD = model.EtaAtFD,
                    MBLFreightTerm = model.MBLFreightTerm,
                    HBLFreightTerm = model.HBLFreightTerm,
                    VesselName = model.VesselName,
                    ShippingLine = model.ShippingLine,
                    ContactPerson = model.ContactPerson,
                    Status = null,
                    CreatedDate = DateTime.UtcNow,
                    CreatedBy = userid,

                };
                _ctx.FileEntry.Add(file);

                foreach (ActivityMaster activity in act)
                {
                    _ctx.FileActivity.Add(new FileActivity
                    {
                        Id = Guid.NewGuid().ToString(),
                        FileId = file.Id,
                        ActivityId = activity.Id,
                        CurrentStatus = "UnAllocated",
                        Comment = null,
                        UserId = null,
                        EnterDate = DateTime.UtcNow,
                    });
                }
                _ctx.SaveChanges();
                return Json("Success");
            }
            else
            {
                return Json("Container Already present.!");
            }
        }

        //[HttpPost]
        //public JsonResult GetData(string fileno, string type, string etadate, string container, string status, string thread, string user)
        //{
        //    var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
        //    int totalRecord = 0;
        //    int filterRecord = 0;
        //    int hblrecord = 0;
        //    var draw = Request.Form["draw"].FirstOrDefault();
        //    var sortColumn = Request.Form["columns[" + Request.Form["order[0][column]"].FirstOrDefault() + "][name]"].FirstOrDefault();
        //    var sortColumnDirection = Request.Form["order[0][dir]"].FirstOrDefault();
        //    var searchValue = Request.Form["search[value]"].FirstOrDefault();
        //    int pageSize = Convert.ToInt32(Request.Form["length"].FirstOrDefault() ?? "0");
        //    int skip = Convert.ToInt32(Request.Form["start"].FirstOrDefault() ?? "0");
        //    _ctx.Database.SetCommandTimeout(300);
        //    //IQueryable<FileEntry> data = _ctx.Set<FileEntry>().AsQueryable();

        //    //List<FileEntryViewModel> fileEntryViewModels = new List<FileEntryViewModel>();
        //    //_ctx.Database.SetCommandTimeout(300);
        //    //fileEntryViewModels = data.Include(x => x.FileActivity).ThenInclude(x => x.ActivityMaster.ThreadMaster).Select(x => new FileEntryViewModel
        //    //{
        //    //    Id = x.Id,
        //    //    CreatedDate = x.CreatedDate,
        //    //    FileNo = x.FileNo,
        //    //    ContainerNo = x.ContainerNo,
        //    //    IsEdi = x.IsEdi == true ? "Yes" : "No",
        //    //    Pol = x.Pol,
        //    //    Pod = _ctx.LocationMaster.Where(y => y.Id == x.Pod).Select(y => y.Name).FirstOrDefault(),
        //    //    FinalDestination = x.FinalDestination,
        //    //    FileType = x.FileType,
        //    //    Hblcount = x.HblEntry.Count() != 0 ? x.HblEntry.Count().ToString() : x.Hblcount,
        //    //    Cbm = x.Cbm,
        //    //    CoLoader = x.CoLoader,
        //    //    SailingDate = x.SailingDate,
        //    //    EtaAtPod = x.EtaAtPod,
        //    //    EtaAtFD = x.EtaAtFD,
        //    //    MBLFreightTerm = x.MBLFreightTerm,
        //    //    HBLFreightTerm = x.HBLFreightTerm,
        //    //    VesselName = x.VesselName,
        //    //    ShippingLine = x.ShippingLine,
        //    //    ContactPerson = x.ContactPerson,
        //    //    ThreadName = x.FileActivity
        //    //.OrderByDescending(y => y.EnterDate)
        //    //.Select(y => y.ActivityMaster.ThreadMaster.Name)
        //    //.FirstOrDefault(),

        //    //    AllocatedTo = x.FileActivity
        //    //.OrderByDescending(y => y.EnterDate)
        //    //.Select(y => _ctx.User
        //    //    .Where(z => z.Id == y.UserId)
        //    //    .Select(z => z.UserName)
        //    //    .FirstOrDefault())
        //    //.FirstOrDefault(),

        //    //    Status = x.FileActivity
        //    //.OrderByDescending(y => y.EnterDate)
        //    //.Select(y => y.CurrentStatus)
        //    //.FirstOrDefault() ?? "Pending",

        //    //    //    FileActivities = x.FileActivity
        //    //    //.OrderByDescending(y => y.EnterDate)
        //    //    //.Select(y => new FileActivity
        //    //    //{
        //    //    //    ActivityMaster = y.ActivityMaster,
        //    //    //    CurrentStatus = y.CurrentStatus,
        //    //    //    UserId = _ctx.User
        //    //    //        .Where(z => z.Id == y.UserId)
        //    //    //        .Select(z => z.UserName)
        //    //    //        .FirstOrDefault(),
        //    //    //    EndTime = y.EndTime,
        //    //    //    EnterDate = y.EnterDate
        //    //    //})
        //    //    //.ToList(),
        //    //    //HblEntry = x.HblEntry,

        //    //})/*.Skip(skip * pageSize).Take(pageSize == -1 ? 100 : pageSize)*/.ToList();

        //    //IQueryable<FileEntry> data = _ctx.Set<FileEntry>().AsQueryable();

        //    //_ctx.Database.SetCommandTimeout(300);

        //    //var locationMasters = _ctx.LocationMaster.ToDictionary(lm => lm.Id, lm => lm.Name);
        //    //var users = _ctx.User.ToDictionary(u => u.Id, u => u.UserName);

        //    //var fileEntryViewModels = data
        //    //    .Include(x => x.FileActivity)
        //    //        .ThenInclude(fa => fa.ActivityMaster)
        //    //            .ThenInclude(am => am.ThreadMaster)
        //    //    .Select(x => new FileEntryViewModel
        //    //    {
        //    //        Id = x.Id,
        //    //        CreatedDate = x.CreatedDate,
        //    //        FileNo = x.FileNo,
        //    //        ContainerNo = x.ContainerNo,
        //    //        IsEdi = x.IsEdi == true ? "Yes" : "No",
        //    //        Pol = x.Pol,
        //    //        Pod = locationMasters.ContainsKey(x.Id == x.Pod) ? locationMasters[x.Pod] : null,
        //    //        FinalDestination = x.FinalDestination,
        //    //        FileType = x.FileType,
        //    //        Hblcount = x.HblEntry.Count().ToString(),
        //    //        Cbm = x.Cbm,
        //    //        CoLoader = x.CoLoader,
        //    //        SailingDate = x.SailingDate,
        //    //        EtaAtPod = x.EtaAtPod,
        //    //        EtaAtFD = x.EtaAtFD,
        //    //        MBLFreightTerm = x.MBLFreightTerm,
        //    //        HBLFreightTerm = x.HBLFreightTerm,
        //    //        VesselName = x.VesselName,
        //    //        ShippingLine = x.ShippingLine,
        //    //        ContactPerson = x.ContactPerson,
        //    //        ThreadName = x.FileActivity
        //    //            .OrderByDescending(fa => fa.EnterDate)
        //    //            .Select(fa => fa.ActivityMaster.ThreadMaster.Name)
        //    //            .FirstOrDefault(),
        //    //        AllocatedTo = x.FileActivity
        //    //            .OrderByDescending(fa => fa.EnterDate)
        //    //            .Select(fa => users.ContainsKey(fa.UserId) ? users[fa.UserId] : null)
        //    //            .FirstOrDefault(),
        //    //        Status = x.FileActivity
        //    //            .OrderByDescending(fa => fa.EnterDate)
        //    //            .Select(fa => fa.CurrentStatus)
        //    //            .FirstOrDefault() ?? "Pending",
        //    //        HblEntry = x.HblEntry
        //    //    })
        //    //    //.Skip(skip * pageSize)
        //    //    //.Take(pageSize == -1 ? 100 : pageSize)
        //    //    .ToList();

        //    //IQueryable<FileEntryViewModel> SortedData = fileEntryViewModels.AsQueryable();

        //    //if (!string.IsNullOrEmpty(fileno))
        //    //{
        //    //    SortedData = SortedData.Where(x => x.FileNo == fileno.Trim());

        //    //}
        //    //if (!string.IsNullOrEmpty(type) && type != "all" && type != "--select--")
        //    //{
        //    //    SortedData = SortedData.Where(x => x.FileType == type.Trim());

        //    //}
        //    //if (!string.IsNullOrEmpty(etadate))
        //    //{
        //    //    SortedData = SortedData.Where(x => x.EtaAtPod == Convert.ToDateTime(etadate));

        //    //}

        //    //if (!string.IsNullOrEmpty(container))
        //    //{
        //    //    SortedData = SortedData.Where(x => x.ContainerNo == container.Trim());

        //    //}

        //    //if (!string.IsNullOrEmpty(user) && user != "none" && user != "--select--")
        //    //{
        //    //    SortedData = SortedData.Where(x => x.CreatedBy == user.Trim());

        //    //}

        //    //if (!string.IsNullOrEmpty(status) && status != "none" && status != "--select--")
        //    //{
        //    //    SortedData = SortedData.Where(x => x.Status == status.Trim());

        //    //}

        //    //if (!string.IsNullOrEmpty(thread) && thread != "none" && thread != "--Select--")
        //    //{
        //    //    SortedData = SortedData.Where(x => x.ThreadName == thread.Trim());

        //    //}
        //    //if (searchValue == "WIP" || searchValue == "Completed" || searchValue == "Pending" || searchValue == "Query" ||
        //    //            searchValue == "Received" || searchValue == "UnAllocated" || searchValue == "eta10" || searchValue == "eta12")
        //    //{
        //    //    if (searchValue == "eta10")
        //    //    {
        //    //        SortedData = SortedData.Where(x => x.EtaAtPod != null && x.EtaAtPod.Value.Date >= DateTime.Now.Date.AddDays(4) && x.EtaAtPod.Value.Date < DateTime.Now.Date.AddDays(11) && (x.Status != "Completed"));

        //    //    }
        //    //    else if (searchValue == "eta12")
        //    //    {
        //    //        SortedData = SortedData.Where(x => x.EtaAtPod != null && x.EtaAtPod.Value.Date >= DateTime.Now.Date && x.EtaAtPod.Value.Date < DateTime.Now.Date.AddDays(4) && x.Status != "Completed");
        //    //    }
        //    //    else if (searchValue == "Received")
        //    //    {
        //    //        SortedData = SortedData;
        //    //    }
        //    //    else if (searchValue == "UnAllocated")
        //    //    {
        //    //        SortedData = SortedData.Where(x => x.Status == "WIP" && x.AllocatedTo == null);
        //    //    }
        //    //    else if (searchValue == "Pending")
        //    //    {
        //    //        SortedData = SortedData.Where(x => x.Status == "Pending" || x.Status == "Completed With Query");
        //    //    }
        //    //    else
        //    //    {
        //    //        SortedData = SortedData.Where(x => x.Status == searchValue);
        //    //    }
        //    //}

        //    //if (!string.IsNullOrEmpty(sortColumn) && !string.IsNullOrEmpty(sortColumnDirection))
        //    //{
        //    //    SortedData = SortedData.OrderBy(sortColumn + " " + sortColumnDirection).AsQueryable();
        //    //}
        //    //else
        //    //{
        //    //    sortColumn = "createdDate";
        //    //    sortColumnDirection = "desc";
        //    //    SortedData = SortedData.OrderBy(sortColumn + " " + sortColumnDirection).AsQueryable();
        //    //}

        //    //int hblFilter = 0;
        //    //foreach (var hblcount in SortedData.ToList())
        //    //{
        //    //    hblFilter = SortedData.Sum(x => Convert.ToInt32(x.Hblcount));
        //    //}
        //    //var returnObj = new
        //    //{
        //    //    draw = draw,
        //    //    recordsTotal = data.Count(),
        //    //    recordsFiltered = SortedData.Count(),
        //    //    data = SortedData,
        //    //    hblCount = hblFilter
        //    //};
        //    //ViewData["TotalHBL"] = hblFilter;
        //    DateTime threeMonth = DateTime.UtcNow.AddMonths(-3);

        //    var query = _ctx.Set<FileEntryDashboardViewModel>().FromSqlRaw("SELECT * FROM vw_AdminDashboardViewModels").AsQueryable();
        //    var filteredRecords = query.Where(x => x.EtaAtPod.Value.Date >= threeMonth.Date || x.EtaAtPod.Value.Date == null).AsQueryable();

        //    IQueryable<FileEntryDashboardViewModel> SortedData = filteredRecords.AsQueryable();

        //    if (!string.IsNullOrEmpty(fileno))
        //    {
        //        SortedData = SortedData.Where(x => x.FileNo == fileno.Trim());
        //    }
        //    if (!string.IsNullOrEmpty(type) && type != "all" && type != "--select--")
        //    {
        //        SortedData = SortedData.Where(x => x.FileType == type.Trim());
        //    }
        //    if (!string.IsNullOrEmpty(etadate))
        //    {
        //        SortedData = SortedData.Where(x => x.EtaAtPod == Convert.ToDateTime(etadate));
        //    }
        //    if (!string.IsNullOrEmpty(container))
        //    {
        //        SortedData = SortedData.Where(x => x.ContainerNo == container.Trim());
        //    }
        //    if (!string.IsNullOrEmpty(user) && user != "none" && user != "--select--")
        //    {
        //        SortedData = SortedData.Where(x => x.AllocatedTo == user.Trim());
        //    }
        //    if (!string.IsNullOrEmpty(status) && status != "none" && status != "--select--")
        //    {
        //        SortedData = SortedData.Where(x => x.Status == status.Trim());
        //    }
        //    //else if(searchValue == "Completed")
        //    //{
        //    //    SortedData = SortedData.Where(x => x.Status == "Completed");
        //    //}else
        //    //{
        //    //    SortedData = SortedData.Where(x => x.Status != "Completed");
        //    //}
        //    if (!string.IsNullOrEmpty(thread) && thread != "none" && thread != "--Select Thread--")
        //    {
        //        SortedData = SortedData.Where(x => x.ThreadName == thread.Trim());
        //    }

        //    if (searchValue == "WIP" || searchValue == "Completed" || searchValue == "Pending" || searchValue == "Query" ||
        //        searchValue == "Received" || searchValue == "UnAllocated" || searchValue == "eta10" || searchValue == "eta12")
        //    {
        //        if (searchValue == "eta10")
        //        {
        //            SortedData = SortedData.Where(x => x.EtaAtPod != null && x.EtaAtPod.Value.Date >= DateTime.Now.Date.AddDays(4) &&
        //                                               x.EtaAtPod.Value.Date < DateTime.Now.Date.AddDays(11) && (x.Status != "Completed"));
        //        }
        //        else if (searchValue == "eta12")
        //        {
        //            SortedData = SortedData.Where(x => x.EtaAtPod != null && x.EtaAtPod.Value.Date >= DateTime.Now.Date &&
        //                                               x.EtaAtPod.Value.Date < DateTime.Now.Date.AddDays(4) && x.Status != "Completed");
        //        }
        //        else if (searchValue == "Received")
        //        {
        //            // No additional filtering needed for "Received"
        //        }
        //        else if (searchValue == "UnAllocated")
        //        {
        //            SortedData = SortedData.Where(x => x.Status == "WIP" && x.AllocatedTo == null);
        //        }
        //        else if (searchValue == "Pending")
        //        {
        //            SortedData = SortedData.Where(x => x.Status == "Pending" || x.Status == "Completed With Query");
        //        }
        //        else
        //        {
        //            SortedData = SortedData.Where(x => x.Status == searchValue);
        //        }
        //    }

        //    if (!string.IsNullOrEmpty(sortColumn) && !string.IsNullOrEmpty(sortColumnDirection))
        //    {
        //        SortedData = SortedData.OrderBy(sortColumn + " " + sortColumnDirection);
        //    }
        //    else
        //    {
        //        sortColumn = "createdDate";
        //        sortColumnDirection = "desc";
        //        SortedData = SortedData.OrderBy(sortColumn + " " + sortColumnDirection);
        //    }

        //    int hblFilter = SortedData.Sum(x => Convert.ToInt32(x.Hblcount));
        //    var returnObj = new
        //    {
        //        draw = draw,
        //        recordsTotal = filteredRecords.Count(),
        //        recordsFiltered = SortedData.Count(),
        //        data = SortedData.ToList(),
        //        hblCount = hblFilter
        //    };
        //    ViewData["TotalHBL"] = hblFilter;

        //    return Json(returnObj);
        //}

        [HttpPost]
        public JsonResult GetData(string fileno, string type, string etadate, string container, string status, string thread, string user)
        {
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            var draw = Request.Form["draw"].FirstOrDefault();
            var sortColumn = Request.Form["columns[" + Request.Form["order[0][column]"].FirstOrDefault() + "][name]"].FirstOrDefault();
            var sortDirection = Request.Form["order[0][dir]"].FirstOrDefault();
            var searchValue = Request.Form["search[value]"].FirstOrDefault();
            int pageSize = Convert.ToInt32(Request.Form["length"].FirstOrDefault() ?? "0");
            int skip = Convert.ToInt32(Request.Form["start"].FirstOrDefault() ?? "0");

            // Default sorting options
            sortColumn = string.IsNullOrEmpty(sortColumn) ? "CreatedDate" : sortColumn;
            sortDirection = string.IsNullOrEmpty(sortDirection) ? "desc" : sortDirection;

            DateTime? eta = !string.IsNullOrEmpty(etadate)
               ? DateTime.ParseExact(etadate, "MMM/dd/yyyy", CultureInfo.InvariantCulture)
               : (DateTime?)null;
          
            // Convert DateTime to "yyyy-MM-dd" format strings
            string etaFormatted = eta.HasValue ? eta.Value.ToString("yyyy-MM-dd") : null;
            
            // Call the stored procedure with filters and pagination
            if(searchValue == "")
            {
                searchValue = null;
            }
            var data = _ctx.Set<FileEntryDashboardViewModel>()
                        .FromSqlRaw("EXEC sp_GetAdminDashboardData @p0, @p1, @p2, @p3, @p4, @p5, @p6, @p7, @p8, @p9",
                                    fileno, type, eta, container, status, thread, user, searchValue, sortColumn, sortDirection).ToList();
            var sortedData = data;

            if (searchValue == "WIP" || searchValue == "Completed" || searchValue == "Pending" || searchValue == "Query" ||
                searchValue == "Received" || searchValue == "UnAllocated" || searchValue == "eta10" || searchValue == "eta12")
            {
                if (searchValue == "eta10")
                {
                    sortedData = sortedData.Where(x => x.EtaAtPod != null && x.EtaAtPod.Value.Date >= DateTime.Now.Date.AddDays(4) &&
                                                       x.EtaAtPod.Value.Date < DateTime.Now.Date.AddDays(11) && (x.Status != "Completed")).ToList();
                }
                else if (searchValue == "eta12")
                {
                    sortedData = sortedData.Where(x => x.EtaAtPod != null && x.EtaAtPod.Value.Date >= DateTime.Now.Date &&
                                                       x.EtaAtPod.Value.Date < DateTime.Now.Date.AddDays(4) && x.Status != "Completed").ToList();
                }
                else if (searchValue == "Received")
                {
                    // No additional filtering needed for "Received"
                }
                else if (searchValue == "UnAllocated")
                {
                    sortedData = sortedData.Where(x => x.Status == "UnAllocated" && x.AllocatedTo == null).ToList();
                }
                else if (searchValue == "Pending")
                {
                    sortedData = sortedData.Where(x => x.Status == "Pending" || x.Status == "Completed With Query").ToList();
                }
                else
                {
                    sortedData = sortedData.Where(x => x.Status == searchValue).ToList();
                }
            }

            int hblFilter = data.Sum(x => Convert.ToInt32(x.Hblcount));
            var returnObj = new
            {
                draw = draw,
                recordsTotal = data.Count(),
                recordsFiltered = sortedData.Count(),
                data = sortedData,
                hblCount = hblFilter != 0 ? hblFilter : 0
            };

            ViewData["TotalHBL"] = hblFilter;

            return Json(returnObj);
        }

        [HttpGet]
        public IActionResult GetHblData(string fileId, string hblId)
        {
            _ctx.Database.SetCommandTimeout(300);
            var hblEntry = _ctx.HblEntry.Where(x => x.FileGuidId == fileId).Select(x => new HBLDataList
            {
                Id = x.Id,
                Hblno = x.Hblno == null ? "" : x.Hblno,
                FileGuidId = x.FileGuidId,
                IsDap = x.IsDap,
                CreatedDate = x.CreatedDate,
                CreatedBy = x.User.UserName == null ? "" : x.User.UserName

            }).ToList();

            var fileEntryData = _ctx.FileActivity.Include(x => x.ActivityMaster).Include(x => x.FileEntry).ThenInclude(x => x.User).Where(x => x.FileEntry.Id == fileId).Select(x => new FileDataList
            {
                ActivityId = x.ActivityMaster.Name,
                Comment = x.Comment == null ? "" : x.Comment,
                CurrentStatus = x.CurrentStatus,
                EndTime = x.EndTime,
                EnterDate = x.EnterDate,
                FileNo = x.FileEntry.FileNo == null ? "" : x.FileEntry.FileNo,
                Id = x.FileId,
                UserId = x.FileEntry.User.UserName == null ? "" : x.FileEntry.User.UserName,
            }).OrderByDescending(y => y.EndTime).ToList();


            return Json(new { fileEntryData, hblEntry });

        }


        public JsonResult GetDashboardValue()
        {

            //IQueryable<FileEntry> data = _ctx.Set<FileEntry>().AsQueryable();
            _ctx.Database.SetCommandTimeout(300);
            //List<FileEntryViewModel> fileEntryViewModels = new List<FileEntryViewModel>();

            //fileEntryViewModels = data.Include(x => x.FileActivity).ThenInclude(x => x.ActivityMaster.ThreadMaster).Select(x => new FileEntryViewModel
            //{
            //    Id = x.Id,
            //    CreatedDate = x.CreatedDate,
            //    FileNo = x.FileNo,
            //    EtaAtPod = x.EtaAtPod,
            //    EtaAtFD = x.EtaAtFD,
            //    ThreadName = _ctx.FileActivity.Where(y => y.FileId == x.Id).OrderByDescending(y => y.EnterDate).Select(y => y.ActivityMaster.ThreadMaster.Name).FirstOrDefault(),
            //    //AllocatedTo = _ctx.FileActivity.Where(y => y.FileId == x.Id).OrderByDescending(y => y.EnterDate).Select(y => _ctx.User.Where(z => z.Id == y.UserId).Select(z => z.UserName).FirstOrDefault()).FirstOrDefault(),
            //    //Status = _ctx.FileActivity.Where(y => y.FileId == x.Id).OrderByDescending(y => y.EnterDate).Select(y => _ctx.User.Where(z => z.Id == y.UserId).Select(z => z.UserName).FirstOrDefault()).FirstOrDefault() == null ? "Pending" : _ctx.FileActivity.Where(y => y.FileId == x.Id).OrderByDescending(y => y.EnterDate).Select(y => y.CurrentStatus).FirstOrDefault(),
            //    AllocatedTo = x.FileActivity
            //.OrderByDescending(y => y.EnterDate)
            //.Select(y => _ctx.User
            //    .Where(z => z.Id == y.UserId)
            //    .Select(z => z.UserName)
            //    .FirstOrDefault())
            //.FirstOrDefault(),
            //    Status = x.FileActivity
            //.OrderByDescending(y => y.EnterDate)
            //.Select(y => y.CurrentStatus)
            //.FirstOrDefault() ?? "Pending",
            //}).ToList();

            DateTime threeMonth = DateTime.UtcNow.AddMonths(-3);
            //var fileEntryViewModels = _ctx.Set<FileEntryDashboardViewModel>().FromSqlRaw("SELECT * FROM vw_AdminDashboardCount").AsQueryable();
            //fileEntryViewModels = fileEntryViewModels.Where(x => x.EtaAtPod.Value.Date >= threeMonth.Date || x.EtaAtPod.Value.Date == null);
           
            var data = _ctx.Set<FileEntryDashboardViewModel>()
            .FromSqlRaw("EXEC sp_GetAdminDashboardData").ToList();

            var now = DateTime.Now.Date;
            AdminDashboardModel model = new AdminDashboardModel
            {
                Received = data.Count(),
                WIP = data.Count(x => x.Status == "WIP"),
                Pending = data.Count(x => x.Status == "Pending" || x.Status == "Completed With Query"),
                Completed = data.Count(x => x.Status == "Completed"),
                Query = data.Where(x => x.Status == "Query").ToList().Count,
                UnTouched = data.Count(x => x.Status == "UnAllocated" && x.AllocatedTo == null),
                eta10 = data.Count(x => x.EtaAtPod.HasValue && x.EtaAtPod.Value.Date >= now.AddDays(4) && x.EtaAtPod.Value.Date < now.AddDays(11) && x.Status != "Completed"),
                eta12 = data.Count(x => x.EtaAtPod.HasValue && x.EtaAtPod.Value.Date >= now && x.EtaAtPod.Value.Date < now.AddDays(4) && x.Status != "Completed"),

            };

            return Json(model);

        }


        [Authorize(Roles = "Admin,Supervisor,Manager")]
        public ActionResult Report()
        {
            return View();
        }
        public DataTable ToDataTable<T>(List<T> items)
        {
            DataTable dataTable = new DataTable(typeof(T).Name);
            //Get all the properties by using reflection   
            PropertyInfo[] Props = typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance);
            foreach (PropertyInfo prop in Props)
            {
                //Setting column names as Property names  
                dataTable.Columns.Add(prop.Name);
            }
            foreach (T item in items)
            {
                var values = new object[Props.Length];
                for (int i = 0; i < Props.Length; i++)
                {

                    values[i] = Props[i].GetValue(item, null);
                }
                dataTable.Rows.Add(values);
            }

            return dataTable;
        }

        [Authorize(Roles = "Admin,Supervisor,Manager")]
        [HttpGet]
        public IActionResult ActivityMapping()
        {
            ViewData["HBLStatusList"] = _ctx.ActivityMaster.Where(x => x.BasedOn == "HBL" && x.IsActive == true && x.IsDelete == false).OrderBy(x => x.Sequence).ThenBy(x => x.Name).ToList();
            _ctx.Database.SetCommandTimeout(300);
            var result = _ctx.ActivityMaster
                            .Where(x => x.BasedOn == "File").OrderBy(x => x.Sequence).ThenBy(x => x.Name)
                            .Select(x => new ActivityMapModel
                            {
                                FileActivityId = x.Id,
                                FileActivityName = x.Name,
                                ThreadName = x.ThreadMaster.Name,
                                HBLMappedActivityList = _ctx.ActivityMapping.Include(y => y.HBLActivityMaster).Where(y => y.FileActivityMaster.Id == x.Id).Select(y => y.HBLActivityMaster.Id).ToList(),
                                IsActive = x.IsActive,
                                IsDelete = x.IsDelete
                            }).Where(x => x.IsDelete == false).ToList();

            return View(result);
        }

        [HttpPost]
        public IActionResult ActivityMapping(ActivityMapModel activitymap)
        {
            var assignedHBLStatus = _ctx.ActivityMapping.Where(x => x.FileActivityMaster.Id == activitymap.FileActivityId).ToList();
            _ctx.Database.SetCommandTimeout(300);
            try
            {
                _ctx.RemoveRange(assignedHBLStatus);

                if (activitymap.HBLMappedActivityList != null)
                    foreach (var multi in activitymap.HBLMappedActivityList)
                    {
                        _ctx.ActivityMapping.Add(new ActivityMapping
                        {
                            Id = Guid.NewGuid().ToString(),
                            FileActivityId = activitymap.FileActivityId,
                            HBLActivityId = multi.ToString(),
                            IsActive = true
                        });
                    }

                _ctx.SaveChanges();
                return Json("success");

            }
            catch (Exception ex)
            {
                return Json("failed");
            }
        }
        public JsonResult MultiAllocate(MultipleAllocationViewModel model)
        {
            if (model.multiSelectViewModels != null)
            {
                foreach (var multilist in model.multiSelectViewModels)
                {
                    List<FileActivity> fileActivitiesList = _ctx.FileActivity.Where(x => x.FileId == multilist.eId).ToList();

                    foreach (FileActivity fileActivity in fileActivitiesList)
                    {
                        if (fileActivity != null)
                        {
                            fileActivity.CurrentStatus = "Pending";
                            fileActivity.UserId = model.uname;
                            _ctx.FileActivity.Update(fileActivity);
                        }
                    }
                }
                _ctx.SaveChanges();
                return Json("Success");
            }
            else
            {
                return Json("Failed");
            }

        }
        public JsonResult DeMultiAllocate(MultipleAllocationViewModel model)
        {
            if (model.multiSelectViewModels != null)
            {
                foreach (var multilist in model.multiSelectViewModels)
                {
                    List<FileActivity> fileActivitiesList = _ctx.FileActivity.Where(x => x.FileId == multilist.eId).ToList();

                    foreach (FileActivity fileActivity in fileActivitiesList)
                    {
                        if (fileActivity != null)
                        {
                            //fileActivity.CurrentStatus = "Pending";
                            fileActivity.UserId = null;
                            _ctx.FileActivity.Update(fileActivity);
                        }
                    }
                }
                _ctx.SaveChanges();
                return Json("Success");
            }
            else
            {
                return Json("Failed");
            }

        }

        public JsonResult FileDetails(FileDetailsViewModel model)
        {
            var result = _ctx.FileEntry.Where(x => x.Id == model.Filedetails.Id).FirstOrDefault();
            if (result != null)
            {

            }

            return Json(model);
        }

        [HttpPost]
        public IActionResult PreAlertDataReport(string fileno, string type, string etadate, string container, string status, string thread, string user)
        {
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            int totalRecord = 0;
            int filterRecord = 0;
            var draw = Request.Form["draw"].FirstOrDefault();
            var sortColumn = Request.Form["columns[" + Request.Form["order[0][column]"].FirstOrDefault() + "][name]"].FirstOrDefault();
            var sortColumnDirection = Request.Form["order[0][dir]"].FirstOrDefault();
            var searchValue = Request.Form["search[value]"].FirstOrDefault();
            int pageSize = Convert.ToInt32(Request.Form["length"].FirstOrDefault() ?? "0");
            int skip = Convert.ToInt32(Request.Form["start"].FirstOrDefault() ?? "0");
            var fileActivity = _ctx.ActivityMaster.Where(x => x.IsActive == true && x.IsDelete == false).OrderBy(x => x.Sequence).ThenBy(x => x.Name).ToList();

            IQueryable<FileEntry> data = _ctx.Set<FileEntry>().AsQueryable();
            _ctx.Database.SetCommandTimeout(300);
            totalRecord = data.Count();


            if (!string.IsNullOrEmpty(fileno))
            {
                data = data.Where(x => x.FileNo == fileno.Trim());

            }
            if (!string.IsNullOrEmpty(type) && type != "all" && type != "--select--")
            {
                data = data.Where(x => x.FileType == type.Trim());

            }
            if (!string.IsNullOrEmpty(etadate))
            {
                data = data.Where(x => x.EtaAtPod == Convert.ToDateTime(etadate));

            }

            if (!string.IsNullOrEmpty(container))
            {
                data = data.Where(x => x.ContainerNo == container.Trim());

            }

            if (!string.IsNullOrEmpty(user) && user != "none" && user != "--select--")
            {
                data = data.Where(x => x.CreatedBy == user.Trim());

            }

            if (!string.IsNullOrEmpty(status) && status != "none" && status != "--select--")
            {
                data = data.Where(x => x.Status == status.Trim());

            }

            if (searchValue == "WIP" || searchValue == "Completed" || searchValue == "Pending" || searchValue == "Query" ||
                        searchValue == "Received" || searchValue == "UnAllocated" || searchValue == "eta10" || searchValue == "eta12")
            {
                if (searchValue == "eta10")
                {
                    data = data.Where(x => x.EtaAtPod != null && Convert.ToDateTime(x.EtaAtPod).AddDays(-10) <= DateTime.Now && (x.Status != "Completed"));

                }
                else if (searchValue == "eta12")
                {
                    data = data.Where(x => x.EtaAtPod != null && Convert.ToDateTime(x.EtaAtPod).AddDays(-10) > DateTime.Now && Convert.ToDateTime(x.EtaAtPod).AddDays(-12) <= DateTime.Now && x.Status != "Completed");
                }

                else
                {
                    data = data.Where(x => x.Status == searchValue);
                }
            }

            if (!string.IsNullOrEmpty(sortColumn) && !string.IsNullOrEmpty(sortColumnDirection))
                data = data.OrderBy(sortColumn + " " + sortColumnDirection).AsQueryable();

            var fileEntryData = new List<FileEntryData>();
            var fileEntryViewModels = data.Include(x => x.FileActivity).ThenInclude(x => x.ActivityMaster.ThreadMaster).Select(x => new
            {
                CreatedDate = x.CreatedDate,
                FileNo = x.FileNo,
                ContainerNo = x.ContainerNo,
                IsEdi = x.IsEdi == true ? "Yes" : "No",
                Pol = x.Pol,
                Pod = x.Pod,
                FinalDestination = x.FinalDestination,
                FileType = x.FileType,
                Hblcount = x.Hblcount,
                Cbm = x.Cbm,
                CoLoader = x.CoLoader,
                SailingDate = x.SailingDate,
                EtaAtPod = x.EtaAtPod,
                VesselName = x.VesselName,
                ShippingLine = x.ShippingLine,
                ContactPerson = x.ContactPerson,
                ThreadName = _ctx.FileActivity.Where(y => y.FileId == x.Id).OrderByDescending(y => y.EnterDate).Select(y => y.ActivityMaster.ThreadMaster.Name).FirstOrDefault(),
                Status = _ctx.FileActivity.Where(y => y.FileId == x.Id).OrderByDescending(y => y.EnterDate).Select(y => y.CurrentStatus).FirstOrDefault(),
                AllocatedTo = _ctx.FileActivity.Where(y => y.FileId == x.Id).OrderByDescending(y => y.EnterDate).Select(y => _ctx.User.Where(z => z.Id == y.UserId).Select(z => z.UserName).FirstOrDefault()).FirstOrDefault(),

            }).ToList();

            DataTable dt = new DataTable();
            dt.Columns.Add("Received Date");
            dt.Columns.Add("FileNo");
            dt.Columns.Add("ContainerNo");
            dt.Columns.Add("IsEdi");
            dt.Columns.Add("Pol");
            dt.Columns.Add("Pod");
            dt.Columns.Add("FinalDestination");
            dt.Columns.Add("FileType");
            dt.Columns.Add("Hblcount");
            dt.Columns.Add("Cbm");
            dt.Columns.Add("CoLoader");
            dt.Columns.Add("SailingDate");
            dt.Columns.Add("EtaAtPod");
            dt.Columns.Add("VesselName");
            dt.Columns.Add("ShippingLine");
            dt.Columns.Add("ContactPerson");
            dt.Columns.Add("ThreadName");
            dt.Columns.Add("Status");
            dt.Columns.Add("AllocatedTo");

            foreach (var file in fileEntryViewModels)
            {

                DataRow tr = dt.NewRow();
                tr[0] = file.CreatedDate;
                tr[1] = file.FileNo;
                tr[2] = file.ContainerNo;
                tr[3] = file.IsEdi;
                tr[4] = file.Pol;
                tr[5] = file.Pod;
                tr[6] = file.FinalDestination;
                tr[7] = file.FileType;
                tr[8] = file.Hblcount;
                tr[9] = file.Cbm;
                tr[10] = file.CoLoader;
                tr[11] = file.SailingDate;
                tr[12] = file.EtaAtPod;
                tr[13] = file.VesselName;
                tr[14] = file.ShippingLine;
                tr[15] = file.ContactPerson;
                tr[16] = file.ThreadName;
                tr[17] = file.Status;
                tr[18] = file.AllocatedTo;
                dt.Rows.Add(tr);

            }

            using (XLWorkbook wb = new XLWorkbook())
            {
                dt.TableName = "Pre-Alert Report";

                var wsFileData = wb.Worksheets.Add(dt);

                using (MemoryStream stream = new MemoryStream())
                {
                    wb.SaveAs(stream);
                    string excelname = $"PreAlertReport-{DateTime.Now.ToString("ddmmyyyy hh:mm:ss")}.xlsx";
                    return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", excelname);
                }
            }
        }

        [HttpPost]
        public IActionResult PreAlertDataDownload(string fileno, string type, string etadate, string container, string status, string thread, string user)
        {
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            int totalRecord = 0;
            int filterRecord = 0;
            var draw = Request.Form["draw"].FirstOrDefault();
            var sortColumn = Request.Form["columns[" + Request.Form["order[0][column]"].FirstOrDefault() + "][name]"].FirstOrDefault();
            var sortColumnDirection = Request.Form["order[0][dir]"].FirstOrDefault();
            var searchValue = Request.Form["search[value]"].FirstOrDefault();
            int pageSize = Convert.ToInt32(Request.Form["length"].FirstOrDefault() ?? "0");
            int skip = Convert.ToInt32(Request.Form["start"].FirstOrDefault() ?? "0");
            var fileActivity = _ctx.ActivityMaster.Where(x => x.IsActive == true && x.IsDelete == false).OrderBy(x => x.Sequence).ThenBy(x => x.Name).ToList();
            _ctx.Database.SetCommandTimeout(300);
            IQueryable<FileEntry> data = _ctx.Set<FileEntry>().AsQueryable();

            totalRecord = data.Count();

            if (!string.IsNullOrEmpty(fileno))
            {
                data = data.Where(x => x.FileNo == fileno.Trim());

            }
            if (!string.IsNullOrEmpty(type) && type != "all" && type != "--select--")
            {
                data = data.Where(x => x.FileType == type.Trim());

            }
            if (!string.IsNullOrEmpty(etadate))
            {
                data = data.Where(x => x.EtaAtPod == Convert.ToDateTime(etadate));

            }

            if (!string.IsNullOrEmpty(container))
            {
                data = data.Where(x => x.ContainerNo == container.Trim());

            }

            if (!string.IsNullOrEmpty(user) && user != "none" && user != "--select--")
            {
                data = data.Where(x => x.CreatedBy == user.Trim());

            }

            if (!string.IsNullOrEmpty(status) && status != "none" && status != "--select--")
            {
                data = data.Where(x => x.Status == status.Trim());

            }

            if (searchValue == "WIP" || searchValue == "Completed" || searchValue == "Pending" || searchValue == "Query" ||
                        searchValue == "Received" || searchValue == "UnAllocated" || searchValue == "eta10" || searchValue == "eta12")
            {
                if (searchValue == "eta10")
                {
                    data = data.Where(x => x.EtaAtPod != null && Convert.ToDateTime(x.EtaAtPod).AddDays(-10) <= DateTime.Now && (x.Status != "Completed"));

                }
                else if (searchValue == "eta12")
                {
                    data = data.Where(x => x.EtaAtPod != null && Convert.ToDateTime(x.EtaAtPod).AddDays(-10) > DateTime.Now && Convert.ToDateTime(x.EtaAtPod).AddDays(-12) <= DateTime.Now && x.Status != "Completed");
                }

                else
                {
                    data = data.Where(x => x.Status == searchValue);
                }
            }


            var fileEntryData = new List<FileEntryData>();
            var fileEntryViewModels = data.Include(x => x.FileActivity).ThenInclude(x => x.ActivityMaster.ThreadMaster).Select(x => new
            {
                CreatedDate = x.CreatedDate,
                FileNo = x.FileNo,
                ContainerNo = x.ContainerNo,
                IsEdi = x.IsEdi == true ? "Yes" : "No",
                Pol = x.Pol,
                Pod = x.Pod,
                FinalDestination = x.FinalDestination,
                FileType = x.FileType,
                Hblcount = x.Hblcount,
                Cbm = x.Cbm,
                CoLoader = x.CoLoader,
                SailingDate = x.SailingDate,
                EtaAtPod = x.EtaAtPod,
                VesselName = x.VesselName,
                ShippingLine = x.ShippingLine,
                ContactPerson = x.ContactPerson,
            }).ToList();


            var fileActivityList = _ctx.FileEntry.Include(x => x.User).Include(x => x.FileActivity).ThenInclude(x => x.ActivityMaster).ToList();
            foreach (var file in fileActivity)
            {
                foreach (var item in fileActivityList)
                {
                    fileEntryData.Add(new FileEntryData
                    {
                        FileId = item.FileNo,
                        Activity = _ctx.ActivityMaster.Where(x => x.Id == file.Id && x.BasedOn == "File").Select(x => x.Name).FirstOrDefault(),
                        Date = item.FileActivity.Where(x => x.ActivityId == file.Id).Select(x => x.EndTime).FirstOrDefault(),
                        Status = item.FileActivity.Where(x => x.ActivityId == file.Id).Select(x => x.CurrentStatus).FirstOrDefault(),
                        UserName = item.FileActivity.Where(x => x.ActivityId == file.Id).Select(x => x.FileEntry.User.UserName).FirstOrDefault(),
                        Comment = item.FileActivity.Where(x => x.ActivityId == file.Id).Select(x => x.Comment).FirstOrDefault()
                    });
                }

            }

            DataTable dt = new DataTable();
            dt.Columns.Add("Received Date");
            dt.Columns.Add("FileNo");
            dt.Columns.Add("ContainerNo");
            dt.Columns.Add("IsEdi");
            dt.Columns.Add("Pol");
            dt.Columns.Add("Pod");
            dt.Columns.Add("FinalDestination");
            dt.Columns.Add("FileType");
            dt.Columns.Add("Hblcount");
            dt.Columns.Add("Cbm");
            dt.Columns.Add("CoLoader");
            dt.Columns.Add("SailingDate");
            dt.Columns.Add("EtaAtPod");
            dt.Columns.Add("VesselName");
            dt.Columns.Add("ShippingLine");
            dt.Columns.Add("ContactPerson");
            foreach (var item in _ctx.ActivityMaster.Where(x => x.BasedOn == "File" && x.IsActive == true && x.IsDelete == false).OrderBy(x => x.Sequence).ThenBy(x => x.Name))
            {
                dt.Columns.Add(item.Name + "_" + "Status");
                dt.Columns.Add(item.Name + "_" + "Date");
                dt.Columns.Add(item.Name + "_" + "UserName");
                dt.Columns.Add(item.Name + "_" + "Comment");
            }
            //foreach (var file in fileEntryViewModels)
            //{
            //    foreach (var item in fileActivity)
            //    {
            //        foreach (var dr in fileEntryData.Where(x => x.Activity == item.Name))
            //        {
            //            DataRow tr = dt.NewRow();
            //            tr[0] = file.FileNo;
            //            tr[1] = file.ContainerNo;
            //            tr[2] = file.IsEdi;
            //            tr[3] = file.Pol;
            //            tr[4] = file.Pod;
            //            tr[5] = file.FinalDestination;
            //            tr[6] = file.FileType;
            //            tr[7] = file.Hblcount;
            //            tr[8] = file.Cbm;
            //            tr[9] = file.CoLoader;
            //            tr[10] = file.SailingDate;
            //            tr[11] = file.EtaAtPod;
            //            tr[12] = file.VesselName;
            //            tr[13] = file.ShippingLine;
            //            tr[14] = file.ContactPerson;
            //            tr[item.Name + "_" + "Status"] = dr.Status;
            //            tr[item.Name + "_" + "Date"] = dr.Date;
            //            tr[item.Name + "_" + "UserName"] = dr.UserName;
            //            tr[item.Name + "_" + "Comment"] = dr.Comment;
            //            dt.Rows.Add(tr);
            //        }
            //    }
            //}

            foreach (var file in fileEntryViewModels)
            {
                // Create a new DataRow for each file
                DataRow tr = dt.NewRow();
                tr[0] = file.CreatedDate;
                tr[1] = file.FileNo;
                tr[2] = file.ContainerNo;
                tr[3] = file.IsEdi;
                tr[4] = file.Pol;
                tr[5] = file.Pod;
                tr[6] = file.FinalDestination;
                tr[7] = file.FileType;
                tr[8] = file.Hblcount;
                tr[9] = file.Cbm;
                tr[10] = file.CoLoader;
                tr[11] = file.SailingDate;
                tr[12] = file.EtaAtPod;
                tr[13] = file.VesselName;
                tr[14] = file.ShippingLine;
                tr[15] = file.ContactPerson;

                foreach (var item in fileActivity)
                {
                    foreach (var dr in fileEntryData.Where(x => x.Activity == item.Name && x.FileId == file.FileNo))
                    {
                        // Add activity data to the DataRow
                        tr[item.Name + "_" + "Status"] = dr.Status;
                        tr[item.Name + "_" + "Date"] = dr.Date;
                        tr[item.Name + "_" + "UserName"] = dr.UserName;
                        tr[item.Name + "_" + "Comment"] = dr.Comment;
                    }
                }

                // Add the DataRow to the DataTable
                dt.Rows.Add(tr);
            }




            using (XLWorkbook wb = new XLWorkbook())
            {
                dt.TableName = "Pre-Alert File Log";

                var wsFileData = wb.Worksheets.Add(dt);

                using (MemoryStream stream = new MemoryStream())
                {
                    wb.SaveAs(stream);
                    string excelname = $"FileActivityStatusReport-{DateTime.Now.ToString("ddmmyyyy hh:mm:ss")}.xlsx";
                    return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", excelname);
                }
            }
        }

        [HttpPost]
        public IActionResult PreAlertHBLDataDownload(string fileno, string type, string etadate, string container, string status, string thread, string user)
        {
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            int totalRecord = 0;
            int filterRecord = 0;
            var draw = Request.Form["draw"].FirstOrDefault();
            var sortColumn = Request.Form["columns[" + Request.Form["order[0][column]"].FirstOrDefault() + "][name]"].FirstOrDefault();
            var sortColumnDirection = Request.Form["order[0][dir]"].FirstOrDefault();
            var searchValue = Request.Form["search[value]"].FirstOrDefault();
            int pageSize = Convert.ToInt32(Request.Form["length"].FirstOrDefault() ?? "0");
            int skip = Convert.ToInt32(Request.Form["start"].FirstOrDefault() ?? "0");
            var HBLActivity = _ctx.ActivityMaster.Where(x => x.IsActive == true && x.IsDelete == false).OrderBy(x => x.Sequence).ThenBy(x => x.Name).ToList();
            _ctx.Database.SetCommandTimeout(300);
            IQueryable<HblEntry> data = _ctx.Set<HblEntry>().AsQueryable();

            totalRecord = data.Count();

            if (!string.IsNullOrEmpty(fileno))
            {
                data = data.Where(x => x.FileGuid.FileNo == fileno.Trim());

            }
            if (!string.IsNullOrEmpty(type) && type != "all" && type != "--select--")
            {
                data = data.Where(x => x.FileGuid.FileType == type.Trim());

            }
            if (!string.IsNullOrEmpty(etadate))
            {
                data = data.Where(x => x.FileGuid.EtaAtPod == Convert.ToDateTime(etadate));

            }

            if (!string.IsNullOrEmpty(container))
            {
                data = data.Where(x => x.FileGuid.ContainerNo == container.Trim());

            }

            if (!string.IsNullOrEmpty(user) && user != "none" && user != "--select--")
            {
                data = data.Where(x => x.CreatedBy == user.Trim());

            }

            if (!string.IsNullOrEmpty(status) && status != "none" && status != "--select--")
            {
                data = data.Where(x => x.FileGuid.Status == status.Trim());

            }

            if (searchValue == "WIP" || searchValue == "Completed" || searchValue == "Pending" || searchValue == "Query" ||
                        searchValue == "Received" || searchValue == "UnAllocated" || searchValue == "eta10" || searchValue == "eta12")
            {
                if (searchValue == "eta10")
                {
                    data = data.Where(x => x.FileGuid.EtaAtPod != null && Convert.ToDateTime(x.FileGuid.EtaAtPod).AddDays(-10) <= DateTime.Now && (x.FileGuid.Status != "Completed"));

                }
                else if (searchValue == "eta12")
                {
                    data = data.Where(x => x.FileGuid.EtaAtPod != null && Convert.ToDateTime(x.FileGuid.EtaAtPod).AddDays(-10) > DateTime.Now && Convert.ToDateTime(x.FileGuid.EtaAtPod).AddDays(-12) <= DateTime.Now && x.FileGuid.Status != "Completed");
                }

                else
                {
                    data = data.Where(x => x.FileGuid.Status == searchValue);
                }
            }
            var fileEntryData = new List<FileEntryData>();
            var HBLEntryViewModels = data.Include(x => x.HblActivity).ThenInclude(x => x.ActivityMaster.ThreadMaster).Select(x => new
            {
                FileNo = x.FileGuid.FileNo,
                ContainerNo = x.FileGuid.ContainerNo,
                Hblno = x.Hblno,
                IsDap = x.IsDap == true ? "Yes" : "No",
                CreatedBy = x.CreatedBy,
                CreatedDate = x.CreatedDate,
            }).ToList();


            var fileActivityList = _ctx.HblEntry.Include(x => x.User).Include(x => x.HblActivity).ThenInclude(x => x.ActivityMaster).Include(x => x.FileGuid).ToList();
            foreach (var hbl in HBLActivity)
            {
                foreach (var item in fileActivityList)
                {
                    fileEntryData.Add(new FileEntryData
                    {
                        FileId = item.FileGuid.FileNo,
                        HBLId = item.Hblno,
                        Activity = _ctx.ActivityMaster.Where(x => x.Id == hbl.Id && x.BasedOn == "HBL").Select(x => x.Name).FirstOrDefault(),
                        Date = item.HblActivity.Where(x => x.ActivityId == hbl.Id && x.HblEntry.Hblno == item.Hblno).Select(x => x.EndTime).FirstOrDefault(),
                        Status = item.HblActivity.Where(x => x.ActivityId == hbl.Id && x.HblEntry.Hblno == item.Hblno).Select(x => x.CurrentStatus).FirstOrDefault(),
                        UserName = item.HblActivity.Where(x => x.ActivityId == hbl.Id && x.HblEntry.Hblno == item.Hblno).Select(x => x.HblEntry.User.UserName).FirstOrDefault(),
                        Comment = item.HblActivity.Where(x => x.ActivityId == hbl.Id && x.HblEntry.Hblno == item.Hblno).Select(x => x.Comment).FirstOrDefault()
                    });
                }

            }

            DataTable dt = new DataTable();
            dt.Columns.Add("Received Date");
            dt.Columns.Add("FileNo");
            dt.Columns.Add("ContainerNo");
            dt.Columns.Add("Hblno");
            dt.Columns.Add("IsDap");
            dt.Columns.Add("CreatedBy");

            foreach (var item in _ctx.ActivityMaster.Where(x => x.BasedOn == "HBL" && x.IsActive == true && x.IsDelete == false).OrderBy( x=> x.Sequence))
            {
                dt.Columns.Add(item.Name + "_" + "Status");
                dt.Columns.Add(item.Name + "_" + "Date");
                dt.Columns.Add(item.Name + "_" + "UserName");
                dt.Columns.Add(item.Name + "_" + "Comment");
            }

            //foreach (var hbl in HBLEntryViewModels)
            //{
            //    DataRow tr = dt.NewRow();
            //    tr[0] = hbl.FileNo;
            //    tr[1] = hbl.ContainerNo;
            //    tr[2] = hbl.Hblno;
            //    tr[3] = hbl.IsDap;
            //    tr[4] = hbl.CreatedBy;
            //    tr[5] = hbl.CreatedDate;
            //    foreach (var item in HBLActivity)
            //    {
            //        foreach (var dr in fileEntryData.Where(x => x.Activity == item.Name && x.FileId == hbl.FileNo))
            //        {
            //            tr[item.Name + "_" + "Status"] = dr.Status;
            //            tr[item.Name + "_" + "Date"] = dr.Date;
            //            tr[item.Name + "_" + "UserName"] = dr.UserName;
            //            tr[item.Name + "_" + "Comment"] = dr.Comment;
            //        }
            //            dt.Rows.Add(tr);
            //    }
            //}

            foreach (var hbl in HBLEntryViewModels)
            {
                DataRow tr = dt.NewRow();
                tr[0] = hbl.CreatedDate;
                tr[1] = hbl.FileNo;
                tr[2] = hbl.ContainerNo;
                tr[3] = hbl.Hblno;
                tr[4] = hbl.IsDap;
                tr[5] = hbl.CreatedBy;

                foreach (var item in HBLActivity)
                {
                    var dr = fileEntryData.FirstOrDefault(x => x.Activity == item.Name && x.FileId == hbl.FileNo && x.HBLId == hbl.Hblno);

                    if (dr != null)
                    {
                        tr[item.Name + "_" + "Status"] = dr.Status;
                        tr[item.Name + "_" + "Date"] = dr.Date;
                        tr[item.Name + "_" + "UserName"] = dr.UserName;
                        tr[item.Name + "_" + "Comment"] = dr.Comment;
                    }
                }

                dt.Rows.Add(tr);
            }

            using (XLWorkbook wb = new XLWorkbook())
            {
                dt.TableName = "Pre-Alert HBL Log";

                var wsFileData = wb.Worksheets.Add(dt);

                using (MemoryStream stream = new MemoryStream())
                {
                    wb.SaveAs(stream);
                    string excelname = $"HBLActivityStatusReport-{DateTime.Now.ToString("ddmmyyyy hh:mm:ss")}.xlsx";
                    return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", excelname);
                }
            }
        }

        [HttpGet]
        public IActionResult UserActivityStatus([FromQuery(Name = "ThreadName")] string threadName, DateTime? StartDate, DateTime? EndDate)
        {
            return View();
        }

        [HttpPost]
        public IActionResult UserActivityStatusList(DateTime? StartDate, DateTime? EndDate)
        {
            if (Convert.ToDateTime(StartDate).Date == DateTime.Now.Date && Convert.ToDateTime(EndDate).Date == DateTime.Now.Date)
            {
                StartDate = null;
                EndDate = null;
            }
            UserActivityStatusViewModel userActivityStatus = new UserActivityStatusViewModel();
            var draw = Request.Form["draw"].FirstOrDefault();
            var sortColumn = Request.Form["columns[" + Request.Form["order[0][column]"].FirstOrDefault() + "][name]"].FirstOrDefault();
            var sortColumnDirection = Request.Form["order[0][dir]"].FirstOrDefault();
            int pageSize = Convert.ToInt32(Request.Form["length"].FirstOrDefault() ?? "0");
            int skip = Convert.ToInt32(Request.Form["start"].FirstOrDefault() ?? "0");
            var searchClick = Request.Form["columns[0][search][value]"].FirstOrDefault();
            var searchValue = Request.Form["search[value]"].FirstOrDefault();
            var fileActivity = _ctx.ActivityMaster.Where(x => x.IsActive == true && x.IsDelete == false).OrderBy(x => x.Sequence).ThenBy(x => x.Name).ToList();
            var hblActivity = _ctx.ActivityMaster.OrderBy(x => x.Sequence).ThenBy(x => x.Name).ToList();
            var userList = _ctx.User.Where(x => x.IsDelete == false && x.IsActive == true).ToList();
            _ctx.Database.SetCommandTimeout(300);
            if (StartDate != null && EndDate != null)
            {
                foreach (var user in userList)
                {
                    var getFileActivityStatus = new List<FileActivityStatusList>();
                    var getHBLActivityStatus = new List<HBLActivityStatusList>();
                    var fileActivityList = _ctx.FileActivity.Where(x => x.EnterDate.Value.Date >= StartDate.Value.Date && x.EnterDate.Value.Date <= EndDate.Value.Date).ToList();

                    foreach (var item in fileActivity)
                    {
                        getFileActivityStatus.Add(new FileActivityStatusList
                        {
                            Activity = _ctx.ActivityMaster.Where(x => x.Id == item.Id).Select(x => x.Name).FirstOrDefault(),
                            ActivityType = _ctx.ActivityMaster.Where(x => x.Id == item.Id).Select(x => x.BasedOn).FirstOrDefault(),
                            WIP = fileActivityList.Where(x => x.CurrentStatus == "WIP" && x.ActivityId == item.Id && x.UserId == user.Id).Count(),
                            Completed = fileActivityList.Where(x => x.CurrentStatus == "Completed" && x.ActivityId == item.Id && x.UserId == user.Id).Count(),
                            Pending = fileActivityList.Where(x => x.CurrentStatus == "Pending" && x.ActivityId == item.Id && x.UserId == user.Id).Count(),
                            Query = fileActivityList.Where(x => x.CurrentStatus == "Query" && x.ActivityId == item.Id && x.UserId == user.Id).Count(),
                            CompletedWithQuery = fileActivityList.Where(x => x.CurrentStatus == "Completed With Query" && x.ActivityId == item.Id && x.UserId == user.Id).Count(),
                            Total = fileActivityList.Where(x => x.ActivityId == item.Id && x.UserId == user.Id).Count(),

                        });
                    }

                    userActivityStatus.GetUserStatusList.Add(new UserStatusList
                    {
                        UserId = user.UserName,
                        WIP = fileActivityList.Where(x => x.CurrentStatus == "WIP" && x.UserId == user.Id).Count(),
                        Completed = fileActivityList.Where(x => x.CurrentStatus == "Completed" && x.UserId == user.Id).Count(),
                        Pending = fileActivityList.Where(x => x.CurrentStatus == "Pending" && x.UserId == user.Id).Count(),
                        Query = fileActivityList.Where(x => x.CurrentStatus == "Query" && x.UserId == user.Id).Count(),
                        CompletedWithQuery = fileActivityList.Where(x => x.CurrentStatus == "Completed With Query" && x.UserId == user.Id).Count(),
                        Total = fileActivityList.Where(x => x.UserId == user.Id).Count(),
                        GetFileActivityStatus = getFileActivityStatus,
                        GetHBLActivityStatus = getHBLActivityStatus
                    });
                }
                var totalrecords = userActivityStatus.GetUserStatusList.Count();
                var SortedData = userActivityStatus.GetUserStatusList.AsQueryable();

                if (!string.IsNullOrEmpty(sortColumn) && !string.IsNullOrEmpty(sortColumnDirection))
                {
                    if (sortColumn == "userName")
                    {
                        sortColumn = "userId";
                    }
                    SortedData = SortedData.OrderBy(sortColumn + " " + sortColumnDirection).AsQueryable();
                }
                var returnObj = new
                {
                    draw = draw,
                    recordsTotal = totalrecords,
                    recordsFiltered = SortedData.Count(),
                    data = SortedData,
                    skip = skip,
                    pageSize = pageSize,
                };
                return Json(returnObj);

            }
            else
            {

                foreach (var user in userList)
                {
                    var getFileActivityStatus = new List<FileActivityStatusList>();
                    var getHBLActivityStatus = new List<HBLActivityStatusList>();


                    foreach (var item in fileActivity)
                    {
                        getFileActivityStatus.Add(new FileActivityStatusList
                        {
                            Activity = _ctx.ActivityMaster.Where(x => x.Id == item.Id).Select(x => x.Name).FirstOrDefault(),
                            ActivityType = _ctx.ActivityMaster.Where(x => x.Id == item.Id).Select(x => x.BasedOn).FirstOrDefault(),
                            WIP = _ctx.FileActivity.Where(x => x.CurrentStatus == "WIP" && x.ActivityId == item.Id && x.UserId == user.Id).Count(),
                            Completed = _ctx.FileActivity.Where(x => x.CurrentStatus == "Completed" && x.ActivityId == item.Id && x.UserId == user.Id).Count(),
                            Pending = _ctx.FileActivity.Where(x => x.CurrentStatus == "Pending" && x.ActivityId == item.Id && x.UserId == user.Id).Count(),
                            Query = _ctx.FileActivity.Where(x => x.CurrentStatus == "Query" && x.ActivityId == item.Id && x.UserId == user.Id).Count(),
                            CompletedWithQuery = _ctx.FileActivity.Where(x => x.CurrentStatus == "Completed With Query" && x.ActivityId == item.Id && x.UserId == user.Id).Count(),
                            Total = _ctx.FileActivity.Where(x => x.ActivityId == item.Id && x.UserId == user.Id).Count(),
                        });

                    }
                    userActivityStatus.GetUserStatusList.Add(new UserStatusList
                    {
                        UserId = user.UserName,
                        WIP = _ctx.FileActivity.Where(x => x.CurrentStatus == "WIP" && x.UserId == user.Id).Count(),
                        Completed = _ctx.FileActivity.Where(x => x.CurrentStatus == "Completed" && x.UserId == user.Id).Count(),
                        Pending = _ctx.FileActivity.Where(x => x.CurrentStatus == "Pending" && x.UserId == user.Id).Count(),
                        Query = _ctx.FileActivity.Where(x => x.CurrentStatus == "Query" && x.UserId == user.Id).Count(),
                        CompletedWithQuery = _ctx.FileActivity.Where(x => x.CurrentStatus == "Completed With Query" && x.UserId == user.Id).Count(),
                        Total = _ctx.FileActivity.Where(x => x.UserId == user.Id).Count(),
                        GetFileActivityStatus = getFileActivityStatus,
                        GetHBLActivityStatus = getHBLActivityStatus
                    });
                }
                var totalrecords = userActivityStatus.GetUserStatusList.Count();
                var SortedData = userActivityStatus.GetUserStatusList.AsQueryable();
                if (!string.IsNullOrEmpty(sortColumn) && !string.IsNullOrEmpty(sortColumnDirection))
                {
                    if (sortColumn == "userName")
                    {
                        sortColumn = "userId";
                    }
                    SortedData = SortedData.OrderBy(sortColumn + " " + sortColumnDirection).AsQueryable();
                }
                var returnObj = new
                {
                    draw = draw,
                    recordsTotal = totalrecords,
                    recordsFiltered = SortedData.Count(),
                    data = SortedData,
                    skip = skip,
                    pageSize = pageSize,
                };
                return Json(returnObj);
            }

        }

        [HttpPost]
        public IActionResult UserDataDownload(DateTime? StartDate, DateTime? EndDate)
        {
            UserActivityStatusViewModel userActivityStatus = new UserActivityStatusViewModel();
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            var fileActivity = _ctx.ActivityMaster.Where(x => x.IsActive == true && x.IsDelete == false).OrderBy(x => x.Sequence).ThenBy(x => x.Name).ToList();
            var hblActivity = _ctx.ActivityMaster.Where(x => x.IsActive == true && x.IsDelete == false).OrderBy(x => x.Sequence).ThenBy(x => x.Name).ToList();
            var userList = _ctx.User.Where(x => x.IsActive == true && x.IsDelete == false).ToList();
            _ctx.Database.SetCommandTimeout(300);
            if (Convert.ToDateTime(StartDate).Date == DateTime.Now.Date && Convert.ToDateTime(EndDate).Date == DateTime.Now.Date)
            {
                StartDate = null;
                EndDate = null;
            }
            if (StartDate != null && EndDate != null)
            {
                foreach (var user in userList)
                {
                    var getFileActivityStatus = new List<FileActivityStatusList>();
                    var getHBLActivityStatus = new List<HBLActivityStatusList>();
                    var fileActivityList = _ctx.FileActivity.Where(x => x.EnterDate.Value.Date >= StartDate.Value.Date && x.EnterDate.Value.Date <= EndDate.Value.Date).ToList();

                    foreach (var item in fileActivity)
                    {
                        getFileActivityStatus.Add(new FileActivityStatusList
                        {
                            Activity = _ctx.ActivityMaster.Where(x => x.Id == item.Id && x.IsActive == true && x.IsDelete == false).Select(x => x.Name).FirstOrDefault(),
                            ActivityType = _ctx.ActivityMaster.Where(x => x.Id == item.Id && x.IsActive == true && x.IsDelete == false).Select(x => x.BasedOn).FirstOrDefault(),
                            WIP = fileActivityList.Where(x => x.CurrentStatus == "WIP" && x.ActivityId == item.Id && x.UserId == user.Id).Count(),
                            Completed = fileActivityList.Where(x => x.CurrentStatus == "Completed" && x.ActivityId == item.Id && x.UserId == user.Id).Count(),
                            Pending = fileActivityList.Where(x => x.CurrentStatus == "Pending" && x.ActivityId == item.Id && x.UserId == user.Id).Count(),
                            Query = fileActivityList.Where(x => x.CurrentStatus == "Query" && x.ActivityId == item.Id && x.UserId == user.Id).Count(),
                            CompletedWithQuery = fileActivityList.Where(x => x.CurrentStatus == "Completed With Query" && x.ActivityId == item.Id && x.UserId == user.Id).Count(),
                            Total = fileActivityList.Where(x => x.ActivityId == item.Id && x.UserId == user.Id).Count(),

                        });
                    }

                    userActivityStatus.GetUserStatusList.Add(new UserStatusList
                    {
                        UserId = user.UserName,
                        WIP = fileActivityList.Where(x => x.CurrentStatus == "WIP" && x.UserId == user.Id).Count(),
                        Completed = fileActivityList.Where(x => x.CurrentStatus == "Completed" && x.UserId == user.Id).Count(),
                        Pending = fileActivityList.Where(x => x.CurrentStatus == "Pending" && x.UserId == user.Id).Count(),
                        Query = fileActivityList.Where(x => x.CurrentStatus == "Query" && x.UserId == user.Id).Count(),
                        CompletedWithQuery = fileActivityList.Where(x => x.CurrentStatus == "Completed With Query" && x.UserId == user.Id).Count(),
                        Total = fileActivityList.Where(x => x.UserId == user.Id).Count(),
                        GetFileActivityStatus = getFileActivityStatus,
                        GetHBLActivityStatus = getHBLActivityStatus
                    });
                }
            }
            else
            {

                foreach (var user in userList)
                {
                    var getFileActivityStatus = new List<FileActivityStatusList>();
                    var getHBLActivityStatus = new List<HBLActivityStatusList>();


                    foreach (var item in fileActivity)
                    {
                        getFileActivityStatus.Add(new FileActivityStatusList
                        {
                            Activity = _ctx.ActivityMaster.Where(x => x.Id == item.Id && x.IsActive == true && x.IsDelete == false).Select(x => x.Name).FirstOrDefault(),
                            ActivityType = _ctx.ActivityMaster.Where(x => x.Id == item.Id && x.IsActive == true && x.IsDelete == false).Select(x => x.BasedOn).FirstOrDefault(),
                            WIP = _ctx.FileActivity.Where(x => x.CurrentStatus == "WIP" && x.ActivityId == item.Id && x.UserId == user.Id).Count(),
                            Completed = _ctx.FileActivity.Where(x => x.CurrentStatus == "Completed" && x.ActivityId == item.Id && x.UserId == user.Id).Count(),
                            Pending = _ctx.FileActivity.Where(x => x.CurrentStatus == "Pending" && x.ActivityId == item.Id && x.UserId == user.Id).Count(),
                            Query = _ctx.FileActivity.Where(x => x.CurrentStatus == "Query" && x.ActivityId == item.Id && x.UserId == user.Id).Count(),
                            CompletedWithQuery = _ctx.FileActivity.Where(x => x.CurrentStatus == "Completed With Query" && x.ActivityId == item.Id && x.UserId == user.Id).Count(),
                            Total = _ctx.FileActivity.Where(x => x.ActivityId == item.Id && x.UserId == user.Id).Count(),
                        });

                    }
                    userActivityStatus.GetUserStatusList.Add(new UserStatusList
                    {
                        UserId = user.UserName,
                        WIP = _ctx.FileActivity.Where(x => x.CurrentStatus == "WIP" && x.UserId == user.Id).Count(),
                        Completed = _ctx.FileActivity.Where(x => x.CurrentStatus == "Completed" && x.UserId == user.Id).Count(),
                        Pending = _ctx.FileActivity.Where(x => x.CurrentStatus == "Pending" && x.UserId == user.Id).Count(),
                        Query = _ctx.FileActivity.Where(x => x.CurrentStatus == "Query" && x.UserId == user.Id).Count(),
                        CompletedWithQuery = _ctx.FileActivity.Where(x => x.CurrentStatus == "Completed With Query" && x.UserId == user.Id).Count(),
                        Total = _ctx.FileActivity.Where(x => x.UserId == user.Id).Count(),
                        GetFileActivityStatus = getFileActivityStatus,
                        GetHBLActivityStatus = getHBLActivityStatus
                    });
                }
            }

            var fileStatus = userActivityStatus.GetUserStatusList.Select(x => new UserStatusList
            {
                UserId = x.UserId,
                Total = x.Total,
                WIP = x.WIP,
                Query = x.Query,
                Pending = x.Pending,
                Completed = x.Completed,
                CompletedWithQuery = x.CompletedWithQuery,
                GetFileActivityStatus = x.GetFileActivityStatus

            }).ToList();

            DataTable FileActivityStatus = ToDataTable(fileStatus);

            DataTable dt = new DataTable();
            dt.Columns.Add("Username");
            dt.Columns.Add("Activity");
            dt.Columns.Add("ActivityType");
            dt.Columns.Add("Total");
            dt.Columns.Add("Completed");
            dt.Columns.Add("CompletedWithQuery");
            dt.Columns.Add("Pending");
            dt.Columns.Add("Query");
            dt.Columns.Add("WIP");



            foreach (var dr in fileStatus)
            {
                foreach (var file in dr.GetFileActivityStatus)
                {
                    DataRow tr = dt.NewRow();
                    tr[0] = dr.UserId;
                    tr[0] = dr.UserId;
                    tr[1] = file.Activity;
                    tr[2] = file.ActivityType;
                    tr[3] = file.Total;
                    tr[4] = file.Completed;
                    tr[5] = file.CompletedWithQuery;
                    tr[6] = file.Pending;
                    tr[7] = file.Query;
                    tr[8] = file.WIP;
                    dt.Rows.Add(tr);
                }
            }

            using (XLWorkbook wb = new XLWorkbook())
            {
                dt.TableName = "User Activity Status";
                var wsData = wb.Worksheets.Add(dt);
                using (MemoryStream stream = new MemoryStream())
                {
                    wb.SaveAs(stream);
                    string excelname = $"UserActivityStatus-{DateTime.UtcNow.ToString("ddmmyyyy hh:mm:ss")}.xlsx";
                    return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", excelname);
                }
            }
        }

        [HttpGet]
        public IActionResult GetActivityFileData()
        {
            ViewData["ActivityMaster"] = _ctx.ActivityMaster.Where(x => x.IsActive == true && x.IsDelete == false).OrderBy(x => x.Sequence).ThenBy(x => x.Name).ToList();

            return View();
        }

        [HttpPost]
        public IActionResult GetActivityFileData(string activity, string activityType, string status)
        {
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            int totalRecord = 0;
            int filterRecord = 0;
            int hblrecord = 0;
            var draw = Request.Form["draw"].FirstOrDefault();
            var sortColumn = Request.Form["columns[" + Request.Form["order[0][column]"].FirstOrDefault() + "][name]"].FirstOrDefault();
            var sortColumnDirection = Request.Form["order[0][dir]"].FirstOrDefault();
            var searchValue = Request.Form["search[value]"].FirstOrDefault();
            int pageSize = Convert.ToInt32(Request.Form["length"].FirstOrDefault() ?? "0");
            int skip = Convert.ToInt32(Request.Form["start"].FirstOrDefault() ?? "0");
            var fileEntryData = new List<FileActivityDataList>();
            _ctx.Database.SetCommandTimeout(300);
            if (activityType == "HBL")
            {
                fileEntryData = _ctx.HblActivity.Include(x => x.ActivityMaster).Include(x => x.HblEntry).ThenInclude(x => x.FileGuid).ThenInclude(x => x.FileActivity).Select(x => new FileActivityDataList
                {
                    ActivityId = x.ActivityMaster.Name,
                    BasedOn = x.ActivityMaster.BasedOn,
                    Comment = x.Comment,
                    CurrentStatus = x.CurrentStatus,
                    EndTime = x.EndTime,
                    EnterDate = x.EnterDate,
                    FileNo = x.HblEntry.FileGuid.FileNo,
                    ContainerNo = x.HblEntry.FileGuid.ContainerNo,
                    hblNo = x.HblEntry.Hblno,
                    Id = x.HblEntry.FileGuid.Id,
                    UserId = x.User.UserName,
                    hblCount = x.HblEntry.FileGuid.Hblcount,
                    StartTime = x.StartTime

                }).Skip(skip * pageSize).Take(pageSize == -1 ? 100 : pageSize).ToList();

            }
            else
            {
                fileEntryData = _ctx.FileActivity.Include(x => x.ActivityMaster).Include(x => x.FileEntry).ThenInclude(x => x.User).Select(x => new FileActivityDataList
                {
                    ActivityId = x.ActivityMaster.Name,
                    BasedOn = x.ActivityMaster.BasedOn,
                    Comment = x.Comment,
                    CurrentStatus = x.CurrentStatus,
                    EndTime = x.EndTime,
                    EnterDate = x.EnterDate,
                    FileNo = x.FileEntry.FileNo,
                    ContainerNo = x.FileEntry.ContainerNo,
                    Id = x.FileId,
                    UserId = x.FileEntry.User.UserName,
                    hblCount = x.FileEntry.Hblcount,
                    StartTime = x.StartTime

                }).Skip(skip * pageSize).Take(pageSize == -1 ? 100 : pageSize).ToList();
            }
            totalRecord = fileEntryData.Count();
            IQueryable<FileActivityDataList> SortedData = fileEntryData.Distinct().AsQueryable();

            if (!string.IsNullOrEmpty(activityType) && activityType != "all" && activityType != "--select--")
            {
                SortedData = SortedData.Where(x => x.BasedOn == activityType.Trim());

            }
            if (!string.IsNullOrEmpty(activity) && activity != "none" && activity != "--Select--")
            {
                SortedData = SortedData.Where(x => x.ActivityId == activity.Trim());

            }
            if (!string.IsNullOrEmpty(status) && status != "none" && status != "--select--")
            {
                SortedData = SortedData.Where(x => x.CurrentStatus == status.Trim());

            }
            else
            {
                SortedData = SortedData.Where(x => x.CurrentStatus != "Completed".Trim());
            }
            if (!string.IsNullOrEmpty(sortColumn) && !string.IsNullOrEmpty(sortColumnDirection))
            {
                SortedData = SortedData.OrderBy(sortColumn + " " + sortColumnDirection).AsQueryable();
            }
            else
            {
                sortColumn = "fileNo";
                SortedData = SortedData.OrderBy(sortColumn + " " + sortColumnDirection).AsQueryable();
            }
            var returnObj = new
            {
                draw = draw,
                recordsTotal = totalRecord,
                recordsFiltered = SortedData.Count(),
                data = SortedData,
            };

            return Json(returnObj);
        }


        public IActionResult GetActivityHBLData(string fileNo, string activityId, string status)
        {
            var fileId = _ctx.FileEntry.Where(x => x.FileNo == fileNo).Select(x => x.Id).FirstOrDefault();
            _ctx.Database.SetCommandTimeout(300);
            var hblEntry = (from FE in _ctx.FileEntry
                            join HE in _ctx.HblEntry on FE.Id equals HE.FileGuidId
                            join hbl in _ctx.HblActivity on HE.Id equals hbl.HblId
                            select new HBLActivityDataList
                            {
                                Id = HE.Id,
                                Hblno = HE.Hblno,
                                FileGuidId = HE.FileGuidId,
                                IsDap = HE.IsDap == true? "Yes":"No",
                                CreatedDate = HE.CreatedDate,
                                BasedOn = _ctx.ActivityMaster.Where(y => y.Id == hbl.ActivityId).Select(x => x.BasedOn).FirstOrDefault(),
                                CreatedBy = _ctx.User.Where(y => y.Id == HE.CreatedBy).Select(y => y.UserName).FirstOrDefault(),
                                Comment = hbl.Comment,
                                CurrentStatus = hbl.CurrentStatus,
                                StartTime = hbl.StartTime,
                                EndTime = hbl.EndTime,
                                EnterBy = hbl.EnterBy,
                                ActivityId = _ctx.HblActivity.Where(y => y.ActivityId == hbl.ActivityId).Select(y => y.ActivityMaster.Name).FirstOrDefault(),
                            }).ToList();

            if (activityId == "File Processing Status")
            {
                hblEntry = hblEntry.Where(x => x.FileGuidId == fileId && x.ActivityId == "HBL Status").ToList();
            }
            else
            {
                hblEntry = hblEntry.Where(x => x.FileGuidId == fileId && x.ActivityId == activityId).ToList();
            }
            if (!string.IsNullOrEmpty(status) && status != "none" && status != "--Select--")
            {
                hblEntry = hblEntry.Where(x => x.CurrentStatus == status.Trim()).ToList();

            }
            else
            {
                hblEntry = hblEntry.Where(x => x.CurrentStatus != "Completed").ToList();
            }
            
            return Json(hblEntry);
        }

        [HttpGet]
        public IActionResult GetHblActivityData(string hblId)
        {
            _ctx.Database.SetCommandTimeout(300);
            ViewData["hblActivityList"] = _ctx.HblActivity.Where(x => x.HblId == hblId).Select(x => new HBLActivityDataList
            {
                Id = x.Id,
                Hblno = x.HblEntry.Hblno == null ? "" : x.HblEntry.Hblno,
                ActivityId = x.ActivityMaster.Name,
                EndTime = x.EndTime,
                CurrentStatus = x.CurrentStatus,
                Comment = x.Comment == null ? "" : x.Comment,
                EnterBy = x.User.CitrixId == null ? "" : x.User.CitrixId
            }).ToList();
            return PartialView();
        }

        [HttpPost]
        public IActionResult GetHblActivityData(string hblno, string hbl)
        {
            var hblact = _ctx.HblActivity.Include(x => x.HblEntry).Include(x => x.ActivityMaster).Include(x => x.User).Where(x => x.HblEntry.Hblno == hblno).ToList();
            _ctx.Database.SetCommandTimeout(300);
            List<HBLActivityDataList> hblActivityLog = new List<HBLActivityDataList>();
            foreach (var item in hblact)
            {
                hblActivityLog.Add(new HBLActivityDataList
                {
                    Hblno = hblno == null ? "" : hblno,
                    ActivityId = item.ActivityMaster.Name == null ? "" : item.ActivityMaster.Name,
                    EndTime =item.EndTime,
                    CurrentStatus = item.CurrentStatus,
                    EnterBy = item.User.CitrixId,

                });
            }
            return Json(hblActivityLog);
        }
        public IActionResult GetActivityType(string fileType)
        {

            ViewData["ActivityMaster"] = _ctx.ActivityMaster.Where(x => x.BasedOn == fileType && x.IsActive == true && x.IsDelete == false).OrderBy(x => x.Sequence).ThenBy(x => x.Name).ToList();
            var activity = _ctx.ActivityMaster.Where(x => x.BasedOn == fileType && x.IsActive == true && x.IsDelete == false).OrderBy(x => x.Sequence).ThenBy(x => x.Name).ToList();

            return Json(activity);
        }

        [HttpPost]
        public IActionResult HBLSubmit(HBLActivityDataList model, string fileType, string activityId, string status, DateTime startDate)
        {
            var activity = _ctx.ActivityMaster.Where(x => x.BasedOn == fileType && x.IsDelete == false && x.IsActive == true).OrderBy(x => x.Sequence).ThenBy(x => x.Name).ToList();
            var hblId = _ctx.HblEntry.Where(x => x.Hblno == model.Hblno).Select(x => x.Id).FirstOrDefault();
            var hblActivityId = _ctx.HblActivity.Where(x => x.HblId == hblId).Select(x => x.Id).FirstOrDefault();
            HblActivity hblActivity = _ctx.HblActivity.Where(x => x.Id == model.Id.Trim()).FirstOrDefault();
            _ctx.Database.SetCommandTimeout(300);
            var hblActivityList = _ctx.HblActivity.Where(x => x.HblEntry.FileGuidId == model.FileGuidId).ToList();
            if (fileType == "HBL")
            {
                var hbllog = _ctx.HBLHistoryLog.Add(new HBLHistoryLog               
                {

                    HBLActivityId = hblActivityId,
                    CurrentStatus = model.CurrentStatus,
                    Comment = model.Comment,
                    EnterBy = model.EnterBy,
                    StartTime = startDate,
                    EndTime = model.EndTime,
                    EnterDate = model.CreatedDate,

                });
                _ctx.SaveChanges();

                hblActivity.CurrentStatus = model.CurrentStatus;
                hblActivity.Comment = model.Comment;
                hblActivity.StartTime = startDate;
                hblActivity.EndTime = DateTime.Now.ToUniversalTime();
                _ctx.HblActivity.Update(hblActivity);
                _ctx.SaveChanges();

                if (model.FileGuidId != null)
                {
                    if (hblActivityList != null)
                    {
                        foreach (var hbl in hblActivityList)
                        {
                            var hblStatus = hblActivityList.Where(x => x.CurrentStatus != "Completed").Count();
                            if (hblStatus == 0)
                            {
                                var fileActivity = _ctx.FileActivity.Where(x => x.FileId == model.FileGuidId).FirstOrDefault();
                                fileActivity.CurrentStatus = model.CurrentStatus;
                                fileActivity.Comment = "All Hbl in this file are completed.";
                                fileActivity.StartTime = startDate;
                                fileActivity.EndTime = DateTime.Now.ToUniversalTime();
                                _ctx.FileActivity.Update(fileActivity);
                                _ctx.SaveChanges();
                            }
                        }
                    }

                }
                return Json("Success");
            }
            else
            {
                return Json("Failed");

            }
        }

        [HttpPost]
        public JsonResult UpdateData(string? columnName, string? editedValue, string? containerId, string? fileId, string? fileActivityLogId, string? startDateTime)
        {

            //var file = _context.FileMaster.Where(x => x.Id == fileId).FirstOrDefault();
            //var container = _context.ContainerMaster.Where(x => x.Id == containerId).FirstOrDefault();
            var file = _ctx.FileEntry.Where(x => x.Id == fileId).FirstOrDefault();
            DateTime date = Convert.ToDateTime(startDateTime).ToUniversalTime();
            var fileList = _ctx.FileEntry.ToList();


            //_context.FileAcitivityLogHistory.Add(new FileAcitivityLogHistory
            //{
            //    FileLogId = fileActivityLogId,
            //    ActivityId = fileLog.ActivityId,
            //    StatusId = fileLog.StatusId,
            //    UserId = fileLog.UserId,
            //    StartDate = fileLog.StartDate,
            //    EndDate = fileLog.EndDate,
            //    Comment = fileLog.Comment,
            //    Roe = fileLog.Roe
            //});
            //_context.SaveChanges();
            if (columnName == "sailingDate")
            {
                DateTime dateTime = Convert.ToDateTime(editedValue).ToUniversalTime();
                file.SailingDate = dateTime;
                //fileLog.StartDate = date;
                //fileLog.EndDate = DateTime.UtcNow;
                _ctx.FileEntry.Update(file);
                //_ctx.FileActivityLog.Update(fileLog);
            }
            else if (columnName == "etaAtPod")
            {
                DateTime dateTime = Convert.ToDateTime(editedValue).ToUniversalTime();
                file.EtaAtPod = dateTime;
                //fileLog.StartDate = date;
                //fileLog.EndDate = DateTime.UtcNow;
                _ctx.FileEntry.Update(file);
                //_ctx.FileActivityLog.Update(fileLog);
            }
            else if (columnName == "containerNo")
            {
                fileList = fileList.Where(x => x.FileNo == file.FileNo && x.ContainerNo == editedValue).ToList();
                if (fileList.Count() != 0)
                {
                    return Json("Duplicate Container in Same File.");
                }
                else
                {
                    //DateTime dateTime = Convert.ToDateTime(editedValue).ToUniversalTime();
                    file.ContainerNo = editedValue;
                    //fileLog.StartDate = date;
                    //fileLog.EndDate = DateTime.UtcNow;
                    _ctx.FileEntry.Update(file);
                    //_ctx.FileActivityLog.Update(fileLog);
                }
            }
            else if (columnName == "etaAtFD")
            {
                DateTime dateTime = Convert.ToDateTime(editedValue).ToUniversalTime();
                file.EtaAtFD = dateTime;
                //fileLog.StartDate = date;
                //fileLog.EndDate = DateTime.UtcNow;
                _ctx.FileEntry.Update(file);
                //_ctx.FileActivityLog.Update(fileLog);
            }
            else if (columnName == "fileNo")
            {
                fileList = fileList.Where(x => x.FileNo == editedValue).ToList();
                if (fileList.Count() != 0)
                {
                    return Json("Duplicate File.");
                }
                else
                {
                    //DateTime dateTime = Convert.ToDateTime(editedValue).ToUniversalTime();
                    file.FileNo = editedValue;
                    //fileLog.StartDate = date;
                    //fileLog.EndDate = DateTime.UtcNow;
                    _ctx.FileEntry.Update(file);
                    //_ctx.FileActivityLog.Update(fileLog);
                }
            }
            else if (columnName == "pod")
            {
                var locationId = _ctx.LocationMaster.Where(x => x.Name == editedValue).Select(x => x.Id).FirstOrDefault();
                file.Pod = locationId;
                //fileLog.StartDate = date;
                //fileLog.EndDate = DateTime.UtcNow;
                _ctx.FileEntry.Update(file);
                //_ctx.FileActivityLog.Update(fileLog);
            }
            else if (columnName == "pol")
            {
                //DateTime dateTime = Convert.ToDateTime(editedValue).ToUniversalTime();
                file.Pol = editedValue;
                //fileLog.StartDate = date;
                //fileLog.EndDate = DateTime.UtcNow;
                _ctx.FileEntry.Update(file);
                //_ctx.FileActivityLog.Update(fileLog);
            }
            else if (columnName == "finalDestination")
            {
                //DateTime dateTime = Convert.ToDateTime(editedValue).ToUniversalTime();
                file.FinalDestination = editedValue;
                //fileLog.StartDate = date;
                //fileLog.EndDate = DateTime.UtcNow;
                _ctx.FileEntry.Update(file);
                //_ctx.FileActivityLog.Update(fileLog);
            }
            _ctx.SaveChanges();
            return Json("Success");

        }
        public JsonResult UpdateIsLDAP(string Id)
        {
            string message = "";
            if (Id != null)
            {
                User master = _ctx.Users.Where(x => x.CitrixId.ToLower() == Id.ToLower()).FirstOrDefault();
                if (master != null)
                {
                    //master.IsActive = master.IsActive != null ? !master.IsActive : true;
                    master.IsLDAP = master.IsLDAP != null ? !master.IsLDAP : true;
                    _ctx.Users.Update(master);
                    _ctx.SaveChanges();
                    message = master.IsLDAP == true ? master.UserName + " LDAP Active!" : master.UserName + " LDAP InActive!";

                }
                else
                {
                    message = "Error in Activation.!";
                }
            }
            return Json(message);
        }

        //public JsonResult UpdateIsReset(string Id)
        //{
        //    string message = "";
        //    User master = _ctx.Users.Where(x => x.CitrixId.ToLower() == Id.ToLower()).FirstOrDefault();
        //    if (Id != null)
        //    {
        //        if (master != null)
        //        {
        //            //master.IsActive = master.IsActive != null ? !master.IsActive : true;
        //            master.IsReset = master.IsReset != null ? !master.IsReset : true;
        //            _ctx.Users.Update(master);
        //            _ctx.SaveChanges();
        //            message = master.IsReset == true ? master.UserName + " Password Unset!" : master.UserName + " Password Reset!";

        //        }
        //        else
        //        {
        //            message = "Error in Activation.!";
        //        }
        //    }
        //    return Json(new { Message = message, UserName = master.UserName, CitrixId = master.CitrixId, UserId = master.Id });
        //}

        public JsonResult ActivateThread(string Id)
        {
            string message = "";
            if (Id != null)
            {
                ThreadMaster master = _ctx.ThreadMaster.Where(x => x.Id.ToLower() == Id.ToLower()).FirstOrDefault();
                if (master != null)
                {
                    //master.IsActive = master.IsActive != null ? !master.IsActive : true;
                    master.IsActive = master.IsActive != null ? !master.IsActive : true;
                    _ctx.ThreadMaster.Update(master);
                    _ctx.SaveChanges();
                    message = master.IsActive == true ? master.Name + " Thread Active!" : master.Name + " Thread InActive!";

                }
                else
                {
                    message = "Error in Activation.!";
                }
            }
            return Json(message);
        }

        public JsonResult ActivateActivity(string Id)
        {
            string message = "";
            if (Id != null)
            {
                ActivityMaster master = _ctx.ActivityMaster.Where(x => x.Id.ToLower() == Id.ToLower()).FirstOrDefault();
                if (master != null)
                {
                    //master.IsActive = master.IsActive != null ? !master.IsActive : true;
                    master.IsActive = master.IsActive != null ? !master.IsActive : true;
                    _ctx.ActivityMaster.Update(master);
                    _ctx.SaveChanges();
                    message = master.IsActive == true ? master.Name + " Activity Active!" : master.Name + " Activity InActive!";

                }
                else
                {
                    message = "Error in Activation.!";
                }
            }
            return Json(message);
        }

        [Authorize(Roles = "Supervisor,Manager,Admin")]
        public ActionResult Reports()
        {
            return View();
        }

        public JsonResult ActivateUser(string Id)
        {
            string message = "";
            if (Id != null)
            {
                User master = _ctx.User.Where(x => x.CitrixId.ToLower() == Id.ToLower()).FirstOrDefault();
                if (master != null)
                {
                    //master.IsActive = master.IsActive != null ? !master.IsActive : true;
                    master.IsActive = master.IsActive != null ? !master.IsActive : true;
                    _ctx.User.Update(master);
                    _ctx.SaveChanges();
                    message = master.IsActive == true ? master.CitrixId + " User Active!" : master.CitrixId + " User InActive!";

                }
                else
                {
                    message = "Error in Activation.!";
                }
            }
            return Json(message);
        }
        public JsonResult DeleteUser(string Id)
        {
            string message = "";
            if (Id != null)
            {
                User master = _ctx.User.Where(x => x.CitrixId.ToLower() == Id.ToLower()).FirstOrDefault();
                if (master != null)
                {
                    //master.IsActive = master.IsActive != null ? !master.IsActive : true;
                    master.IsDelete = master.IsDelete != null ? !master.IsDelete : true;
                    _ctx.User.Update(master);
                    _ctx.SaveChanges();
                    message = master.IsDelete == true ? master.CitrixId + " User Delete!" : master.CitrixId + " User Restore!";

                }
                else
                {
                    message = "Error in Activation.!";
                }
            }
            return Json(message);
        }

        public JsonResult UpdateIsReset(string Id)
        {
            string message = "";
            User master = _ctx.Users.Where(x => x.CitrixId.ToLower() == Id.ToLower()).FirstOrDefault();
            if (Id != null)
            {
                if (master != null)
                {
                    //master.IsActive = master.IsActive != null ? !master.IsActive : true;
                    master.IsReset = master.IsReset != null ? !master.IsReset : true;
                    _ctx.Users.Update(master);
                    _ctx.SaveChanges();
                    message = master.IsReset == true ? master.UserName + " Password Unset!" : master.UserName + " Password Reset!";

                }
                else
                {
                    message = "Error in Activation.!";
                }
            }
            return Json(new { Message = message, UserName = master.UserName, CitrixId = master.CitrixId, UserId = master.Id });
        }


        ////Report download
        //[HttpPost]
        //public ActionResult Reports(ReportViewModel report)
        //{
        //    //Main Report file and HBL also activity wise filelevel and hbllevel report
        //    //DataTable filedt = new DataTable();
        //    DataTable fileactivity = new DataTable();
        //    DataTable hblactivity = new DataTable();
        //    var fileactivtydata = new List<FileReportViewModel>();
        //    var fileactivtyHistory = new List<FileReportViewModel>();
        //    var HBLdata = new List<HBLReportViewModel>();
        //    var HBLHistory = new List<HBLReportViewModel>();
        //    var getFileActivityStatus = new List<FileActivityStatusList>();
        //    var getHBLActivityStatus = new List<HBLActivityStatusList>();
        //    //var fileActivityList = new List<FileActivityLog>();
        //    UserActivityStatusViewModel userActivityStatus = new UserActivityStatusViewModel();
        //    //var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
        //    var fileActivitys = _ctx.ActivityMaster.Include(x => x.ThreadMaster).Where(x => x.IsActive == true && x.ThreadMaster.Name == "File").OrderBy(x => x.Sequence).ThenBy(x => x.Name).ToList();
        //    var hblActivitys = _ctx.ActivityMaster.Include(x => x.ThreadMaster).Where(x => x.IsActive == true && x.ThreadMaster.Name == "HBL").OrderBy(x => x.Sequence).ThenBy(x => x.Name).ToList();
        //    _ctx.Database.SetCommandTimeout(300);
        //    var userList = _ctx.User.Where(x => x.IsActive == true && x.IsDelete == false).OrderBy(x => x.CitrixId).ToList();
        //    //Adhoc Report 
        //    DataTable adhoc = new DataTable();
        //    DataTable adhocHBL = new DataTable();
        //    DataTable adhocfileActivity = new DataTable();
        //    DataTable adhochblActivity = new DataTable();
        //    var startDate = report.start_date;
        //    var endDate = report.end_date;
        //    IQueryable<User> udata = _ctx.Set<User>().AsQueryable();
        //    DataTable dt = new DataTable();
        //    DataTable dt1 = new DataTable();
        //    const string ISTTimeZoneId = "India Standard Time";
        //    var istTimeZone = TimeZoneInfo.FindSystemTimeZoneById(ISTTimeZoneId);


        //    if (report.start_date != null && report.end_date != null)
        //    {
        //        if (report.ReportType == "File")
        //        {
        //            //DataTable dt = new DataTable();
        //            dt.Columns.Add("Received Date");
        //            dt.Columns.Add("FileNo");
        //            dt.Columns.Add("ContainerNo");
        //            dt.Columns.Add("IsEdi");
        //            dt.Columns.Add("Pol");
        //            dt.Columns.Add("Pod");
        //            dt.Columns.Add("Final Destination");
        //            dt.Columns.Add("FileType");
        //            dt.Columns.Add("Hblcount");
        //            dt.Columns.Add("CBM");
        //            dt.Columns.Add("Coloader");
        //            dt.Columns.Add("Sailing Date");
        //            dt.Columns.Add("Eta At Pod");
        //            dt.Columns.Add("Eta At FD");
        //            dt.Columns.Add("MBL Freight Term");
        //            dt.Columns.Add("HBL Freight Term");
        //            dt.Columns.Add("Vessel Name");
        //            dt.Columns.Add("Shipping Line");
        //            dt.Columns.Add("Contact Person");
        //            dt.Columns.Add("Thread Name");
        //            dt.Columns.Add("Activity");
        //            dt.Columns.Add("Current Status");
        //            dt.Columns.Add("User Name");
        //            dt.Columns.Add("Comment");
        //            //dt.Columns.Add("Pages");
        //            dt.Columns.Add("StartDate");
        //            dt.Columns.Add("EndDate");

        //            //dt1.Columns.Add("Pod");
        //            //dt1.Columns.Add("EtaAtPod");
        //            //dt1.Columns.Add("Received Date");
        //            //dt1.Columns.Add("ContainerNo");
        //            //dt1.Columns.Add("Pol");
        //            //dt1.Columns.Add("FileType");
        //            //dt1.Columns.Add("Hblcount");
        //            //dt1.Columns.Add("IsEdi");
        //            //dt1.Columns.Add("Activity");
        //            //dt1.Columns.Add("Current Status");
        //            //dt1.Columns.Add("Comment");
        //            //dt1.Columns.Add("UserName");
        //            ////dt1.Columns.Add("Pages");
        //            //dt1.Columns.Add("StartDate");
        //            //dt1.Columns.Add("EndDate");
        //            //dt1.Columns.Add("FileNo");
        //            //dt1.Columns.Add("VesselName");
        //            //dt1.Columns.Add("ShippingLine");

        //            //dt.Columns.Add("Received Date");
        //            //dt.Columns.Add("File Number");
        //            //dt.Columns.Add("Container Number");
        //            //dt.Columns.Add("SI Cut Off");
        //            //dt.Columns.Add("User");
        //            //dt.Columns.Add("Activity");
        //            //dt.Columns.Add("Status");
        //            //dt.Columns.Add("Comment");
        //            //dt.Columns.Add("ROE");


        //            if (report.DateType == "ReceivedDate")
        //            {
        //                fileactivtydata = _ctx.FileActivity.Include(x => x.FileEntry).Include(x => x.User).Include(x => x.ActivityMaster).Where(x => x.FileEntry.CreatedDate != null && x.FileEntry.CreatedDate.Value.Date >= startDate.Date &&
        //                                      x.FileEntry.CreatedDate.Value.Date <= endDate.Date)
        //                                      .Select(x => new FileReportViewModel
        //                                      {
        //                                          ReceivedDate = x.FileEntry.CreatedDate,
        //                                          FileNo = x.FileEntry.FileNo != null ? x.FileEntry.FileNo : "",
        //                                          ContainerNo = x.FileEntry.ContainerNo,
        //                                          IsEdi = x.FileEntry.IsEdi == true ? "Yes" : "No",
        //                                          POL = x.FileEntry.Pol != null ? x.FileEntry.Pol : "",
        //                                          POD = x.FileEntry.Pod != null ? _ctx.LocationMaster.Where(y => y.Id == x.FileEntry.Pod).Select(y => y.Name).FirstOrDefault() : "",
        //                                          FinalDestination = x.FileEntry.FinalDestination != null ? x.FileEntry.FinalDestination : "",
        //                                          FileType = x.FileEntry.FileType != null ? x.FileEntry.FileType : "",
        //                                          HBLCount = x.FileEntry.Hblcount != null ? x.FileEntry.Hblcount : "0",
        //                                          CBM = x.FileEntry.Cbm != null ? x.FileEntry.Cbm : "",
        //                                          Coloader = x.FileEntry.CoLoader != null ? x.FileEntry.CoLoader : "",
        //                                          SailingDate = x.FileEntry.SailingDate,
        //                                          ETA = x.FileEntry.EtaAtPod,
        //                                          ETAFD = x.FileEntry.EtaAtFD,
        //                                          MBLFreightTerm = x.FileEntry.MBLFreightTerm != null ? x.FileEntry.MBLFreightTerm : "",
        //                                          HBLFreightTerm = x.FileEntry.HBLFreightTerm != null ? x.FileEntry.HBLFreightTerm : "",
        //                                          VesselName = x.FileEntry.VesselName != null ? x.FileEntry.VesselName : "",
        //                                          ShippingLine = x.FileEntry.ShippingLine != null ? x.FileEntry.ShippingLine : "",
        //                                          ContactPerson = x.FileEntry.ContactPerson != null ? x.FileEntry.ContactPerson : "",
        //                                          ThreadName = x.ActivityMaster.ThreadMaster.Name != null ? x.ActivityMaster.ThreadMaster.Name : "",
        //                                          Activity = x.ActivityId != null ? x.ActivityMaster.Name : "",
        //                                          Status = x.CurrentStatus != null ? x.CurrentStatus : "",
        //                                          User = x.UserId != null ? x.User.CitrixId : "",
        //                                          Comment = x.Comment != null ? x.Comment : "",
        //                                          //Pages = x.Pages,
        //                                          StartDate = x.StartTime != null ? x.StartTime : (DateTime?)null,
        //                                          EndDate = x.EndTime != null ? x.EndTime : (DateTime?)null,
        //                                      }).ToList();
        //                fileactivtydata = fileactivtydata.Select(x => new FileReportViewModel
        //                {
        //                    //POD = x.POD,
        //                    //ETA = x.ETA.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.ETA.Value, istTimeZone) : (DateTime?)null,
        //                    //ReceivedDate = x.ReceivedDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.ReceivedDate.Value, istTimeZone) : (DateTime?)null,
        //                    //ContainerNo = x.ContainerNo,
        //                    //POL = x.POL,
        //                    //FileType = x.FileType,
        //                    //HBLCount = x.HBLCount,
        //                    //IsEdi = x.IsEdi,
        //                    //Activity = x.Activity,
        //                    //Status = x.Status,
        //                    //Comment = x.Comment,
        //                    //User = x.User,
        //                    ////Pages = x.Pages,
        //                    //StartDate = x.StartDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.StartDate.Value, istTimeZone) : (DateTime?)null,
        //                    //EndDate = x.EndDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.EndDate.Value, istTimeZone) : (DateTime?)null,
        //                    //FileNo = x.FileNo,
        //                    //VesselName = x.VesselName,
        //                    //ShippingLine = x.ShippingLine,
        //                    ReceivedDate = x.ReceivedDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.ReceivedDate.Value, istTimeZone) : (DateTime?)null,
        //                    FileNo = x.FileNo != null ? x.FileNo : "",
        //                    ContainerNo = x.ContainerNo,
        //                    IsEdi = x.IsEdi,
        //                    POL = x.POL,
        //                    POD = x.POD,
        //                    FinalDestination = x.FinalDestination,
        //                    FileType = x.FileType,
        //                    HBLCount = x.HBLCount,
        //                    CBM = x.CBM,
        //                    Coloader = x.Coloader,
        //                    SailingDate = x.SailingDate,
        //                    ETA = x.ETA.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.ETA.Value, istTimeZone) : (DateTime?)null,
        //                    ETAFD = x.ETAFD.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.ETAFD.Value, istTimeZone) : (DateTime?)null,
        //                    MBLFreightTerm = x.MBLFreightTerm,
        //                    HBLFreightTerm = x.HBLFreightTerm,
        //                    VesselName = x.VesselName,
        //                    ShippingLine = x.ShippingLine,
        //                    ContactPerson = x.ContactPerson,
        //                    ThreadName = x.ThreadName,
        //                    Activity = x.Activity,
        //                    Status = x.Status,
        //                    User = x.User,
        //                    Comment = x.Comment,
        //                    //Pages = x.Pages,
        //                    StartDate = x.StartDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.StartDate.Value, istTimeZone) : (DateTime?)null,
        //                    EndDate = x.EndDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.EndDate.Value, istTimeZone) : (DateTime?)null,
        //                }).ToList();

        //                fileactivtyHistory = _ctx.FileHistoryLog.Include(x => x.FileActivity).Include(x => x.FileActivity.FileEntry).Include(x => x.User).Include(x => x.FileActivity.ActivityMaster).Where(x => x.FileActivity.FileEntry.CreatedDate != null && x.FileActivity.FileEntry.CreatedDate.Value.Date >= startDate.Date &&
        //                                     x.FileActivity.FileEntry.CreatedDate.Value.Date <= endDate.Date)
        //                                     .Select(x => new FileReportViewModel
        //                                     {
        //                                         ReceivedDate = x.FileActivity.FileEntry.CreatedDate,
        //                                         FileNo = x.FileActivity.FileEntry.FileNo != null ? x.FileActivity.FileEntry.FileNo : "",
        //                                         ContainerNo = x.FileActivity.FileEntry.ContainerNo,
        //                                         IsEdi = x.FileActivity.FileEntry.IsEdi == true ? "Yes" : "No",
        //                                         POL = x.FileActivity.FileEntry.Pol != null ? x.FileActivity.FileEntry.Pol : "",
        //                                         POD = x.FileActivity.FileEntry.Pod != null ? _ctx.LocationMaster.Where(y => y.Id == x.FileActivity.FileEntry.Pod).Select(y => y.Name).FirstOrDefault() : "",
        //                                         FinalDestination = x.FileActivity.FileEntry.FinalDestination != null ? x.FileActivity.FileEntry.FinalDestination : "",
        //                                         FileType = x.FileActivity.FileEntry.FileType != null ? x.FileActivity.FileEntry.FileType : "",
        //                                         HBLCount = x.FileActivity.FileEntry.Hblcount != null ? x.FileActivity.FileEntry.Hblcount : "0",
        //                                         CBM = x.FileActivity.FileEntry.Cbm != null ? x.FileActivity.FileEntry.Cbm : "",
        //                                         Coloader = x.FileActivity.FileEntry.CoLoader != null ? x.FileActivity.FileEntry.CoLoader : "",
        //                                         SailingDate = x.FileActivity.FileEntry.SailingDate,
        //                                         ETA = x.FileActivity.FileEntry.EtaAtPod,
        //                                         ETAFD = x.FileActivity.FileEntry.EtaAtFD,
        //                                         MBLFreightTerm = x.FileActivity.FileEntry.MBLFreightTerm != null ? x.FileActivity.FileEntry.MBLFreightTerm : "",
        //                                         VesselName = x.FileActivity.FileEntry.VesselName != null ? x.FileActivity.FileEntry.VesselName : "",
        //                                         ShippingLine = x.FileActivity.FileEntry.ShippingLine != null ? x.FileActivity.FileEntry.ShippingLine : "",
        //                                         ContactPerson = x.FileActivity.FileEntry.ContactPerson != null ? x.FileActivity.FileEntry.ContactPerson : "",
        //                                         ThreadName = x.FileActivity.ActivityMaster.ThreadMaster.Name != null ? x.FileActivity.ActivityMaster.ThreadMaster.Name : "",
        //                                         Activity = x.FileActivityId != null ? x.FileActivity.ActivityMaster.Name : "",
        //                                         Status = x.CurrentStatus != null ? x.CurrentStatus : "",
        //                                         User = x.UserId != null ? x.User.CitrixId : "",
        //                                         Comment = x.Comment != null ? x.Comment : "",
        //                                         //Pages = x.Pages,
        //                                         StartDate = x.StartTime != null ? x.StartTime : (DateTime?)null,
        //                                         EndDate = x.EndTime != null ? x.EndTime : (DateTime?)null,
        //                                     }).ToList();
        //                fileactivtyHistory = fileactivtyHistory.Select(x => new FileReportViewModel
        //                {
        //                    ReceivedDate = x.ReceivedDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.ReceivedDate.Value, istTimeZone) : (DateTime?)null,
        //                    FileNo = x.FileNo != null ? x.FileNo : "",
        //                    ContainerNo = x.ContainerNo,
        //                    IsEdi = x.IsEdi,
        //                    POL = x.POL,
        //                    POD = x.POD,
        //                    FinalDestination = x.FinalDestination,
        //                    FileType = x.FileType,
        //                    HBLCount = x.HBLCount,
        //                    CBM = x.CBM,
        //                    Coloader = x.Coloader,
        //                    SailingDate = x.SailingDate,
        //                    ETA = x.ETA.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.ETA.Value, istTimeZone) : (DateTime?)null,
        //                    ETAFD = x.ETAFD.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.ETAFD.Value, istTimeZone) : (DateTime?)null,
        //                    MBLFreightTerm = x.MBLFreightTerm,
        //                    HBLFreightTerm = x.HBLFreightTerm,
        //                    VesselName = x.VesselName,
        //                    ShippingLine = x.ShippingLine,
        //                    ContactPerson = x.ContactPerson,
        //                    ThreadName = x.ThreadName,
        //                    Activity = x.Activity,
        //                    Status = x.Status,
        //                    User = x.User,
        //                    Comment = x.Comment,
        //                    //Pages = x.Pages,
        //                    StartDate = x.StartDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.StartDate.Value, istTimeZone) : (DateTime?)null,
        //                    EndDate = x.EndDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.EndDate.Value, istTimeZone) : (DateTime?)null,
        //                }).ToList();

        //                //fileactivity = ToDataTable(fileactivtydata);
        //            }
        //            else if ((report.DateType == "EndDate"))
        //            {
        //                fileactivtydata = _ctx.FileActivity.Include(x => x.FileEntry).Include(x => x.User).Include(x => x.ActivityMaster).Where(x => x.EndTime != null && x.EndTime.Value.Date >= startDate.Date &&
        //                                     x.EndTime.Value.Date <= endDate.Date)
        //                                     .Select(x => new FileReportViewModel
        //                                     {
        //                                         ReceivedDate = x.FileEntry.CreatedDate,
        //                                         FileNo = x.FileEntry.FileNo != null ? x.FileEntry.FileNo : "",
        //                                         ContainerNo = x.FileEntry.ContainerNo,
        //                                         IsEdi = x.FileEntry.IsEdi == true ? "Yes" : "No",
        //                                         POL = x.FileEntry.Pol != null ? x.FileEntry.Pol : "",
        //                                         POD = x.FileEntry.Pod != null ? _ctx.LocationMaster.Where(y => y.Id == x.FileEntry.Pod).Select(y => y.Name).FirstOrDefault() : "",
        //                                         FinalDestination = x.FileEntry.FinalDestination != null ? x.FileEntry.FinalDestination : "",
        //                                         FileType = x.FileEntry.FileType != null ? x.FileEntry.FileType : "",
        //                                         HBLCount = x.FileEntry.Hblcount != null ? x.FileEntry.Hblcount : "0",
        //                                         CBM = x.FileEntry.Cbm != null ? x.FileEntry.Cbm : "",
        //                                         Coloader = x.FileEntry.CoLoader != null ? x.FileEntry.CoLoader : "",
        //                                         SailingDate = x.FileEntry.SailingDate,
        //                                         ETA = x.FileEntry.EtaAtPod,
        //                                         ETAFD = x.FileEntry.EtaAtFD,
        //                                         MBLFreightTerm = x.FileEntry.MBLFreightTerm != null ? x.FileEntry.MBLFreightTerm : "",
        //                                         HBLFreightTerm = x.FileEntry.HBLFreightTerm != null ? x.FileEntry.HBLFreightTerm : "",
        //                                         VesselName = x.FileEntry.VesselName != null ? x.FileEntry.VesselName : "",
        //                                         ShippingLine = x.FileEntry.ShippingLine != null ? x.FileEntry.ShippingLine : "",
        //                                         ContactPerson = x.FileEntry.ContactPerson != null ? x.FileEntry.ContactPerson : "",
        //                                         ThreadName = x.ActivityMaster.ThreadMaster.Name != null ? x.ActivityMaster.ThreadMaster.Name : "",
        //                                         Activity = x.ActivityId != null ? x.ActivityMaster.Name : "",
        //                                         Status = x.CurrentStatus != null ? x.CurrentStatus : "",
        //                                         User = x.UserId != null ? x.User.CitrixId : "",
        //                                         Comment = x.Comment != null ? x.Comment : "",
        //                                         //Pages = x.Pages,
        //                                         StartDate = x.StartTime != null ? x.StartTime : (DateTime?)null,
        //                                         EndDate = x.EndTime != null ? x.EndTime : (DateTime?)null,
        //                                     }).ToList();
        //                fileactivtydata = fileactivtydata.Select(x => new FileReportViewModel
        //                {
        //                    ReceivedDate = x.ReceivedDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.ReceivedDate.Value, istTimeZone) : (DateTime?)null,
        //                    FileNo = x.FileNo != null ? x.FileNo : "",
        //                    ContainerNo = x.ContainerNo,
        //                    IsEdi = x.IsEdi,
        //                    POL = x.POL,
        //                    POD = x.POD,
        //                    FinalDestination = x.FinalDestination,
        //                    FileType = x.FileType,
        //                    HBLCount = x.HBLCount,
        //                    CBM = x.CBM,
        //                    Coloader = x.Coloader,
        //                    SailingDate = x.SailingDate,
        //                    ETA = x.ETA.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.ETA.Value, istTimeZone) : (DateTime?)null,
        //                    ETAFD = x.ETAFD.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.ETAFD.Value, istTimeZone) : (DateTime?)null,
        //                    MBLFreightTerm = x.MBLFreightTerm,
        //                    HBLFreightTerm = x.HBLFreightTerm,
        //                    VesselName = x.VesselName,
        //                    ShippingLine = x.ShippingLine,
        //                    ContactPerson = x.ContactPerson,
        //                    ThreadName = x.ThreadName,
        //                    Activity = x.Activity,
        //                    Status = x.Status,
        //                    User = x.User,
        //                    Comment = x.Comment,
        //                    //Pages = x.Pages,
        //                    StartDate = x.StartDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.StartDate.Value, istTimeZone) : (DateTime?)null,
        //                    EndDate = x.EndDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.EndDate.Value, istTimeZone) : (DateTime?)null,
        //                }).ToList();

        //                fileactivtyHistory = _ctx.FileHistoryLog.Include(x => x.FileActivity).Include(x => x.FileActivity.FileEntry).Include(x => x.User).Include(x => x.FileActivity.ActivityMaster).Where(x => x.EndTime != null && x.EndTime.Value.Date >= startDate.Date &&
        //                                     x.EndTime.Value.Date <= endDate.Date)
        //                                     .Select(x => new FileReportViewModel
        //                                     {
        //                                         ReceivedDate = x.FileActivity.FileEntry.CreatedDate,
        //                                         FileNo = x.FileActivity.FileEntry.FileNo != null ? x.FileActivity.FileEntry.FileNo : "",
        //                                         ContainerNo = x.FileActivity.FileEntry.ContainerNo,
        //                                         IsEdi = x.FileActivity.FileEntry.IsEdi == true ? "Yes" : "No",
        //                                         POL = x.FileActivity.FileEntry.Pol != null ? x.FileActivity.FileEntry.Pol : "",
        //                                         POD = x.FileActivity.FileEntry.Pod != null ? _ctx.LocationMaster.Where(y => y.Id == x.FileActivity.FileEntry.Pod).Select(y => y.Name).FirstOrDefault() : "",
        //                                         FinalDestination = x.FileActivity.FileEntry.FinalDestination != null ? x.FileActivity.FileEntry.FinalDestination : "",
        //                                         FileType = x.FileActivity.FileEntry.FileType != null ? x.FileActivity.FileEntry.FileType : "",
        //                                         HBLCount = x.FileActivity.FileEntry.Hblcount != null ? x.FileActivity.FileEntry.Hblcount : "0",
        //                                         CBM = x.FileActivity.FileEntry.Cbm != null ? x.FileActivity.FileEntry.Cbm : "",
        //                                         Coloader = x.FileActivity.FileEntry.CoLoader != null ? x.FileActivity.FileEntry.CoLoader : "",
        //                                         SailingDate = x.FileActivity.FileEntry.SailingDate,
        //                                         ETA = x.FileActivity.FileEntry.EtaAtPod,
        //                                         ETAFD = x.FileActivity.FileEntry.EtaAtFD,
        //                                         MBLFreightTerm = x.FileActivity.FileEntry.MBLFreightTerm != null ? x.FileActivity.FileEntry.MBLFreightTerm : "",
        //                                         VesselName = x.FileActivity.FileEntry.VesselName != null ? x.FileActivity.FileEntry.VesselName : "",
        //                                         ShippingLine = x.FileActivity.FileEntry.ShippingLine != null ? x.FileActivity.FileEntry.ShippingLine : "",
        //                                         ContactPerson = x.FileActivity.FileEntry.ContactPerson != null ? x.FileActivity.FileEntry.ContactPerson : "",
        //                                         ThreadName = x.FileActivity.ActivityMaster.ThreadMaster.Name != null ? x.FileActivity.ActivityMaster.ThreadMaster.Name : "",
        //                                         Activity = x.FileActivityId != null ? x.FileActivity.ActivityMaster.Name : "",
        //                                         Status = x.CurrentStatus != null ? x.CurrentStatus : "",
        //                                         User = x.UserId != null ? x.User.CitrixId : "",
        //                                         Comment = x.Comment != null ? x.Comment : "",
        //                                         //Pages = x.Pages,
        //                                         StartDate = x.StartTime != null ? x.StartTime : (DateTime?)null,
        //                                         EndDate = x.EndTime != null ? x.EndTime : (DateTime?)null,
        //                                     }).ToList();
        //                fileactivtyHistory = fileactivtyHistory.Select(x => new FileReportViewModel
        //                {
        //                    ReceivedDate = x.ReceivedDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.ReceivedDate.Value, istTimeZone) : (DateTime?)null,
        //                    FileNo = x.FileNo != null ? x.FileNo : "",
        //                    ContainerNo = x.ContainerNo,
        //                    IsEdi = x.IsEdi,
        //                    POL = x.POL,
        //                    POD = x.POD,
        //                    FinalDestination = x.FinalDestination,
        //                    FileType = x.FileType,
        //                    HBLCount = x.HBLCount,
        //                    CBM = x.CBM,
        //                    Coloader = x.Coloader,
        //                    SailingDate = x.SailingDate,
        //                    ETA = x.ETA.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.ETA.Value, istTimeZone) : (DateTime?)null,
        //                    ETAFD = x.ETAFD.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.ETAFD.Value, istTimeZone) : (DateTime?)null,
        //                    MBLFreightTerm = x.MBLFreightTerm,
        //                    HBLFreightTerm = x.HBLFreightTerm,
        //                    VesselName = x.VesselName,
        //                    ShippingLine = x.ShippingLine,
        //                    ContactPerson = x.ContactPerson,
        //                    ThreadName = x.ThreadName,
        //                    Activity = x.Activity,
        //                    Status = x.Status,
        //                    User = x.User,
        //                    Comment = x.Comment,
        //                    //Pages = x.Pages,
        //                    StartDate = x.StartDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.StartDate.Value, istTimeZone) : (DateTime?)null,
        //                    EndDate = x.EndDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.EndDate.Value, istTimeZone) : (DateTime?)null,
        //                }).ToList();

        //                //fileactivity = ToDataTable(fileactivtydata);
        //            }
        //            else
        //            {
        //                fileactivtydata = _ctx.FileActivity.Include(x => x.FileEntry).Include(x => x.User).Include(x => x.ActivityMaster).Where(x => x.StartTime != null && x.StartTime.Value.Date >= startDate.Date &&
        //                                     x.StartTime.Value.Date <= endDate.Date)
        //                                     .Select(x => new FileReportViewModel
        //                                     {
        //                                         ReceivedDate = x.FileEntry.CreatedDate,
        //                                         FileNo = x.FileEntry.FileNo != null ? x.FileEntry.FileNo : "",
        //                                         ContainerNo = x.FileEntry.ContainerNo,
        //                                         IsEdi = x.FileEntry.IsEdi == true ? "Yes" : "No",
        //                                         POL = x.FileEntry.Pol != null ? x.FileEntry.Pol : "",
        //                                         POD = x.FileEntry.Pod != null ? _ctx.LocationMaster.Where(y => y.Id == x.FileEntry.Pod).Select(y => y.Name).FirstOrDefault() : "",
        //                                         FinalDestination = x.FileEntry.FinalDestination != null ? x.FileEntry.FinalDestination : "",
        //                                         FileType = x.FileEntry.FileType != null ? x.FileEntry.FileType : "",
        //                                         HBLCount = x.FileEntry.Hblcount != null ? x.FileEntry.Hblcount : "0",
        //                                         CBM = x.FileEntry.Cbm != null ? x.FileEntry.Cbm : "",
        //                                         Coloader = x.FileEntry.CoLoader != null ? x.FileEntry.CoLoader : "",
        //                                         SailingDate = x.FileEntry.SailingDate,
        //                                         ETA = x.FileEntry.EtaAtPod,
        //                                         ETAFD = x.FileEntry.EtaAtFD,
        //                                         MBLFreightTerm = x.FileEntry.MBLFreightTerm != null ? x.FileEntry.MBLFreightTerm : "",
        //                                         HBLFreightTerm = x.FileEntry.HBLFreightTerm != null ? x.FileEntry.HBLFreightTerm : "",
        //                                         VesselName = x.FileEntry.VesselName != null ? x.FileEntry.VesselName : "",
        //                                         ShippingLine = x.FileEntry.ShippingLine != null ? x.FileEntry.ShippingLine : "",
        //                                         ContactPerson = x.FileEntry.ContactPerson != null ? x.FileEntry.ContactPerson : "",
        //                                         ThreadName = x.ActivityMaster.ThreadMaster.Name != null ? x.ActivityMaster.ThreadMaster.Name : "",
        //                                         Activity = x.ActivityId != null ? x.ActivityMaster.Name : "",
        //                                         Status = x.CurrentStatus != null ? x.CurrentStatus : "",
        //                                         User = x.UserId != null ? x.User.CitrixId : "",
        //                                         Comment = x.Comment != null ? x.Comment : "",
        //                                         //Pages = x.Pages,
        //                                         StartDate = x.StartTime != null ? x.StartTime : (DateTime?)null,
        //                                         EndDate = x.EndTime != null ? x.EndTime : (DateTime?)null,
        //                                     }).ToList();
        //                fileactivtydata = fileactivtydata.Select(x => new FileReportViewModel
        //                {
        //                    ReceivedDate = x.ReceivedDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.ReceivedDate.Value, istTimeZone) : (DateTime?)null,
        //                    FileNo = x.FileNo != null ? x.FileNo : "",
        //                    ContainerNo = x.ContainerNo,
        //                    IsEdi = x.IsEdi,
        //                    POL = x.POL,
        //                    POD = x.POD,
        //                    FinalDestination = x.FinalDestination,
        //                    FileType = x.FileType,
        //                    HBLCount = x.HBLCount,
        //                    CBM = x.CBM,
        //                    Coloader = x.Coloader,
        //                    SailingDate = x.SailingDate,
        //                    ETA = x.ETA.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.ETA.Value, istTimeZone) : (DateTime?)null,
        //                    ETAFD = x.ETAFD.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.ETAFD.Value, istTimeZone) : (DateTime?)null,
        //                    MBLFreightTerm = x.MBLFreightTerm,
        //                    HBLFreightTerm = x.HBLFreightTerm,
        //                    VesselName = x.VesselName,
        //                    ShippingLine = x.ShippingLine,
        //                    ContactPerson = x.ContactPerson,
        //                    ThreadName = x.ThreadName,
        //                    Activity = x.Activity,
        //                    Status = x.Status,
        //                    User = x.User,
        //                    Comment = x.Comment,
        //                    //Pages = x.Pages,
        //                    StartDate = x.StartDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.StartDate.Value, istTimeZone) : (DateTime?)null,
        //                    EndDate = x.EndDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.EndDate.Value, istTimeZone) : (DateTime?)null,
        //                }).ToList();

        //                fileactivtyHistory = _ctx.FileHistoryLog.Include(x => x.FileActivity).Include(x => x.FileActivity.FileEntry).Include(x => x.User).Include(x => x.FileActivity.ActivityMaster).Where(x => x.StartTime != null && x.StartTime.Value.Date >= startDate.Date &&
        //                                     x.StartTime.Value.Date <= endDate.Date)
        //                                     .Select(x => new FileReportViewModel
        //                                     {
        //                                         ReceivedDate = x.FileActivity.FileEntry.CreatedDate,
        //                                         FileNo = x.FileActivity.FileEntry.FileNo != null ? x.FileActivity.FileEntry.FileNo : "",
        //                                         ContainerNo = x.FileActivity.FileEntry.ContainerNo,
        //                                         IsEdi = x.FileActivity.FileEntry.IsEdi == true ? "Yes" : "No",
        //                                         POL = x.FileActivity.FileEntry.Pol != null ? x.FileActivity.FileEntry.Pol : "",
        //                                         POD = x.FileActivity.FileEntry.Pod != null ? _ctx.LocationMaster.Where(y => y.Id == x.FileActivity.FileEntry.Pod).Select(y => y.Name).FirstOrDefault() : "",
        //                                         FinalDestination = x.FileActivity.FileEntry.FinalDestination != null ? x.FileActivity.FileEntry.FinalDestination : "",
        //                                         FileType = x.FileActivity.FileEntry.FileType != null ? x.FileActivity.FileEntry.FileType : "",
        //                                         HBLCount = x.FileActivity.FileEntry.Hblcount != null ? x.FileActivity.FileEntry.Hblcount : "0",
        //                                         CBM = x.FileActivity.FileEntry.Cbm != null ? x.FileActivity.FileEntry.Cbm : "",
        //                                         Coloader = x.FileActivity.FileEntry.CoLoader != null ? x.FileActivity.FileEntry.CoLoader : "",
        //                                         SailingDate = x.FileActivity.FileEntry.SailingDate,
        //                                         ETA = x.FileActivity.FileEntry.EtaAtPod,
        //                                         ETAFD = x.FileActivity.FileEntry.EtaAtFD,
        //                                         MBLFreightTerm = x.FileActivity.FileEntry.MBLFreightTerm != null ? x.FileActivity.FileEntry.MBLFreightTerm : "",
        //                                         VesselName = x.FileActivity.FileEntry.VesselName != null ? x.FileActivity.FileEntry.VesselName : "",
        //                                         ShippingLine = x.FileActivity.FileEntry.ShippingLine != null ? x.FileActivity.FileEntry.ShippingLine : "",
        //                                         ContactPerson = x.FileActivity.FileEntry.ContactPerson != null ? x.FileActivity.FileEntry.ContactPerson : "",
        //                                         ThreadName = x.FileActivity.ActivityMaster.ThreadMaster.Name != null ? x.FileActivity.ActivityMaster.ThreadMaster.Name : "",
        //                                         Activity = x.FileActivityId != null ? x.FileActivity.ActivityMaster.Name : "",
        //                                         Status = x.CurrentStatus != null ? x.CurrentStatus : "",
        //                                         User = x.UserId != null ? x.User.CitrixId : "",
        //                                         Comment = x.Comment != null ? x.Comment : "",
        //                                         //Pages = x.Pages,
        //                                         StartDate = x.StartTime != null ? x.StartTime : (DateTime?)null,
        //                                         EndDate = x.EndTime != null ? x.EndTime : (DateTime?)null,
        //                                     }).ToList();
        //                fileactivtyHistory = fileactivtyHistory.Select(x => new FileReportViewModel
        //                {
        //                    ReceivedDate = x.ReceivedDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.ReceivedDate.Value, istTimeZone) : (DateTime?)null,
        //                    FileNo = x.FileNo != null ? x.FileNo : "",
        //                    ContainerNo = x.ContainerNo,
        //                    IsEdi = x.IsEdi,
        //                    POL = x.POL,
        //                    POD = x.POD,
        //                    FinalDestination = x.FinalDestination,
        //                    FileType = x.FileType,
        //                    HBLCount = x.HBLCount,
        //                    CBM = x.CBM,
        //                    Coloader = x.Coloader,
        //                    SailingDate = x.SailingDate,
        //                    ETA = x.ETA.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.ETA.Value, istTimeZone) : (DateTime?)null,
        //                    ETAFD = x.ETAFD.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.ETAFD.Value, istTimeZone) : (DateTime?)null,
        //                    MBLFreightTerm = x.MBLFreightTerm,
        //                    HBLFreightTerm = x.HBLFreightTerm,
        //                    VesselName = x.VesselName,
        //                    ShippingLine = x.ShippingLine,
        //                    ContactPerson = x.ContactPerson,
        //                    ThreadName = x.ThreadName,
        //                    Activity = x.Activity,
        //                    Status = x.Status,
        //                    User = x.User,
        //                    Comment = x.Comment,
        //                    //Pages = x.Pages,
        //                    StartDate = x.StartDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.StartDate.Value, istTimeZone) : (DateTime?)null,
        //                    EndDate = x.EndDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.EndDate.Value, istTimeZone) : (DateTime?)null,
        //                }).ToList();

        //                //fileactivity = ToDataTable(fileactivtydata);
        //            }

        //            DataTable dtt = ToDataTable(fileactivtydata);
        //            DataTable dtt1 = ToDataTable(fileactivtyHistory);

        //            foreach (DataRow item in dtt.Rows)
        //            {
        //                DataRow dr = dt.NewRow();
        //                for (int i = 0; i < dtt.Columns.Count; i++)
        //                {
        //                    dr[i] = item[i];

        //                }
        //                dt.Rows.Add(dr);
        //            }

        //            foreach (DataRow item in dtt1.Rows)
        //            {
        //                DataRow dr = dt1.NewRow();
        //                for (int i = 0; i < dtt1.Columns.Count; i++)
        //                {
        //                    dr[i] = item[i];

        //                }
        //                dt1.Rows.Add(dr);
        //            }

        //            string filename = "";
        //            //filename = saveFile.FileName;
        //            string apath = filename + ".xlsx";
        //            using (XLWorkbook wb = new XLWorkbook())
        //            {
        //                dt.TableName = "File Data Report";
        //                dt1.TableName = "File History Data Report";
        //                var wsFileData = wb.Worksheets.Add(dt);
        //                var wsFileData1 = wb.Worksheets.Add(dt1);
        //                wsFileData.Columns().AdjustToContents();
        //                wsFileData1.Columns().AdjustToContents();

        //                try
        //                {
        //                    using (MemoryStream stream = new MemoryStream())
        //                    {
        //                        wb.SaveAs(stream);
        //                        string excelname = $"FileDataReport-{DateTime.Now.ToString("ddMMyyyy hh:mm:ss")}.xlsx";
        //                        return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", excelname);
        //                    }

        //                    // System.Windows.Forms.MessageBox.Show("File Save Successfully.!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
        //                }
        //                catch (Exception ex)
        //                {
        //                    // System.Windows.Forms.MessageBox.Show("Something went wrong.!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        //                }
        //            }

        //        }
        //        else if (report.ReportType == "HBL")
        //        {
        //            dt.Columns.Add("Received Date");
        //            dt.Columns.Add("FileNo");
        //            dt.Columns.Add("ContainerNo");
        //            dt.Columns.Add("HBLNo");
        //            dt.Columns.Add("IsDap");
        //            dt.Columns.Add("Activity");
        //            dt.Columns.Add("Current Status");
        //            dt.Columns.Add("Comment");
        //            dt.Columns.Add("UserName");
        //            dt.Columns.Add("StartDate");
        //            dt.Columns.Add("EndDate");

        //            dt1.Columns.Add("Received Date");
        //            dt1.Columns.Add("FileNo");
        //            dt1.Columns.Add("ContainerNo");
        //            dt1.Columns.Add("HBLNo");
        //            dt1.Columns.Add("IsDap");
        //            dt1.Columns.Add("Activity");
        //            dt1.Columns.Add("Current Status");
        //            dt1.Columns.Add("Comment");
        //            dt1.Columns.Add("UserName");
        //            dt1.Columns.Add("StartDate");
        //            dt1.Columns.Add("EndDate");

        //            if (report.DateType == "ReceivedDate")
        //            {
        //                HBLdata = _ctx.HblActivity.Include(x => x.HblEntry).Include(x => x.HblEntry.FileGuid).Include(x => x.ActivityMaster).Include(x => x.User).Where(x => x.HblEntry.CreatedDate != null && x.HblEntry.CreatedDate.Value.Date >= startDate.Date &&
        //                          x.HblEntry.CreatedDate.Value.Date <= endDate.Date).Select(x => new HBLReportViewModel
        //                          {
        //                              ReceivedDate = x.HblEntry.CreatedDate,
        //                              FileNo = x.HblEntry.FileGuid.FileNo,
        //                              ContainerNo = x.HblEntry.FileGuid.ContainerNo,
        //                              HBLNo = x.HblEntry.Hblno,
        //                              IsDap = x.HblEntry.IsDap,
        //                              Activity = x.ActivityMaster.Name,
        //                              Status = x.CurrentStatus,
        //                              Comment = x.Comment,
        //                              User = x.User.CitrixId,
        //                              StartDate = x.StartTime,
        //                              EndDate = x.EndTime
        //                          }).ToList();

        //                HBLdata = HBLdata.Select(x => new HBLReportViewModel
        //                {
        //                    ReceivedDate = x.ReceivedDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.ReceivedDate.Value, istTimeZone) : (DateTime?)null,
        //                    FileNo = x.FileNo,
        //                    ContainerNo = x.ContainerNo,
        //                    HBLNo = x.HBLNo,
        //                    IsDap = x.IsDap,
        //                    Activity = x.Activity,
        //                    Status = x.Status,
        //                    Comment = x.Comment,
        //                    User = x.User,
        //                    StartDate = x.StartDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.StartDate.Value, istTimeZone) : (DateTime?)null,
        //                    EndDate = x.EndDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.EndDate.Value, istTimeZone) : (DateTime?)null

        //                }).ToList();

        //                HBLHistory = _ctx.HBLHistoryLog.Include(x => x.HblActivity).Include(x => x.HblActivity.HblEntry).Include(x => x.HblActivity.HblEntry.FileGuid).Include(x => x.HblActivity.ActivityMaster).Include(x => x.User).Where(x => x.HblActivity.HblEntry.CreatedDate != null && x.HblActivity.HblEntry.CreatedDate.Value.Date >= startDate.Date &&
        //                          x.HblActivity.HblEntry.CreatedDate.Value.Date <= endDate.Date).Select(x => new HBLReportViewModel
        //                          {
        //                              ReceivedDate = x.HblActivity.HblEntry.CreatedDate,
        //                              FileNo = x.HblActivity.HblEntry.FileGuid.FileNo,
        //                              ContainerNo = x.HblActivity.HblEntry.FileGuid.ContainerNo,
        //                              HBLNo = x.HblActivity.HblEntry.Hblno,
        //                              IsDap = x.HblActivity.HblEntry.IsDap,
        //                              Activity = x.HblActivity.ActivityMaster.Name,
        //                              Status = x.CurrentStatus,
        //                              Comment = x.Comment,
        //                              User = x.User.CitrixId,
        //                              StartDate = x.StartTime,
        //                              EndDate = x.EndTime
        //                          }).ToList();

        //                HBLHistory = HBLHistory.Select(x => new HBLReportViewModel
        //                {
        //                    ReceivedDate = x.ReceivedDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.ReceivedDate.Value, istTimeZone) : (DateTime?)null,
        //                    FileNo = x.FileNo,
        //                    ContainerNo = x.ContainerNo,
        //                    HBLNo = x.HBLNo,
        //                    IsDap = x.IsDap,
        //                    Activity = x.Activity,
        //                    Status = x.Status,
        //                    Comment = x.Comment,
        //                    User = x.User,
        //                    StartDate = x.StartDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.StartDate.Value, istTimeZone) : (DateTime?)null,
        //                    EndDate = x.EndDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.EndDate.Value, istTimeZone) : (DateTime?)null

        //                }).ToList();

        //                //hblactivity = ToDataTable(HBLdata);
        //            }
        //            else if (report.DateType == "EndDate")
        //            {
        //                HBLdata = _ctx.HblActivity.Include(x => x.HblEntry).Include(x => x.HblEntry.FileGuid).Include(x => x.ActivityMaster).Include(x => x.User).Where(x => x.EndTime != null && x.EndTime.Value.Date >= startDate.Date &&
        //                          x.EndTime.Value.Date <= endDate.Date).Select(x => new HBLReportViewModel
        //                          {
        //                              ReceivedDate = x.HblEntry.CreatedDate,
        //                              FileNo = x.HblEntry.FileGuid.FileNo,
        //                              ContainerNo = x.HblEntry.FileGuid.ContainerNo,
        //                              HBLNo = x.HblEntry.Hblno,
        //                              IsDap = x.HblEntry.IsDap,
        //                              Activity = x.ActivityMaster.Name,
        //                              Status = x.CurrentStatus,
        //                              Comment = x.Comment,
        //                              User = x.User.CitrixId,
        //                              StartDate = x.StartTime,
        //                              EndDate = x.EndTime
        //                          }).ToList();

        //                HBLdata = HBLdata.Select(x => new HBLReportViewModel
        //                {
        //                    ReceivedDate = x.ReceivedDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.ReceivedDate.Value, istTimeZone) : (DateTime?)null,
        //                    FileNo = x.FileNo,
        //                    ContainerNo = x.ContainerNo,
        //                    HBLNo = x.HBLNo,
        //                    IsDap = x.IsDap,
        //                    Activity = x.Activity,
        //                    Status = x.Status,
        //                    Comment = x.Comment,
        //                    User = x.User,
        //                    StartDate = x.StartDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.StartDate.Value, istTimeZone) : (DateTime?)null,
        //                    EndDate = x.EndDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.EndDate.Value, istTimeZone) : (DateTime?)null

        //                }).ToList();

        //                HBLHistory = _ctx.HBLHistoryLog.Include(x => x.HblActivity).Include(x => x.HblActivity.HblEntry).Include(x => x.HblActivity.HblEntry.FileGuid).Include(x => x.HblActivity.ActivityMaster).Include(x => x.User).Where(x => x.EndTime != null && x.EndTime.Value.Date >= startDate.Date &&
        //                          x.EndTime.Value.Date <= endDate.Date).Select(x => new HBLReportViewModel
        //                          {
        //                              ReceivedDate = x.HblActivity.HblEntry.CreatedDate,
        //                              FileNo = x.HblActivity.HblEntry.FileGuid.FileNo,
        //                              ContainerNo = x.HblActivity.HblEntry.FileGuid.ContainerNo,
        //                              HBLNo = x.HblActivity.HblEntry.Hblno,
        //                              IsDap = x.HblActivity.HblEntry.IsDap,
        //                              Activity = x.HblActivity.ActivityMaster.Name,
        //                              Status = x.CurrentStatus,
        //                              Comment = x.Comment,
        //                              User = x.User.CitrixId,
        //                              StartDate = x.StartTime,
        //                              EndDate = x.EndTime
        //                          }).ToList();

        //                HBLHistory = HBLHistory.Select(x => new HBLReportViewModel
        //                {
        //                    ReceivedDate = x.ReceivedDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.ReceivedDate.Value, istTimeZone) : (DateTime?)null,
        //                    FileNo = x.FileNo,
        //                    ContainerNo = x.ContainerNo,
        //                    HBLNo = x.HBLNo,
        //                    IsDap = x.IsDap,
        //                    Activity = x.Activity,
        //                    Status = x.Status,
        //                    Comment = x.Comment,
        //                    User = x.User,
        //                    StartDate = x.StartDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.StartDate.Value, istTimeZone) : (DateTime?)null,
        //                    EndDate = x.EndDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.EndDate.Value, istTimeZone) : (DateTime?)null

        //                }).ToList();

        //                //hblactivity = ToDataTable(HBLdata);
        //            }
        //            else
        //            {
        //                HBLdata = _ctx.HblActivity.Include(x => x.HblEntry).Include(x => x.HblEntry.FileGuid).Include(x => x.ActivityMaster).Include(x => x.User).Where(x => x.StartTime != null && x.StartTime.Value.Date >= startDate.Date &&
        //                          x.StartTime.Value.Date <= endDate.Date).Select(x => new HBLReportViewModel
        //                          {
        //                              ReceivedDate = x.HblEntry.CreatedDate,
        //                              FileNo = x.HblEntry.FileGuid.FileNo,
        //                              ContainerNo = x.HblEntry.FileGuid.ContainerNo,
        //                              HBLNo = x.HblEntry.Hblno,
        //                              IsDap = x.HblEntry.IsDap,
        //                              Activity = x.ActivityMaster.Name,
        //                              Status = x.CurrentStatus,
        //                              Comment = x.Comment,
        //                              User = x.User.CitrixId,
        //                              StartDate = x.StartTime,
        //                              EndDate = x.EndTime
        //                          }).ToList();

        //                HBLdata = HBLdata.Select(x => new HBLReportViewModel
        //                {
        //                    ReceivedDate = x.ReceivedDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.ReceivedDate.Value, istTimeZone) : (DateTime?)null,
        //                    FileNo = x.FileNo,
        //                    ContainerNo = x.ContainerNo,
        //                    HBLNo = x.HBLNo,
        //                    IsDap = x.IsDap,
        //                    Activity = x.Activity,
        //                    Status = x.Status,
        //                    Comment = x.Comment,
        //                    User = x.User,
        //                    StartDate = x.StartDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.StartDate.Value, istTimeZone) : (DateTime?)null,
        //                    EndDate = x.EndDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.EndDate.Value, istTimeZone) : (DateTime?)null

        //                }).ToList();

        //                HBLHistory = _ctx.HBLHistoryLog.Include(x => x.HblActivity).Include(x => x.HblActivity.HblEntry).Include(x => x.HblActivity.HblEntry.FileGuid).Include(x => x.HblActivity.ActivityMaster).Include(x => x.User).Where(x => x.StartTime != null && x.StartTime.Value.Date >= startDate.Date &&
        //                          x.StartTime.Value.Date <= endDate.Date).Select(x => new HBLReportViewModel
        //                          {
        //                              ReceivedDate = x.HblActivity.HblEntry.CreatedDate,
        //                              FileNo = x.HblActivity.HblEntry.FileGuid.FileNo,
        //                              ContainerNo = x.HblActivity.HblEntry.FileGuid.ContainerNo,
        //                              HBLNo = x.HblActivity.HblEntry.Hblno,
        //                              IsDap = x.HblActivity.HblEntry.IsDap,
        //                              Activity = x.HblActivity.ActivityMaster.Name,
        //                              Status = x.CurrentStatus,
        //                              Comment = x.Comment,
        //                              User = x.User.CitrixId,
        //                              StartDate = x.StartTime,
        //                              EndDate = x.EndTime
        //                          }).ToList();

        //                HBLHistory = HBLHistory.Select(x => new HBLReportViewModel
        //                {
        //                    ReceivedDate = x.ReceivedDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.ReceivedDate.Value, istTimeZone) : (DateTime?)null,
        //                    FileNo = x.FileNo,
        //                    ContainerNo = x.ContainerNo,
        //                    HBLNo = x.HBLNo,
        //                    IsDap = x.IsDap,
        //                    Activity = x.Activity,
        //                    Status = x.Status,
        //                    Comment = x.Comment,
        //                    User = x.User,
        //                    StartDate = x.StartDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.StartDate.Value, istTimeZone) : (DateTime?)null,
        //                    EndDate = x.EndDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.EndDate.Value, istTimeZone) : (DateTime?)null

        //                }).ToList();

        //                //hblactivity = ToDataTable(HBLdata);

        //            }
        //            DataTable dtt = ToDataTable(HBLdata);
        //            DataTable dtt1 = ToDataTable(HBLHistory);

        //            foreach (DataRow item in dtt.Rows)
        //            {
        //                DataRow dr = dt.NewRow();
        //                for (int i = 0; i < dtt.Columns.Count; i++)
        //                {
        //                    dr[i] = item[i];

        //                }
        //                dt.Rows.Add(dr);
        //            }

        //            foreach (DataRow item in dtt1.Rows)
        //            {
        //                DataRow dr = dt1.NewRow();
        //                for (int i = 0; i < dtt1.Columns.Count; i++)
        //                {
        //                    dr[i] = item[i];

        //                }
        //                dt1.Rows.Add(dr);
        //            }

        //            string filename = "";
        //            string apath = filename + ".xlsx";
        //            using (XLWorkbook wb = new XLWorkbook())
        //            {
        //                dt.TableName = "HBL Data Report";
        //                dt1.TableName = "HBL History Data Report";
        //                var wsFileData = wb.Worksheets.Add(dt);
        //                var wsFileData1 = wb.Worksheets.Add(dt1);
        //                wsFileData.Columns().AdjustToContents();
        //                wsFileData1.Columns().AdjustToContents();

        //                try
        //                {
        //                    using (MemoryStream stream = new MemoryStream())
        //                    {
        //                        wb.SaveAs(stream);
        //                        string excelname = $"HBLDataReport-{DateTime.Now.ToString("ddMMyyyy hh:mm:ss")}.xlsx";
        //                        return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", excelname);
        //                    }
        //                }
        //                catch (Exception ex)
        //                {

        //                }
        //            }

        //        }

        //    }
        //    else
        //    {
        //        ViewBag.ErrorMessage = "Please Select Date";
        //    }

        //    return View();
        //}
        
        
        //Report download

        [HttpPost]
        public ActionResult Reports(ReportViewModel report)
        {
            var fileActivityData = new List<FileReportViewModel>();
            var fileActivityHistory = new List<FileReportViewModel>();
            var hblActivityData = new List<HBLReportViewModel>();
            var hblActivityHistory = new List<HBLReportViewModel>();
            var istTimeZone = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
            var startDate = report.start_date;
            var endDate = report.end_date;

            if (report.start_date != null && report.end_date != null)
            {
                if (report.ReportType == "File")
                {
                    if (report.DateType == "ReceivedDate")
                    {
                        IQueryable<FileActivity> fileActivitiesQuery = _ctx.FileActivity
                            .Include(x => x.FileEntry)
                            .Include(x => x.User)
                            .Include(x => x.ActivityMaster)
                            .Where(x => x.FileEntry.CreatedDate != null
                                && x.FileEntry.CreatedDate.Value.Date >= startDate.Date
                                && x.FileEntry.CreatedDate.Value.Date <= endDate.Date);

                        IQueryable<FileHistoryLog> fileHistoryLogsQuery = _ctx.FileHistoryLog
                            .Include(x => x.FileActivity)
                            .Include(x => x.FileActivity.FileEntry)
                            .Include(x => x.User)
                            .Include(x => x.FileActivity.ActivityMaster)
                            .Where(x => x.FileActivity.FileEntry.CreatedDate != null
                                && x.FileActivity.FileEntry.CreatedDate.Value.Date >= startDate.Date
                                && x.FileActivity.FileEntry.CreatedDate.Value.Date <= endDate.Date);

                        // Data conversion
                        fileActivityData = fileActivitiesQuery
                            .Select(x => new FileReportViewModel
                            {
                                ReceivedDate = TimeZoneInfo.ConvertTimeFromUtc(x.FileEntry.CreatedDate.Value, istTimeZone),
                                FileNo = x.FileEntry.FileNo ?? "",
                                ContainerNo = x.FileEntry.ContainerNo,
                                IsEdi = x.FileEntry.IsEdi == true ? "Yes" : "No",
                                POL = x.FileEntry.Pol ?? "",
                                POD = x.FileEntry.Pod != null ? _ctx.LocationMaster.Where(y => y.Id == x.FileEntry.Pod).Select(y => y.Name).FirstOrDefault() : "",
                                FinalDestination = x.FileEntry.FinalDestination ?? "",
                                FileType = x.FileEntry.FileType ?? "",
                                HBLCount = x.FileEntry.Hblcount ?? "0",
                                CBM = x.FileEntry.Cbm ?? "",
                                Coloader = x.FileEntry.CoLoader ?? "",
                                SailingDate = x.FileEntry.SailingDate,
                                ETA = x.FileEntry.EtaAtPod.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.FileEntry.EtaAtPod.Value, istTimeZone) : (DateTime?)null,
                                ETAFD = x.FileEntry.EtaAtFD.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.FileEntry.EtaAtFD.Value, istTimeZone) : (DateTime?)null,
                                MBLFreightTerm = x.FileEntry.MBLFreightTerm ?? "",
                                HBLFreightTerm = x.FileEntry.HBLFreightTerm ?? "",
                                VesselName = x.FileEntry.VesselName ?? "",
                                ShippingLine = x.FileEntry.ShippingLine ?? "",
                                ContactPerson = x.FileEntry.ContactPerson ?? "",
                                ThreadName = x.ActivityMaster.ThreadMaster.Name ?? "",
                                Activity = x.ActivityMaster.Name ?? "",
                                Status = x.CurrentStatus ?? "",
                                User = x.User.CitrixId ?? "",
                                Comment = x.Comment ?? "",
                                StartDate = x.StartTime.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.StartTime.Value, istTimeZone) : (DateTime?)null,
                                EndDate = x.EndTime.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.EndTime.Value, istTimeZone) : (DateTime?)null,
                            }).ToList();

                        fileActivityHistory = fileHistoryLogsQuery
                            .Select(x => new FileReportViewModel
                            {
                                ReceivedDate = TimeZoneInfo.ConvertTimeFromUtc(x.FileActivity.FileEntry.CreatedDate.Value, istTimeZone),
                                FileNo = x.FileActivity.FileEntry.FileNo ?? "",
                                ContainerNo = x.FileActivity.FileEntry.ContainerNo,
                                IsEdi = x.FileActivity.FileEntry.IsEdi == true ? "Yes" : "No",
                                POL = x.FileActivity.FileEntry.Pol ?? "",
                                POD = x.FileActivity.FileEntry.Pod != null ? _ctx.LocationMaster.Where(y => y.Id == x.FileActivity.FileEntry.Pod).Select(y => y.Name).FirstOrDefault() : "",
                                FinalDestination = x.FileActivity.FileEntry.FinalDestination ?? "",
                                FileType = x.FileActivity.FileEntry.FileType ?? "",
                                HBLCount = x.FileActivity.FileEntry.Hblcount ?? "0",
                                CBM = x.FileActivity.FileEntry.Cbm ?? "",
                                Coloader = x.FileActivity.FileEntry.CoLoader ?? "",
                                SailingDate = x.FileActivity.FileEntry.SailingDate,
                                ETA = x.FileActivity.FileEntry.EtaAtPod.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.FileActivity.FileEntry.EtaAtPod.Value, istTimeZone) : (DateTime?)null,
                                ETAFD = x.FileActivity.FileEntry.EtaAtFD.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.FileActivity.FileEntry.EtaAtFD.Value, istTimeZone) : (DateTime?)null,
                                MBLFreightTerm = x.FileActivity.FileEntry.MBLFreightTerm ?? "",
                                HBLFreightTerm = x.FileActivity.FileEntry.HBLFreightTerm ?? "",
                                VesselName = x.FileActivity.FileEntry.VesselName ?? "",
                                ShippingLine = x.FileActivity.FileEntry.ShippingLine ?? "",
                                ContactPerson = x.FileActivity.FileEntry.ContactPerson ?? "",
                                ThreadName = x.FileActivity.ActivityMaster.ThreadMaster.Name ?? "",
                                Activity = x.FileActivity.ActivityMaster.Name ?? "",
                                Status = x.CurrentStatus ?? "",
                                User = x.User.CitrixId ?? "",
                                Comment = x.Comment ?? "",
                                StartDate = x.StartTime.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.StartTime.Value, istTimeZone) : (DateTime?)null,
                                EndDate = x.EndTime.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.EndTime.Value, istTimeZone) : (DateTime?)null,
                            }).ToList();
                    }
                    else if ((report.DateType == "EndDate"))
                    {
                        IQueryable<FileActivity> fileActivitiesQuery = _ctx.FileActivity
                            .Include(x => x.FileEntry)
                            .Include(x => x.User)
                            .Include(x => x.ActivityMaster)
                            .Where(x => x.EndTime != null
                                && x.EndTime.Value.Date >= startDate.Date
                                && x.EndTime.Value.Date <= endDate.Date);

                        IQueryable<FileHistoryLog> fileHistoryLogsQuery = _ctx.FileHistoryLog
                            .Include(x => x.FileActivity)
                            .Include(x => x.FileActivity.FileEntry)
                            .Include(x => x.User)
                            .Include(x => x.FileActivity.ActivityMaster)
                            .Where(x => x.EndTime != null
                                && x.EndTime.Value.Date >= startDate.Date
                                && x.EndTime.Value.Date <= endDate.Date);

                        // Data conversion
                        fileActivityData = fileActivitiesQuery
                            .Select(x => new FileReportViewModel
                            {
                                ReceivedDate = TimeZoneInfo.ConvertTimeFromUtc(x.FileEntry.CreatedDate.Value, istTimeZone),
                                FileNo = x.FileEntry.FileNo ?? "",
                                ContainerNo = x.FileEntry.ContainerNo,
                                IsEdi = x.FileEntry.IsEdi == true ? "Yes" : "No",
                                POL = x.FileEntry.Pol ?? "",
                                POD = x.FileEntry.Pod != null ? _ctx.LocationMaster.Where(y => y.Id == x.FileEntry.Pod).Select(y => y.Name).FirstOrDefault() : "",
                                FinalDestination = x.FileEntry.FinalDestination ?? "",
                                FileType = x.FileEntry.FileType ?? "",
                                HBLCount = x.FileEntry.Hblcount ?? "0",
                                CBM = x.FileEntry.Cbm ?? "",
                                Coloader = x.FileEntry.CoLoader ?? "",
                                SailingDate = x.FileEntry.SailingDate,
                                ETA = x.FileEntry.EtaAtPod.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.FileEntry.EtaAtPod.Value, istTimeZone) : (DateTime?)null,
                                ETAFD = x.FileEntry.EtaAtFD.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.FileEntry.EtaAtFD.Value, istTimeZone) : (DateTime?)null,
                                MBLFreightTerm = x.FileEntry.MBLFreightTerm ?? "",
                                HBLFreightTerm = x.FileEntry.HBLFreightTerm ?? "",
                                VesselName = x.FileEntry.VesselName ?? "",
                                ShippingLine = x.FileEntry.ShippingLine ?? "",
                                ContactPerson = x.FileEntry.ContactPerson ?? "",
                                ThreadName = x.ActivityMaster.ThreadMaster.Name ?? "",
                                Activity = x.ActivityMaster.Name ?? "",
                                Status = x.CurrentStatus ?? "",
                                User = x.User.CitrixId ?? "",
                                Comment = x.Comment ?? "",
                                StartDate = x.StartTime.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.StartTime.Value, istTimeZone) : (DateTime?)null,
                                EndDate = x.EndTime.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.EndTime.Value, istTimeZone) : (DateTime?)null,
                            }).ToList();

                        fileActivityHistory = fileHistoryLogsQuery
                            .Select(x => new FileReportViewModel
                            {
                                ReceivedDate = TimeZoneInfo.ConvertTimeFromUtc(x.FileActivity.FileEntry.CreatedDate.Value, istTimeZone),
                                FileNo = x.FileActivity.FileEntry.FileNo ?? "",
                                ContainerNo = x.FileActivity.FileEntry.ContainerNo,
                                IsEdi = x.FileActivity.FileEntry.IsEdi == true ? "Yes" : "No",
                                POL = x.FileActivity.FileEntry.Pol ?? "",
                                POD = x.FileActivity.FileEntry.Pod != null ? _ctx.LocationMaster.Where(y => y.Id == x.FileActivity.FileEntry.Pod).Select(y => y.Name).FirstOrDefault() : "",
                                FinalDestination = x.FileActivity.FileEntry.FinalDestination ?? "",
                                FileType = x.FileActivity.FileEntry.FileType ?? "",
                                HBLCount = x.FileActivity.FileEntry.Hblcount ?? "0",
                                CBM = x.FileActivity.FileEntry.Cbm ?? "",
                                Coloader = x.FileActivity.FileEntry.CoLoader ?? "",
                                SailingDate = x.FileActivity.FileEntry.SailingDate,
                                ETA = x.FileActivity.FileEntry.EtaAtPod.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.FileActivity.FileEntry.EtaAtPod.Value, istTimeZone) : (DateTime?)null,
                                ETAFD = x.FileActivity.FileEntry.EtaAtFD.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.FileActivity.FileEntry.EtaAtFD.Value, istTimeZone) : (DateTime?)null,
                                MBLFreightTerm = x.FileActivity.FileEntry.MBLFreightTerm ?? "",
                                HBLFreightTerm = x.FileActivity.FileEntry.HBLFreightTerm ?? "",
                                VesselName = x.FileActivity.FileEntry.VesselName ?? "",
                                ShippingLine = x.FileActivity.FileEntry.ShippingLine ?? "",
                                ContactPerson = x.FileActivity.FileEntry.ContactPerson ?? "",
                                ThreadName = x.FileActivity.ActivityMaster.ThreadMaster.Name ?? "",
                                Activity = x.FileActivity.ActivityMaster.Name ?? "",
                                Status = x.CurrentStatus ?? "",
                                User = x.User.CitrixId ?? "",
                                Comment = x.Comment ?? "",
                                StartDate = x.StartTime.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.StartTime.Value, istTimeZone) : (DateTime?)null,
                                EndDate = x.EndTime.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.EndTime.Value, istTimeZone) : (DateTime?)null,
                            }).ToList();
                    }
                    else
                    {
                        IQueryable<FileActivity> fileActivitiesQuery = _ctx.FileActivity
                            .Include(x => x.FileEntry)
                            .Include(x => x.User)
                            .Include(x => x.ActivityMaster)
                            .Where(x => x.StartTime != null
                                && x.StartTime.Value.Date >= startDate.Date
                                && x.StartTime.Value.Date <= endDate.Date);

                        IQueryable<FileHistoryLog> fileHistoryLogsQuery = _ctx.FileHistoryLog
                            .Include(x => x.FileActivity)
                            .Include(x => x.FileActivity.FileEntry)
                            .Include(x => x.User)
                            .Include(x => x.FileActivity.ActivityMaster)
                            .Where(x => x.StartTime != null
                                && x.StartTime.Value.Date >= startDate.Date
                                && x.StartTime.Value.Date <= endDate.Date);

                        // Data conversion
                        fileActivityData = fileActivitiesQuery
                            .Select(x => new FileReportViewModel
                            {
                                ReceivedDate = TimeZoneInfo.ConvertTimeFromUtc(x.FileEntry.CreatedDate.Value, istTimeZone),
                                FileNo = x.FileEntry.FileNo ?? "",
                                ContainerNo = x.FileEntry.ContainerNo,
                                IsEdi = x.FileEntry.IsEdi == true ? "Yes" : "No",
                                POL = x.FileEntry.Pol ?? "",
                                POD = x.FileEntry.Pod != null ? _ctx.LocationMaster.Where(y => y.Id == x.FileEntry.Pod).Select(y => y.Name).FirstOrDefault() : "",
                                FinalDestination = x.FileEntry.FinalDestination ?? "",
                                FileType = x.FileEntry.FileType ?? "",
                                HBLCount = x.FileEntry.Hblcount ?? "0",
                                CBM = x.FileEntry.Cbm ?? "",
                                Coloader = x.FileEntry.CoLoader ?? "",
                                SailingDate = x.FileEntry.SailingDate,
                                ETA = x.FileEntry.EtaAtPod.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.FileEntry.EtaAtPod.Value, istTimeZone) : (DateTime?)null,
                                ETAFD = x.FileEntry.EtaAtFD.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.FileEntry.EtaAtFD.Value, istTimeZone) : (DateTime?)null,
                                MBLFreightTerm = x.FileEntry.MBLFreightTerm ?? "",
                                HBLFreightTerm = x.FileEntry.HBLFreightTerm ?? "",
                                VesselName = x.FileEntry.VesselName ?? "",
                                ShippingLine = x.FileEntry.ShippingLine ?? "",
                                ContactPerson = x.FileEntry.ContactPerson ?? "",
                                ThreadName = x.ActivityMaster.ThreadMaster.Name ?? "",
                                Activity = x.ActivityMaster.Name ?? "",
                                Status = x.CurrentStatus ?? "",
                                User = x.User.CitrixId ?? "",
                                Comment = x.Comment ?? "",
                                StartDate = x.StartTime.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.StartTime.Value, istTimeZone) : (DateTime?)null,
                                EndDate = x.EndTime.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.EndTime.Value, istTimeZone) : (DateTime?)null,
                            }).ToList();

                        fileActivityHistory = fileHistoryLogsQuery
                            .Select(x => new FileReportViewModel
                            {
                                ReceivedDate = TimeZoneInfo.ConvertTimeFromUtc(x.FileActivity.FileEntry.CreatedDate.Value, istTimeZone),
                                FileNo = x.FileActivity.FileEntry.FileNo ?? "",
                                ContainerNo = x.FileActivity.FileEntry.ContainerNo,
                                IsEdi = x.FileActivity.FileEntry.IsEdi == true ? "Yes" : "No",
                                POL = x.FileActivity.FileEntry.Pol ?? "",
                                POD = x.FileActivity.FileEntry.Pod != null ? _ctx.LocationMaster.Where(y => y.Id == x.FileActivity.FileEntry.Pod).Select(y => y.Name).FirstOrDefault() : "",
                                FinalDestination = x.FileActivity.FileEntry.FinalDestination ?? "",
                                FileType = x.FileActivity.FileEntry.FileType ?? "",
                                HBLCount = x.FileActivity.FileEntry.Hblcount ?? "0",
                                CBM = x.FileActivity.FileEntry.Cbm ?? "",
                                Coloader = x.FileActivity.FileEntry.CoLoader ?? "",
                                SailingDate = x.FileActivity.FileEntry.SailingDate,
                                ETA = x.FileActivity.FileEntry.EtaAtPod.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.FileActivity.FileEntry.EtaAtPod.Value, istTimeZone) : (DateTime?)null,
                                ETAFD = x.FileActivity.FileEntry.EtaAtFD.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.FileActivity.FileEntry.EtaAtFD.Value, istTimeZone) : (DateTime?)null,
                                MBLFreightTerm = x.FileActivity.FileEntry.MBLFreightTerm ?? "",
                                HBLFreightTerm = x.FileActivity.FileEntry.HBLFreightTerm ?? "",
                                VesselName = x.FileActivity.FileEntry.VesselName ?? "",
                                ShippingLine = x.FileActivity.FileEntry.ShippingLine ?? "",
                                ContactPerson = x.FileActivity.FileEntry.ContactPerson ?? "",
                                ThreadName = x.FileActivity.ActivityMaster.ThreadMaster.Name ?? "",
                                Activity = x.FileActivity.ActivityMaster.Name ?? "",
                                Status = x.CurrentStatus ?? "",
                                User = x.User.CitrixId ?? "",
                                Comment = x.Comment ?? "",
                                StartDate = x.StartTime.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.StartTime.Value, istTimeZone) : (DateTime?)null,
                                EndDate = x.EndTime.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.EndTime.Value, istTimeZone) : (DateTime?)null,
                            }).ToList();
                    }

                    DataTable dt = ToDataTable(fileActivityData);
                    DataTable dt1 = ToDataTable(fileActivityHistory);

                    string filename = "";
                    //filename = saveFile.FileName;
                    string apath = filename + ".xlsx";
                    using (XLWorkbook wb = new XLWorkbook())
                    {
                        dt.TableName = "File Data Report";
                        dt1.TableName = "File History Data Report";
                        wb.Worksheets.Add(dt);
                        wb.Worksheets.Add(dt1);

                        try
                        {
                            using (MemoryStream stream = new MemoryStream())
                            {
                                wb.SaveAs(stream);
                                string excelname = $"FileDataReport-{DateTime.Now.ToString("ddMMyyyy hh:mm:ss")}.xlsx";
                                return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", excelname);
                            }

                            // System.Windows.Forms.MessageBox.Show("File Save Successfully.!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        catch (Exception ex)
                        {
                            // System.Windows.Forms.MessageBox.Show("Something went wrong.!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }

                }
                else if (report.ReportType == "HBL")
                {
                    if (report.DateType == "ReceivedDate")
                    {
                        IQueryable <HblActivity> hblActivitiesQuery = _ctx.HblActivity
                            .Include(x => x.HblEntry)
                            .Include(x => x.HblEntry.FileGuid)
                            .Include(x => x.User)
                            .Include(x => x.ActivityMaster)
                            .Where(x => x.HblEntry.CreatedDate != null
                                && x.HblEntry.CreatedDate.Value.Date >= startDate.Date
                                && x.HblEntry.CreatedDate.Value.Date <= endDate.Date);

                        IQueryable<HBLHistoryLog> hblHistoryLogsQuery = _ctx.HBLHistoryLog
                            .Include(x => x.HblActivity)
                            .Include(x => x.HblActivity.HblEntry)
                            .Include(x => x.User)
                            .Include(x => x.HblActivity.ActivityMaster)
                            .Where(x => x.HblActivity.HblEntry.CreatedDate != null
                                && x.HblActivity.HblEntry.CreatedDate.Value.Date >= startDate.Date
                                && x.HblActivity.HblEntry.CreatedDate.Value.Date <= endDate.Date);

                        // Data conversion
                        hblActivityData = hblActivitiesQuery
                            .Select(x => new HBLReportViewModel
                            {
                                ReceivedDate = TimeZoneInfo.ConvertTimeFromUtc(x.HblEntry.CreatedDate.Value, istTimeZone),
                                FileNo = x.HblEntry.FileGuid.FileNo ?? "",
                                ContainerNo = x.HblEntry.FileGuid.ContainerNo,
                                HBLNo = x.HblEntry.Hblno,
                                IsDap = x.HblEntry.IsDap,
                                IsEdi = x.HblEntry.FileGuid.IsEdi == true ? "Yes" : "No",
                                POL = x.HblEntry.FileGuid.Pol ?? "",
                                POD = x.HblEntry.FileGuid.Pod != null ? _ctx.LocationMaster.Where(y => y.Id == x.HblEntry.FileGuid.Pod).Select(y => y.Name).FirstOrDefault() : "",
                                FinalDestination = x.HblEntry.FileGuid.FinalDestination ?? "",
                                FileType = x.HblEntry.FileGuid.FileType ?? "",
                                HBLCount = x.HblEntry.FileGuid.Hblcount ?? "0",
                                CBM = x.HblEntry.FileGuid.Cbm ?? "",
                                Coloader = x.HblEntry.FileGuid.CoLoader ?? "",
                                SailingDate = x.HblEntry.FileGuid.SailingDate,
                                ETA = x.HblEntry.FileGuid.EtaAtPod.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.HblEntry.FileGuid.EtaAtPod.Value, istTimeZone) : (DateTime?)null,
                                ETAFD = x.HblEntry.FileGuid.EtaAtFD.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.HblEntry.FileGuid.EtaAtFD.Value, istTimeZone) : (DateTime?)null,
                                MBLFreightTerm = x.HblEntry.FileGuid.MBLFreightTerm ?? "",
                                HBLFreightTerm = x.HblEntry.FileGuid.HBLFreightTerm ?? "",
                                VesselName = x.HblEntry.FileGuid.VesselName ?? "",
                                ShippingLine = x.HblEntry.FileGuid.ShippingLine ?? "",
                                ContactPerson = x.HblEntry.FileGuid.ContactPerson ?? "",
                                ThreadName = x.ActivityMaster.ThreadMaster.Name ?? "",
                                Activity = x.ActivityMaster.Name ?? "",
                                Status = x.CurrentStatus ?? "",
                                User = x.User.CitrixId ?? "",
                                Comment = x.Comment ?? "",
                                StartDate = x.StartTime.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.StartTime.Value, istTimeZone) : (DateTime?)null,
                                EndDate = x.EndTime.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.EndTime.Value, istTimeZone) : (DateTime?)null,
                            }).ToList();

                        hblActivityHistory = hblHistoryLogsQuery
                            .Select(x => new HBLReportViewModel
                            {
                                ReceivedDate = TimeZoneInfo.ConvertTimeFromUtc(x.HblActivity.HblEntry.FileGuid.CreatedDate.Value, istTimeZone),
                                FileNo = x.HblActivity.HblEntry.FileGuid.FileNo ?? "",
                                ContainerNo = x.HblActivity.HblEntry.FileGuid.ContainerNo,
                                HBLNo = x.HblActivity.HblEntry.Hblno,
                                IsDap = x.HblActivity.HblEntry.IsDap,
                                IsEdi = x.HblActivity.HblEntry.FileGuid.IsEdi == true ? "Yes" : "No",
                                POL = x.HblActivity.HblEntry.FileGuid.Pol ?? "",
                                POD = x.HblActivity.HblEntry.FileGuid.Pod != null ? _ctx.LocationMaster.Where(y => y.Id == x.HblActivity.HblEntry.FileGuid.Pod).Select(y => y.Name).FirstOrDefault() : "",
                                FinalDestination = x.HblActivity.HblEntry.FileGuid.FinalDestination ?? "",
                                FileType = x.HblActivity.HblEntry.FileGuid.FileType ?? "",
                                HBLCount = x.HblActivity.HblEntry.FileGuid.Hblcount ?? "0",
                                CBM = x.HblActivity.HblEntry.FileGuid.Cbm ?? "",
                                Coloader = x.HblActivity.HblEntry.FileGuid.CoLoader ?? "",
                                SailingDate = x.HblActivity.HblEntry.FileGuid.SailingDate,
                                ETA = x.HblActivity.HblEntry.FileGuid.EtaAtPod.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.HblActivity.HblEntry.FileGuid.EtaAtPod.Value, istTimeZone) : (DateTime?)null,
                                ETAFD = x.HblActivity.HblEntry.FileGuid.EtaAtFD.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.HblActivity.HblEntry.FileGuid.EtaAtFD.Value, istTimeZone) : (DateTime?)null,
                                MBLFreightTerm = x.HblActivity.HblEntry.FileGuid.MBLFreightTerm ?? "",
                                HBLFreightTerm = x.HblActivity.HblEntry.FileGuid.HBLFreightTerm ?? "",
                                VesselName = x.HblActivity.HblEntry.FileGuid.VesselName ?? "",
                                ShippingLine = x.HblActivity.HblEntry.FileGuid.ShippingLine ?? "",
                                ContactPerson = x.HblActivity.HblEntry.FileGuid.ContactPerson ?? "",
                                ThreadName = x.HblActivity.ActivityMaster.ThreadMaster.Name ?? "",
                                Activity = x.HblActivity.ActivityMaster.Name ?? "",
                                Status = x.CurrentStatus ?? "",
                                User = x.User.CitrixId ?? "",
                                Comment = x.Comment ?? "",
                                StartDate = x.StartTime.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.StartTime.Value, istTimeZone) : (DateTime?)null,
                                EndDate = x.EndTime.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.EndTime.Value, istTimeZone) : (DateTime?)null,
                            }).ToList();
                    }
                    else if ((report.DateType == "EndDate"))
                    {
                        IQueryable<HblActivity> hblActivitiesQuery = _ctx.HblActivity
                            .Include(x => x.HblEntry)
                            .Include(x => x.HblEntry.FileGuid)
                            .Include(x => x.User)
                            .Include(x => x.ActivityMaster)
                            .Where(x => x.HblEntry.CreatedDate != null
                                && x.EndTime.Value.Date >= startDate.Date
                                && x.EndTime.Value.Date <= endDate.Date);

                        IQueryable<HBLHistoryLog> hblHistoryLogsQuery = _ctx.HBLHistoryLog
                            .Include(x => x.HblActivity)
                            .Include(x => x.HblActivity.HblEntry)
                            .Include(x => x.User)
                            .Include(x => x.HblActivity.ActivityMaster)
                            .Where(x => x.HblActivity.HblEntry.CreatedDate != null
                                && x.EndTime.Value.Date >= startDate.Date
                                && x.EndTime.Value.Date <= endDate.Date);

                        // Data conversion
                        hblActivityData = hblActivitiesQuery
                            .Select(x => new HBLReportViewModel
                            {
                                ReceivedDate = TimeZoneInfo.ConvertTimeFromUtc(x.HblEntry.CreatedDate.Value, istTimeZone),
                                FileNo = x.HblEntry.FileGuid.FileNo ?? "",
                                ContainerNo = x.HblEntry.FileGuid.ContainerNo,
                                HBLNo = x.HblEntry.Hblno,
                                IsDap = x.HblEntry.IsDap,
                                IsEdi = x.HblEntry.FileGuid.IsEdi == true ? "Yes" : "No",
                                POL = x.HblEntry.FileGuid.Pol ?? "",
                                POD = x.HblEntry.FileGuid.Pod != null ? _ctx.LocationMaster.Where(y => y.Id == x.HblEntry.FileGuid.Pod).Select(y => y.Name).FirstOrDefault() : "",
                                FinalDestination = x.HblEntry.FileGuid.FinalDestination ?? "",
                                FileType = x.HblEntry.FileGuid.FileType ?? "",
                                HBLCount = x.HblEntry.FileGuid.Hblcount ?? "0",
                                CBM = x.HblEntry.FileGuid.Cbm ?? "",
                                Coloader = x.HblEntry.FileGuid.CoLoader ?? "",
                                SailingDate = x.HblEntry.FileGuid.SailingDate,
                                ETA = x.HblEntry.FileGuid.EtaAtPod.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.HblEntry.FileGuid.EtaAtPod.Value, istTimeZone) : (DateTime?)null,
                                ETAFD = x.HblEntry.FileGuid.EtaAtFD.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.HblEntry.FileGuid.EtaAtFD.Value, istTimeZone) : (DateTime?)null,
                                MBLFreightTerm = x.HblEntry.FileGuid.MBLFreightTerm ?? "",
                                HBLFreightTerm = x.HblEntry.FileGuid.HBLFreightTerm ?? "",
                                VesselName = x.HblEntry.FileGuid.VesselName ?? "",
                                ShippingLine = x.HblEntry.FileGuid.ShippingLine ?? "",
                                ContactPerson = x.HblEntry.FileGuid.ContactPerson ?? "",
                                ThreadName = x.ActivityMaster.ThreadMaster.Name ?? "",
                                Activity = x.ActivityMaster.Name ?? "",
                                Status = x.CurrentStatus ?? "",
                                User = x.User.CitrixId ?? "",
                                Comment = x.Comment ?? "",
                                StartDate = x.StartTime.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.StartTime.Value, istTimeZone) : (DateTime?)null,
                                EndDate = x.EndTime.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.EndTime.Value, istTimeZone) : (DateTime?)null,
                            }).ToList();

                        hblActivityHistory = hblHistoryLogsQuery
                            .Select(x => new HBLReportViewModel
                            {
                                ReceivedDate = TimeZoneInfo.ConvertTimeFromUtc(x.HblActivity.HblEntry.FileGuid.CreatedDate.Value, istTimeZone),
                                FileNo = x.HblActivity.HblEntry.FileGuid.FileNo ?? "",
                                ContainerNo = x.HblActivity.HblEntry.FileGuid.ContainerNo,
                                HBLNo = x.HblActivity.HblEntry.Hblno,
                                IsDap = x.HblActivity.HblEntry.IsDap,
                                IsEdi = x.HblActivity.HblEntry.FileGuid.IsEdi == true ? "Yes" : "No",
                                POL = x.HblActivity.HblEntry.FileGuid.Pol ?? "",
                                POD = x.HblActivity.HblEntry.FileGuid.Pod != null ? _ctx.LocationMaster.Where(y => y.Id == x.HblActivity.HblEntry.FileGuid.Pod).Select(y => y.Name).FirstOrDefault() : "",
                                FinalDestination = x.HblActivity.HblEntry.FileGuid.FinalDestination ?? "",
                                FileType = x.HblActivity.HblEntry.FileGuid.FileType ?? "",
                                HBLCount = x.HblActivity.HblEntry.FileGuid.Hblcount ?? "0",
                                CBM = x.HblActivity.HblEntry.FileGuid.Cbm ?? "",
                                Coloader = x.HblActivity.HblEntry.FileGuid.CoLoader ?? "",
                                SailingDate = x.HblActivity.HblEntry.FileGuid.SailingDate,
                                ETA = x.HblActivity.HblEntry.FileGuid.EtaAtPod.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.HblActivity.HblEntry.FileGuid.EtaAtPod.Value, istTimeZone) : (DateTime?)null,
                                ETAFD = x.HblActivity.HblEntry.FileGuid.EtaAtFD.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.HblActivity.HblEntry.FileGuid.EtaAtFD.Value, istTimeZone) : (DateTime?)null,
                                MBLFreightTerm = x.HblActivity.HblEntry.FileGuid.MBLFreightTerm ?? "",
                                HBLFreightTerm = x.HblActivity.HblEntry.FileGuid.HBLFreightTerm ?? "",
                                VesselName = x.HblActivity.HblEntry.FileGuid.VesselName ?? "",
                                ShippingLine = x.HblActivity.HblEntry.FileGuid.ShippingLine ?? "",
                                ContactPerson = x.HblActivity.HblEntry.FileGuid.ContactPerson ?? "",
                                ThreadName = x.HblActivity.ActivityMaster.ThreadMaster.Name ?? "",
                                Activity = x.HblActivity.ActivityMaster.Name ?? "",
                                Status = x.CurrentStatus ?? "",
                                User = x.User.CitrixId ?? "",
                                Comment = x.Comment ?? "",
                                StartDate = x.StartTime.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.StartTime.Value, istTimeZone) : (DateTime?)null,
                                EndDate = x.EndTime.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.EndTime.Value, istTimeZone) : (DateTime?)null,
                            }).ToList();
                    }
                    else
                    {
                        IQueryable<HblActivity> hblActivitiesQuery = _ctx.HblActivity
                            .Include(x => x.HblEntry)
                            .Include(x => x.HblEntry.FileGuid)
                            .Include(x => x.User)
                            .Include(x => x.ActivityMaster)
                            .Where(x => x.HblEntry.CreatedDate != null
                                && x.StartTime.Value.Date >= startDate.Date
                                && x.StartTime.Value.Date <= endDate.Date);

                        IQueryable<HBLHistoryLog> hblHistoryLogsQuery = _ctx.HBLHistoryLog
                            .Include(x => x.HblActivity)
                            .Include(x => x.HblActivity.HblEntry)
                            .Include(x => x.User)
                            .Include(x => x.HblActivity.ActivityMaster)
                            .Where(x => x.HblActivity.HblEntry.CreatedDate != null
                                && x.StartTime.Value.Date >= startDate.Date
                                && x.StartTime.Value.Date <= endDate.Date);

                        // Data conversion
                        hblActivityData = hblActivitiesQuery
                            .Select(x => new HBLReportViewModel
                            {
                                ReceivedDate = TimeZoneInfo.ConvertTimeFromUtc(x.HblEntry.CreatedDate.Value, istTimeZone),
                                FileNo = x.HblEntry.FileGuid.FileNo ?? "",
                                ContainerNo = x.HblEntry.FileGuid.ContainerNo,
                                HBLNo = x.HblEntry.Hblno,
                                IsDap = x.HblEntry.IsDap,
                                IsEdi = x.HblEntry.FileGuid.IsEdi == true ? "Yes" : "No",
                                POL = x.HblEntry.FileGuid.Pol ?? "",
                                POD = x.HblEntry.FileGuid.Pod != null ? _ctx.LocationMaster.Where(y => y.Id == x.HblEntry.FileGuid.Pod).Select(y => y.Name).FirstOrDefault() : "",
                                FinalDestination = x.HblEntry.FileGuid.FinalDestination ?? "",
                                FileType = x.HblEntry.FileGuid.FileType ?? "",
                                HBLCount = x.HblEntry.FileGuid.Hblcount ?? "0",
                                CBM = x.HblEntry.FileGuid.Cbm ?? "",
                                Coloader = x.HblEntry.FileGuid.CoLoader ?? "",
                                SailingDate = x.HblEntry.FileGuid.SailingDate,
                                ETA = x.HblEntry.FileGuid.EtaAtPod.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.HblEntry.FileGuid.EtaAtPod.Value, istTimeZone) : (DateTime?)null,
                                ETAFD = x.HblEntry.FileGuid.EtaAtFD.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.HblEntry.FileGuid.EtaAtFD.Value, istTimeZone) : (DateTime?)null,
                                MBLFreightTerm = x.HblEntry.FileGuid.MBLFreightTerm ?? "",
                                HBLFreightTerm = x.HblEntry.FileGuid.HBLFreightTerm ?? "",
                                VesselName = x.HblEntry.FileGuid.VesselName ?? "",
                                ShippingLine = x.HblEntry.FileGuid.ShippingLine ?? "",
                                ContactPerson = x.HblEntry.FileGuid.ContactPerson ?? "",
                                ThreadName = x.ActivityMaster.ThreadMaster.Name ?? "",
                                Activity = x.ActivityMaster.Name ?? "",
                                Status = x.CurrentStatus ?? "",
                                User = x.User.CitrixId ?? "",
                                Comment = x.Comment ?? "",
                                StartDate = x.StartTime.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.StartTime.Value, istTimeZone) : (DateTime?)null,
                                EndDate = x.EndTime.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.EndTime.Value, istTimeZone) : (DateTime?)null,
                            }).ToList();

                        hblActivityHistory = hblHistoryLogsQuery
                            .Select(x => new HBLReportViewModel
                            {
                                ReceivedDate = TimeZoneInfo.ConvertTimeFromUtc(x.HblActivity.HblEntry.FileGuid.CreatedDate.Value, istTimeZone),
                                FileNo = x.HblActivity.HblEntry.FileGuid.FileNo ?? "",
                                ContainerNo = x.HblActivity.HblEntry.FileGuid.ContainerNo,
                                HBLNo = x.HblActivity.HblEntry.Hblno,
                                IsDap = x.HblActivity.HblEntry.IsDap,
                                IsEdi = x.HblActivity.HblEntry.FileGuid.IsEdi == true ? "Yes" : "No",
                                POL = x.HblActivity.HblEntry.FileGuid.Pol ?? "",
                                POD = x.HblActivity.HblEntry.FileGuid.Pod != null ? _ctx.LocationMaster.Where(y => y.Id == x.HblActivity.HblEntry.FileGuid.Pod).Select(y => y.Name).FirstOrDefault() : "",
                                FinalDestination = x.HblActivity.HblEntry.FileGuid.FinalDestination ?? "",
                                FileType = x.HblActivity.HblEntry.FileGuid.FileType ?? "",
                                HBLCount = x.HblActivity.HblEntry.FileGuid.Hblcount ?? "0",
                                CBM = x.HblActivity.HblEntry.FileGuid.Cbm ?? "",
                                Coloader = x.HblActivity.HblEntry.FileGuid.CoLoader ?? "",
                                SailingDate = x.HblActivity.HblEntry.FileGuid.SailingDate,
                                ETA = x.HblActivity.HblEntry.FileGuid.EtaAtPod.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.HblActivity.HblEntry.FileGuid.EtaAtPod.Value, istTimeZone) : (DateTime?)null,
                                ETAFD = x.HblActivity.HblEntry.FileGuid.EtaAtFD.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.HblActivity.HblEntry.FileGuid.EtaAtFD.Value, istTimeZone) : (DateTime?)null,
                                MBLFreightTerm = x.HblActivity.HblEntry.FileGuid.MBLFreightTerm ?? "",
                                HBLFreightTerm = x.HblActivity.HblEntry.FileGuid.HBLFreightTerm ?? "",
                                VesselName = x.HblActivity.HblEntry.FileGuid.VesselName ?? "",
                                ShippingLine = x.HblActivity.HblEntry.FileGuid.ShippingLine ?? "",
                                ContactPerson = x.HblActivity.HblEntry.FileGuid.ContactPerson ?? "",
                                ThreadName = x.HblActivity.ActivityMaster.ThreadMaster.Name ?? "",
                                Activity = x.HblActivity.ActivityMaster.Name ?? "",
                                Status = x.CurrentStatus ?? "",
                                User = x.User.CitrixId ?? "",
                                Comment = x.Comment ?? "",
                                StartDate = x.StartTime.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.StartTime.Value, istTimeZone) : (DateTime?)null,
                                EndDate = x.EndTime.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.EndTime.Value, istTimeZone) : (DateTime?)null,
                            }).ToList();
                    }

                    DataTable dt = ToDataTable(hblActivityData);
                    DataTable dt1 = ToDataTable(hblActivityHistory);

                    string filename = "";
                    //filename = saveFile.FileName;
                    string apath = filename + ".xlsx";
                    using (XLWorkbook wb = new XLWorkbook())
                    {
                        dt.TableName = "HBL Data Report";
                        dt1.TableName = "HBL History Data Report";
                        wb.Worksheets.Add(dt);
                        wb.Worksheets.Add(dt1);

                        try
                        {
                            using (MemoryStream stream = new MemoryStream())
                            {
                                wb.SaveAs(stream);
                                string excelname = $"HBLDataReport-{DateTime.Now.ToString("ddMMyyyy hh:mm:ss")}.xlsx";
                                return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", excelname);
                            }

                            // System.Windows.Forms.MessageBox.Show("File Save Successfully.!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        catch (Exception ex)
                        {
                            // System.Windows.Forms.MessageBox.Show("Something went wrong.!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
                

                

            }
            else
            {
                ViewBag.ErrorMessage = "Please Select Date";
            }

            return View();
        }

        ///Edit File
        [Authorize(Roles = "Admin,Supervisor,Manager")]
        [HttpGet]
        public IActionResult EditFile(string id)
        {
            //var query = _ctx.Set<FileEntryDashboardViewModel>().FromSqlRaw("SELECT * FROM vw_AdminDashboardViewModels").AsQueryable();
            IQueryable<FileEntry> data = _ctx.Set<FileEntry>().AsQueryable();

            List<DashboardViewModel> fileEntryViewModels = new List<DashboardViewModel>();
            _ctx.Database.SetCommandTimeout(300);
            fileEntryViewModels = data.Include(x => x.FileActivity).ThenInclude(x => x.ActivityMaster.ThreadMaster).Where(x => x.Id == id).Select(x => new DashboardViewModel
            {
                Id = x.Id,
                CreatedDate = x.CreatedDate,
                FileNo = x.FileNo,
                ContainerNo = x.ContainerNo,
                IsEdi = x.IsEdi == true ? "Yes" : "No",
                Pol = x.Pol,
                Pod = _ctx.LocationMaster.Where(y => y.Id == x.Pod).Select(y => y.Name).FirstOrDefault(),
                PodId = _ctx.LocationMaster.Where(y => y.Id == x.Pod).Select(y => y.Id).FirstOrDefault(),
                FinalDestination = x.FinalDestination,
                FileType = x.FileType,
                Hblcount = x.HblEntry.Count() != 0 ? x.HblEntry.Count().ToString() : x.Hblcount,
                Cbm = x.Cbm,
                CoLoader = x.CoLoader,
                SailingDate = x.SailingDate,
                EtaAtPod = x.EtaAtPod,
                EtaAtFD = x.EtaAtFD,
                MBLFreightTerm = x.MBLFreightTerm,
                HBLFreightTerm = x.HBLFreightTerm,
                VesselName = x.VesselName,
                ShippingLine = x.ShippingLine,
                ContactPerson = x.ContactPerson,
                ThreadName = x.FileActivity
            .OrderByDescending(y => y.EnterDate)
            .Select(y => y.ActivityMaster.ThreadMaster.Name)
            .FirstOrDefault(),

                AllocatedTo = x.FileActivity
            .OrderByDescending(y => y.EnterDate)
            .Select(y => _ctx.User
                .Where(z => z.Id == y.UserId)
                .Select(z => z.UserName)
                .FirstOrDefault())
            .FirstOrDefault(),

                Status = x.FileActivity
            .OrderByDescending(y => y.EnterDate)
            .Select(y => y.CurrentStatus)
            .FirstOrDefault() ?? "Pending",

                //    FileActivities = x.FileActivity
                //.OrderByDescending(y => y.EnterDate)
                //.Select(y => new FileActivity
                //{
                //    ActivityMaster = y.ActivityMaster,
                //    CurrentStatus = y.CurrentStatus,
                //    UserId = _ctx.User
                //        .Where(z => z.Id == y.UserId)
                //        .Select(z => z.UserName)
                //        .FirstOrDefault(),
                //    EndTime = y.EndTime,
                //    EnterDate = y.EnterDate
                //})
                //.ToList(),
                //HblEntry = x.HblEntry,

            })/*.Skip(skip * pageSize).Take(pageSize == -1 ? 100 : pageSize)*/.ToList();

            //var data = fileEntryViewModels.AsQueryable();
            ViewData["EditFile"] = fileEntryViewModels.FirstOrDefault();
            ViewData["Country"] = _ctx.LocationMaster.OrderBy(x => x.Name).ToList();
            return View();
        }

        [HttpPost]
        public IActionResult EditFile(FileEntryViewModel model)
        {
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            var act = _ctx.ActivityMaster.Where(x => x.BasedOn == "File" && x.ThreadMaster.Name == "HBL User" && x.IsActive == true && x.IsDelete == false).OrderBy(x => x.Sequence).ThenBy(x => x.Name).ToList();
            _ctx.Database.SetCommandTimeout(300);
            var present = _ctx.FileEntry.Where(x => x.Id == model.Id).FirstOrDefault();
            if (present != null)
            {
                present.FileNo = model.FileNo;
                present.ContainerNo = model.ContainerNo;
                present.IsEdi = (model.IsEdi.ToUpper() == "TRUE" || model.IsEdi.ToUpper() == "YES" ? true : false);
                present.Pol = model.Pol;
                present.Pod = model.Pod;
                present.FinalDestination = model.FinalDestination;
                present.FileType = model.FileType;
                present.Hblcount = model.Hblcount;
                //present.ActualHblcount = model.ActualHblcount;
                present.Cbm = model.Cbm;
                present.CoLoader = model.CoLoader;
                present.SailingDate = model.SailingDate;
                present.EtaAtPod = model.EtaAtPod;
                present.EtaAtFD = model.EtaAtFD;
                present.MBLFreightTerm = model.MBLFreightTerm;
                present.HBLFreightTerm = model.HBLFreightTerm;
                present.VesselName = model.VesselName;
                present.ShippingLine = model.ShippingLine;
                present.ContactPerson = model.ContactPerson;
                //present.Status = model.Status;
                //present.CreatedDate = DateTime.UtcNow;
                //present.CreatedBy = userid;

                _ctx.FileEntry.Update(present);
                _ctx.SaveChanges();
                return Json("Success");
            }
            else
            {
                return Json("Container Already present.!");
            }
        }
    }
}


