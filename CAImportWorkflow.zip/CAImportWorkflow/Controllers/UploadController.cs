﻿using ClosedXML.Excel;
using DocumentFormat.OpenXml.Spreadsheet;
using CAImportWorkflow.Data;
using CAImportWorkflow.Models;
using Microsoft.AspNetCore.Mvc;
using System.Data;
using System.Drawing;
using System.Net;
using CAImportWorkflow;
using Microsoft.AspNetCore.Authorization;
using DocumentFormat.OpenXml.Office2010.Excel;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using System.Diagnostics;
using Microsoft.AspNetCore.Http.HttpResults;
using Syncfusion.JavaScript.DataVisualization.Builders;


namespace CAImportWorkflow.Controllers
{
    public class UploadController : Controller
    {
        ApplicationDbContext _context;
        public UploadController(ApplicationDbContext context)
        {
            _context = context;
        }

        [Authorize(Roles = "Supervisor,Manager,Admin")]
        public IActionResult Index()
        {
            ViewData["Location"] = _context.LocationMaster.Where(x => x.IsActive == true).OrderBy(x => x.Name).ToList();
            //ViewData["POL"] = _context.POLMaster.Where(x => x.IsActive == true).OrderBy(x => x.Name).ToList();
            return View(new UploadViewModel());
        }
        [Authorize(Roles = "Supervisor,Manager,Admin")]
        [HttpPost]
        public async Task<IActionResult> Index(UploadViewModel model)
        {


            if (ModelState.IsValid)
             {
                // Save the uploaded file to the server
                var filePath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "uploads", model.File.FileName);
                using (var stream = new FileStream(filePath, FileMode.Create))
                {
                    await model.File.CopyToAsync(stream);
                }
                var uploadResult = UploadFile(filePath);

                // Check if the UploadFile method was successful
                if (uploadResult is JsonResult && ((JsonResult)uploadResult).Value.ToString() == "success")
                {
                    return Json("success");
                }
                else
                {
                    return Json("error");
                }

            }
            else
            {
                return Json("Invalid file.");
                //return Json(new { success = false, message = "Invalid file." });
            }
            // Return a response to the client
        }

        [Authorize(Roles = "Supervisor,Manager,Admin")]
        public JsonResult UploadFile(string filePath)
        {
            DataTable Rawdata = new DataTable();
            List<FileEntry> filemaster = new List<FileEntry>();
            List<HblEntry> hBLMaster = new List<HblEntry>();
            List<FileActivity> fileActivityLog = new List<FileActivity>();
            //var carrierRequest = _context.ActivityMaster.FirstOrDefault(x => x.Name == "Carrier Request" && x.IsActive == true && x.IsDelete == false)?.Id;
            //var pending = _context.StatusMaster.FirstOrDefault(x => x.Status == "Pending" && x.IsActive == true && x.IsDelete == false)?.Id;
            DataTable UploadRawdata = GeneralFunction.GetDataFromExcel(filePath);
            var isfilepresent = _context.FileEntry.ToList();

            try
            {
                var filemasterdata = UploadRawdata.AsEnumerable().ToList();

                foreach (DataRow dr in filemasterdata)
                {
                    string containerNo = dr["Container No"].ToString().Trim();
                    //string[] parts = containerNo.Split('/');
                    string locationName = dr["Pod"].ToString().Trim().ToLower();
                    string polName = dr["Pol"].ToString().Trim();
                    var duplicate = isfilepresent.FirstOrDefault(x => x.ContainerNo == containerNo);

                    var locationId = _context.LocationMaster
                        .FirstOrDefault(x => x.Name.ToLower() == locationName && x.IsActive == true)?.Id;
                    //var polId = _context.POLMaster
                    //    .FirstOrDefault(x => x.Name == polName && x.IsActive == true)?.Id;

                    if (duplicate == null)
                    {
                        try
                        {
                            FileEntry filemas = InsertIntoDB(dr, locationName, polName, /*polId,*/ locationId);
                            filemaster.Add(filemas);
                        }
                        catch (Exception ex)
                        {
                            return Json("error");
                        }
                    }
                    else
                    {
                        try
                        {
                            UpdateFileMaster(duplicate, dr, locationName, polName, /*polId,*/ locationId);
                        }
                        catch (Exception ex)
                        {
                            return Json("error");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                return Json("error");
            }

            _context.FileEntry.AddRange(filemaster);
            _context.SaveChanges();

            var fileList = _context.FileEntry.ToList();

            var activityMasterQuery = _context.ActivityMaster
                .Include(x => x.ThreadMaster)
                .Where(x => x.BasedOn == "File" && x.ThreadMaster.Name == "HBL User" && x.ThreadMaster.IsActive && x.IsActive);
            var activities = activityMasterQuery.ToList();

            foreach (var item in fileList)
            {
                var filelog = _context.FileActivity.FirstOrDefault(x => x.FileId == item.Id);

                if (filelog == null)
                {
                    foreach (var activity in activities)
                    {
                        _context.FileActivity.Add(new FileActivity
                        {
                            Id = Guid.NewGuid().ToString(),
                            FileId = item.Id,
                            ActivityId = activity.Id,
                            CurrentStatus = "UnAllocated",
                            UserId = item.AllocatedTo != null ? item.AllocatedTo : null,
                            EnterDate = DateTime.UtcNow,
                        });
                        _context.SaveChanges();
                    }
                }
                else
                {
                    foreach (var activity in activities)
                    {
                        filelog.FileId = item.Id;
                        filelog.ActivityId = activity.Id;
                        filelog.CurrentStatus = item.Status == "UnAllocated" ? "UnAllocated" : item.Status; // assuming you want to update the status
                        filelog.UserId = item.AllocatedTo != null ? item.AllocatedTo : null;
                        filelog.EnterDate = filelog.EnterDate != null ? filelog.EnterDate : (DateTime?) null;

                        _context.FileActivity.Update(filelog);
                    }
                }
            }

            _context.SaveChanges();

            return Json("success");

            //return Json("success");
        }

        [Authorize(Roles = "Supervisor,Manager,Admin")]
        public FileEntry InsertIntoDB(DataRow dr, string locationName, string polName, /*string polId,*/ string locationId)
        {
            var location = _context.LocationMaster.FirstOrDefault(x => x.Name.ToLower() == locationName && x.IsActive == true);
            //var pol = _context.POLMaster.FirstOrDefault(x => x.Name == polName && x.IsActive == true);
            var userId = _context.User.FirstOrDefault(x => x.CitrixId == dr["Allocated User"].ToString().Trim() && x.IsActive == true && x.IsDelete == false)?.Id; 

            if (location == null)
            {
                location = new LocationMaster
                {
                    Name = locationName.ToUpper(),
                    IsActive = true
                };

                _context.LocationMaster.Add(location);
                _context.SaveChanges();
            }
            else
            {
                location.Name = locationName.ToUpper();
            }

            //if (pol == null)
            //{
            //    pol = new POLMaster
            //    {
            //        Name = polName,
            //        IsActive = true
            //    };

            //    _context.POLMaster.Add(pol);
            //    _context.SaveChanges();
            //}
            //else
            //{
            //    pol.Name = polName;
            //}

            var efile = new FileEntry
            {
                Id = Guid.NewGuid().ToString(),
                CreatedDate = DateTime.UtcNow,
                FileNo = dr["File No"].ToString().Trim(),
                ContainerNo = dr["Container No"].ToString().Trim(),
                FileType = dr["File Type"].ToString().Trim() == "Select" ? null : dr["File Type"].ToString().Trim(),
                Hblcount = dr["HBL Count"].ToString().Trim(),
                IsEdi = dr["IsEdi"].ToString().Trim().ToLower() == "yes" ? true : false,
                AllocatedTo = userId != null ? userId : null,
                EtaAtPod = Convert.ToDateTime(dr["Eta At Pod"]).ToUniversalTime(),
                Pod = locationId,
                Pol = dr["Pol"].ToString().Trim(),
                FinalDestination = dr["Final Destination"].ToString().Trim(),
                Cbm = dr["Cbm"].ToString().Trim(),
                CoLoader = dr["CoLoader"].ToString().Trim(),
                SailingDate = Convert.ToDateTime(dr["Sailing Date"]).ToUniversalTime(),
                EtaAtFD = Convert.ToDateTime(dr["ETA at FD"]).ToUniversalTime(),
                MBLFreightTerm = dr["MBL Freight Term"].ToString().Trim() == "Select" ? null : dr["MBL Freight Term"].ToString().Trim(),
                HBLFreightTerm = dr["HBL Freight Term"].ToString().Trim() == "Select" ? null : dr["HBL Freight Term"].ToString().Trim(),
                VesselName = dr["Vessel Name"].ToString().Trim(),
                ShippingLine = dr["Shipping Line"].ToString().Trim(),
                ContactPerson = dr["Contact Person"].ToString().Trim(),
                Status = dr["Status"].ToString().Trim() == "Select" ? "UnAllocated" : dr["Status"].ToString().Trim(),
                //CreatedBy = dr["Allocated User"].ToString().Trim(),
            };

            return efile;
        }

        private void UpdateFileMaster(FileEntry duplicate, DataRow dr, string locationName, string polName, /*string polId,*/ string locationId)
        {
            var location = _context.LocationMaster.FirstOrDefault(x => x.Name.ToLower() == locationName && x.IsActive == true);
            var userId = _context.User.FirstOrDefault(x => x.CitrixId == dr["Allocated User"].ToString().Trim() && x.IsActive == true && x.IsDelete == false)?.Id;
            
            if (location == null)
            {
                location = new LocationMaster
                {
                    Name = locationName.ToUpper(),
                    IsActive = true
                };

                _context.LocationMaster.Add(location);
                _context.SaveChanges();
            }
            else
            {
                location.Name = locationName.ToUpper();
            }

            duplicate.FileNo = dr["File No"].ToString().Trim();
            duplicate.ContainerNo = dr["Container No"].ToString().Trim();
            duplicate.FileType = dr["File Type"].ToString().Trim() == "Select" ? null : dr["File Type"].ToString().Trim();
            duplicate.Hblcount = dr["HBL Count"].ToString().Trim();
            duplicate.IsEdi = dr["IsEdi"].ToString().Trim().ToLower() == "yes" ? true : false;
            duplicate.AllocatedTo = userId != null ? userId : null;
            duplicate.EtaAtPod = Convert.ToDateTime(dr["Eta At Pod"]).ToUniversalTime();
            duplicate.Pod = location.Id;
            duplicate.Pol = dr["Pol"].ToString().Trim();
            duplicate.FinalDestination = dr["Final Destination"].ToString().Trim();
            duplicate.Cbm = dr["Cbm"].ToString().Trim();
            duplicate.CoLoader = dr["CoLoader"].ToString().Trim();
            duplicate.SailingDate = Convert.ToDateTime(dr["Sailing Date"]).ToUniversalTime();
            duplicate.EtaAtFD = Convert.ToDateTime(dr["ETA at FD"]).ToUniversalTime();
            duplicate.MBLFreightTerm = dr["MBL Freight Term"].ToString().Trim() == "Select" ? null : dr["MBL Freight Term"].ToString().Trim();
            duplicate.HBLFreightTerm = dr["HBL Freight Term"].ToString().Trim() == "Select" ? null : dr["HBL Freight Term"].ToString().Trim();
            duplicate.VesselName = dr["Vessel Name"].ToString().Trim();
            duplicate.ShippingLine = dr["Shipping Line"].ToString().Trim();
            duplicate.ContactPerson = dr["Contact Person"].ToString().Trim();
            duplicate.Status = dr["Status"].ToString().Trim() == "Select" ? "UnAllocated" : dr["Status"].ToString().Trim();
            //duplicate.CreatedBy = dr["Allocated User"].ToString().Trim();
            _context.FileEntry.Update(duplicate);
        }
    }
}
