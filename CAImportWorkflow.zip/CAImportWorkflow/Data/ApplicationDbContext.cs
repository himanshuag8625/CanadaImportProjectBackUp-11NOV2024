﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using CAImportWorkflow.Data;
using CAImportWorkflow.Models;

namespace CAImportWorkflow.Data
{
    public partial class ApplicationDbContext :IdentityDbContext<User, Role, string>
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }
        public virtual DbSet<FileEntry> FileEntry{ get; set; }
        public virtual DbSet<HblEntry> HblEntry { get; set; }
        public virtual DbSet<ActivityMaster> ActivityMaster { get; set; }
        public virtual DbSet<FileActivity> FileActivity { get; set; }
        public virtual DbSet<HblActivity> HblActivity{ get; set; }
        public virtual DbSet<ThreadMaster> ThreadMaster { get; set; }
        public virtual DbSet<ThreadRelation> ThreadRelation { get; set; }
        public virtual DbSet<User> User { get; set; }
        public virtual DbSet<Role> Role { get; set; }
        public virtual DbSet<ActivityMapping> ActivityMapping { get; set; }
        public virtual DbSet<LocationMaster> LocationMaster { get; set; }
        public virtual DbSet<UserLocationRelation> UserLocationRelation { get; set; }
        public virtual DbSet<FileHistoryLog> FileHistoryLog { get; set; }
        public virtual DbSet<HBLHistoryLog> HBLHistoryLog { get; set; }
        public virtual DbSet<FileEntryDashboardViewModel> FileEntryDashboardViewModel { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Map the view to the AdminDashboardViewModel
            modelBuilder.Entity<FileEntryDashboardViewModel>()
                .HasNoKey()  // Since this is a view, we don't have a primary key
                .ToView("vw_AdminDashboardViewModels");

            modelBuilder.Entity<FileEntryDashboardViewModel>()
                .HasNoKey()  // Since this is a view, we don't have a primary key
                .ToView("vw_AdminDashboardCount");
        }
    }
}
