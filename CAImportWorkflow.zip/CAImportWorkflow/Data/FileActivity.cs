﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace CAImportWorkflow.Data
{
    public partial class FileActivity
    {
        
        public string Id { get; set; } = Guid.NewGuid().ToString();
        public string? FileId { get; set; }
        public string? ActivityId { get; set; }
        public string? CurrentStatus { get; set; }
        public string? Comment { get; set; } = string.Empty;
        public string? UserId { get; set; }
        public DateTime? StartTime { get; set; }
        public DateTime? EndTime { get; set; }
        public DateTime? EnterDate { get; set; } = DateTime.UtcNow;


        [ForeignKey("FileId")]
        public virtual FileEntry FileEntry { get; set; }

        [ForeignKey("ActivityId")]
        public virtual ActivityMaster ActivityMaster { get; set; }

        [ForeignKey("UserId")]
        public virtual User? User { get; set; }
        public virtual ICollection<FileHistoryLog> FileHistoryLog { get; set; }

    }
}
