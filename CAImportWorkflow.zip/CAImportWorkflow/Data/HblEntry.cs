﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace CAImportWorkflow.Data
{
    public partial class HblEntry
    {
        public HblEntry()
        {
            HblActivity = new HashSet<HblActivity>();
        }

        public string Id { get; set; } = Guid.NewGuid().ToString(); 
        public string FileGuidId { get; set; }
        public string Hblno { get; set; }
        public bool? IsDap { get; set; }
        public string? CreatedBy { get; set; }
        public DateTime? CreatedDate { get; set; }

        public virtual FileEntry FileGuid { get; set; }
        public virtual ICollection<HblActivity> HblActivity { get; set; }

        [ForeignKey("CreatedBy")]
        public User User { get; set; }
    }
}
