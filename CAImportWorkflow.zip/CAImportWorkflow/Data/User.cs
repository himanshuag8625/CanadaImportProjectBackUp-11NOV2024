﻿using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;

namespace CAImportWorkflow.Data
{
    public partial class User : IdentityUser
    {
        public User()
        {
            ThreadRelation = new HashSet<ThreadRelation>();
            FileActivities = new HashSet<FileActivity>();
            HblActivities = new HashSet<HblActivity>();
            FileEntries = new HashSet<FileEntry>();
            HblEntries = new HashSet<HblEntry>();
        }
        public override string Id { get; set; } = Guid.NewGuid().ToString();
        public override string UserName { get; set; }
        public string Wnsid { get; set; }
        public string CitrixId { get; set; }
        public string DocContact { get; set; }

        public bool? IsActive { get; set; } = true;
        public bool IsDelete { get; set; } = false;
        public bool IsLDAP { get; set; } = false;
        public bool IsReset { get; set; } = false;
        public ICollection<ThreadRelation> ThreadRelation { get; set; }
        public ICollection<FileActivity> FileActivities { get; set; }
        public ICollection<HblActivity> HblActivities { get; set; }
        public ICollection<FileEntry> FileEntries { get; set; }
        public ICollection<HblEntry> HblEntries { get; set; }

    }
}
