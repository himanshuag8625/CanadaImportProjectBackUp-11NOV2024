﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CAImportWorkflow.Migrations
{
    public partial class ThreadUserIdRemoved : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
               name: "UserId",
               table: "ThreadMaster");
        }
    }
}
