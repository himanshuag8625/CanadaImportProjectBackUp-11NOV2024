﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CAImportWorkflow.Migrations
{
    public partial class IsDeleteInActivityMaster : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<bool>(
                name: "IsDelete",
                table: "ActivityMaster",
                type: "bit",
                nullable: false,
                defaultValue: false);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "IsDelete",
                table: "ActivityMaster");
        }
    }
}
