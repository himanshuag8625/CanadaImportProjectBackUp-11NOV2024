﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CAImportWorkflow.Migrations
{
    public partial class AddSequenceinActivityMaster : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "Sequance",
                table: "ThreadMaster",
                newName: "Sequence");

            migrationBuilder.AddColumn<int>(
                name: "Sequence",
                table: "ActivityMaster",
                type: "int",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Sequence",
                table: "ActivityMaster");

            migrationBuilder.RenameColumn(
                name: "Sequence",
                table: "ThreadMaster",
                newName: "Sequance");
        }
    }
}
