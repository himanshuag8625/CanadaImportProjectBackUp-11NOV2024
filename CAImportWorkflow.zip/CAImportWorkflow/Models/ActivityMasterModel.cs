﻿namespace CAImportWorkflow.Models
{
    public class ActivityMasterModel
    {
        public string Id { get; set; } = Guid.NewGuid().ToString();
        public string Name { get; set; }
        public string BasedOn { get; set; }
        public int? Sequence { get; set; } = 999;
        public bool IsActive { get; set; }
        public bool IsDelete { get; set; }
        public string ThreadId { get; set; }
        public string? ThreadName { get; set; }
    }
}
