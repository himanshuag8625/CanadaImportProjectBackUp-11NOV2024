﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CAImportWorkflow.Models
{
    public class AdminDashboardModel
    {
        public string FileNo { get; set; }
        public int Received { get; set; }
        public int WIP { get; set; }
        public int Completed { get; set; }
        public int Pending { get; set; }
        public int UnTouched { get; set; }
        public int Query { get; set; }
        public int eta10 { get; set; }
        public int eta12 { get; set; }
        public int eta18 { get; set; }
         
    }

    public class CustomeFileActivity
    {
        public string ThreadName { get; set; }
        public string ActivityName { get; set; }
        public int Total { get; set; } = 0;
        public int Unallocated { get; set; } = 0;
        public int Pending { get; set; } = 0;
        public int Query { get; set; } = 0;
        public int CompletedWithQuery { get; set; } = 0;
        public int Completed { get; set; } = 0;

    }



}
