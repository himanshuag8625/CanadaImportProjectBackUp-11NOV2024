﻿namespace CAImportWorkflow.Models
{
    public class FileReportViewModel
    {
        public DateTime? ReceivedDate { get; set; }
        public string? FileNo { get; set; }
        public string? ContainerNo { get; set; }
        public string? IsEdi { get; set; }
        public string? POL { get; set; }
        public string? POD { get; set; }
        public string? FinalDestination { get; set; }
        public string? FileType { get; set; }
        public string? HBLCount { get; set; }
        public string? CBM { get; set; }
        public string? Coloader { get; set; }
        public DateTime? SailingDate { get; set; }
        public DateTime? ETA { get; set; }
        public DateTime? ETAFD { get; set; }
        public string? MBLFreightTerm { get; set; }
        public string? HBLFreightTerm { get; set; }
        public string? VesselName { get; set; }
        public string? ShippingLine { get; set; }
        public string? ContactPerson { get; set; }
        public string? ThreadName { get; set; }
        public string? Activity { get; set; }
        public string? Status { get; set; }
        public string? User { get; set; }
        public string? Comment { get; set; }
        //public int? Pages { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }

    }
}
