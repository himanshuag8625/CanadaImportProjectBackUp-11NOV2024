﻿using CAImportWorkflow.Data;
using Microsoft.AspNetCore.Identity;
using System.ComponentModel.DataAnnotations;

namespace CAImportWorkflow.Models
{
    public class RegisterViewModel
    {

        public string Id { get; set; }

        [Required]
        public string UserName { get; set; }
        [Required]
        public string Wnsid { get; set; }
        [Required]
        public string CitrixId { get; set; }
        public bool? IsActive { get; set; }
        public bool IsDelete { get; set; }
        public bool IsLDAP { get; set; }
        public bool IsReset { get; set; }
        public List<Role>? RoleList { get; set; }
        public List<string>? assingedRoleList { get; set; }
        public List<ThreadMaster>? threadMasters { get; set; }
        public List<string>? assignedThreads { get; set; }
        public List<LocationMaster> locationMasterList { get; set; }
        public List<string> assignedLocation { get; set; }
    }
}