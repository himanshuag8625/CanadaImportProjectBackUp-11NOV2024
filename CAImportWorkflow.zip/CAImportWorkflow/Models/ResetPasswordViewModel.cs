﻿using CAImportWorkflow.Data;

namespace CAImportWorkflow.Models
{
    public class ResetPasswordViewModel
    {
        public IEnumerable<User> Users { get; set; }
        public string SelectedUserId { get; set; }
    }
}