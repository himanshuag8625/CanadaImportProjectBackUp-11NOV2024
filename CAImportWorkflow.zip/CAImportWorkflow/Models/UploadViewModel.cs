﻿namespace CAImportWorkflow.Models
{
    public class UploadViewModel
    {
        public string? LocationId { get; set; }
        public string? POLId { get; set; }
        public IFormFile File { get; set; }
    }
}
