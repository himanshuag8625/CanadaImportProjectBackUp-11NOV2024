$(function() {
  setTimeout(function(){
    $('body').removeClass('loading');
  }, 1000);
});
